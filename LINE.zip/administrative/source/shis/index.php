<?php
ob_start();
/*
creator : @Developer_P_H_P
channels : @PowerfulTM,@IranTM
*/
define('API_KEY','[*[TOKEN]*]');
 
function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,http_build_query($datas));
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}
$up=json_decode(file_get_contents('php://input'));
$sudo=[*[ADMIN]*];
$fwd_id=$up->message->reply_to_message->forward_from->id;
$first_name=$up->message->from->first_name;
$last_name=$up->message->from->last_name;
$msg_id=$up->message->message_id;
$username=$up->message->from->username;
$chat_id=$up->message->chat->id;
$from_id=$up->message->from->id;
if(!file_exists("sudo.txt")){
  file_put_contents("sudo.txt","empty");
}
$vaziyat=file_get_contents("sudo.txt");
if(!file_exists("member.txt")){
  file_put_contents("member.txt","$sudo");
}
if(!file_exists("profile.txt")){
  file_put_contents("profile.txt","پروفایل خالی است.");
}
if(!file_exists("start.txt")){
  file_put_contents("start.txt","باسلام.خوش آمدید.\nلطفا پیام خود را ارسال نمایید.");
}
if(!file_exists("block.txt")){
  file_put_contents("block.txt","block");
}
$text=$up->message->text;
$member=file("member.txt");
if(isset($up->message)){
  if($from_id==$sudo){
    if($text=="لغو" and $vaziyat!="empty"){
      file_put_contents("sudo.txt","empty");
      var_dump(bot("sendMessage",[
        "chat_id"=>$chat_id,
        "text"=>"_عملیات لغو شد._",
        "parse_mode"=>"markdown",
        "reply_markup"=>json_encode(["remove_keyboard"=>true])
      ]));
    }elseif($vaziyat=="forward"){
      foreach($member as $key=>$value){
        $id=$value+0;
        var_dump(bot("forwardMessage",[
          "chat_id"=>$id,
          "from_chat_id"=>$chat_id,
          "message_id"=>$msg_id
        ]));
      }
      var_dump(bot("sendMessage",[
        "chat_id"=>$chat_id,
        "text"=>"_پیام شما با موفقیت به تمام کاربران ارسال شد._",
        "parse_mode"=>"markdown",
        "reply_markup"=>json_encode(["remove_keyboard"=>true])
      ]));
      file_put_contents("sudo.txt","empty");
    }elseif($vaziyat=="profile"){
      if(isset($up->message->text)){
        var_dump(bot("sendmessage",[
          "chat_id"=>$chat_id,
          "text"=>"_پیام پروفایل ذخیره شد._",
          "parse_mode"=>"markdown",
          "reply_markup"=>json_encode(["remove_keyboard"=>true])
        ]));
        file_put_contents("sudo.txt","empty");
        file_put_contents("profile.txt","$text");
      }else{
        var_dump(bot("sendmessage",[
          "chat_id"=>$chat_id,
          "text"=>"_پیام فقط باید حاوی متن باشد._",
          "parse_mode"=>"markdown"
        ]));
      }
    }elseif($vaziyat=="start"){
      if(isset($up->message->text)){
        var_dump(bot("sendmessage",[
          "chat_id"=>$chat_id,
          "text"=>"_پیام دستور استارت تغییر کرد._",
          "parse_mode"=>"markdown",
          "reply_markup"=>json_encode(["remove_keyboard"=>true])
        ]));
        file_put_contents("sudo.txt","empty");
        file_put_contents("start.txt","$text");
      }else{
        var_dump(bot("sendmessage",[
          "chat_id"=>$chat_id,
          "text"=>"_پیام فقط باید حاوی متن باشد._",
          "parse_mode"=>"markdown"
        ]));
      }
    }elseif($text=="/block" and isset($up->message->reply_to_message->forward_from->id) and $fwd_id!=$sudo){
      $file=fopen("block.txt","a");
      fwrite($file,"\n$fwd_id");
      fclose($file);
      var_dump(bot("sendmessage",[
          "chat_id"=>$fwd_id,
          "text"=>"_کاربر شما از ربات بلاک شدید._",
          "parse_mode"=>"markdown"
        ]));
        var_dump(bot("sendmessage",[
          "chat_id"=>$chat_id,
          "text"=>"_کاربر $fwd_id بلاک شد._",
          "parse_mode"=>"markdown"
        ])); 
    }elseif(isset($up->message->reply_to_message) && !empty($fwd_id)){
      var_dump(bot("forwardmessage",[
          "chat_id"=>$fwd_id,
          "from_chat_id"=>$chat_id,
          "message_id"=>$msg_id
        ]));
        var_dump(bot("sendmessage",[
          "chat_id"=>$chat_id,
          "text"=>"_پیام شما باموفقیت ارسال شد._",
          "parse_mode"=>"markdown"
        ]));
    }elseif($text=="/start"){
      var_dump(bot("sendmessage",[
          "chat_id"=>$chat_id,
          "text"=>"_چکاری میتونم انجام بدم ادمین؟_",
          "parse_mode"=>"markdown",
          "reply_markup"=>json_encode(["inline_keyboard"=>[[["text"=>"آمار 👥","callback_data"=>"amar"],["text"=>"پروفایل 👤","callback_data"=>"profile"]],[["text"=>"فروارد همگانی 🗣","callback_data"=>"forward"],["text"=>"بلاک لیست 🚫","callback_data"=>"block"]],[["text"=>"♨️ پیام استارت ربات ♨️","callback_data"=>"start"]]]])
        ]));
    }
  }else{
   if(!strstr(file_get_contents("block.txt"),"$from_id")){
    if(!isset($up->message->forward_from) && !isset($up->message->forward_from_chat)){
      if($text=="/start"){
        $start=str_replace("userid","$from_id",file_get_contents("start.txt"));
        $start=str_replace("username","$username",$start);
        $start=str_replace("firstname","$first_name",$start);
        $start=str_replace("lastname","$last_name",$start);
        var_dump(bot("sendMessage",[
          "chat_id"=>$chat_id,
          "text"=>"$start",
          "reply_markup"=>json_encode(["resize_keyboard"=>true,"keyboard"=>[[["text"=>"پروفایل"]]]])
        ]));
        if(!strstr(file_get_contents("member.txt"),"$from_id")){
          $file=fopen("member.txt","a");
          fwrite($file,"\n$from_id");
          fclose($file);
        }
      }elseif($text=="پروفایل"){
        $profile=file_get_contents("profile.txt");
        var_dump(bot("sendMessage",[
          "chat_id"=>$chat_id,
          "text"=>"$profile"
        ]));
      }else{
        var_dump(bot("forwardMessage",[
          "chat_id"=>$sudo,
          "from_chat_id"=>$chat_id,
          "message_id"=>$msg_id
        ]));
        var_dump(bot("sendMessage",[
          "chat_id"=>$chat_id,
          "text"=>"_پیام شما با موفقیت ارسال شد._",
          "parse_mode"=>"markdown"
        ]));
      }
    }else{
      var_dump(bot("sendMessage",[
          "chat_id"=>$chat_id,
          "text"=>"_لطفا از جایی پیام فروارد نکنید._",
          "parse_mode"=>"markdown"
        ]));
    }}
  }
}elseif(isset($up->callback_query)){
$data=$up->callback_query->data;
$cl_msgid=$up->callback_query->message->message_id;
$cl_fromid=$up->callback_query->from->id;
$cl_chatid=$up->callback_query->message->chat->id;
  if($cl_fromid==$sudo){
    if($vaziyat=="empty"){
      if($data=="amar"){
        $count=count($member);
        var_dump(bot("editMessageText",[
          "chat_id"=>$cl_chatid,
          "text"=>"_آمار ربات با احتساب خودتان $count نفر است._",
          "message_id"=>$cl_msgid,
          "parse_mode"=>"markdown",
          "reply_markup"=>json_encode(["inline_keyboard"=>[[["text"=>"بازگشت 🔙","callback_data"=>"back"]]]])
        ]));
      }elseif($data=="back"){
        var_dump(bot("editMessageText",[
          "chat_id"=>$cl_chatid,
          "text"=>"_چکاری میتونم انجام بدم ادمین؟_",
          "message_id"=>$cl_msgid,
          "parse_mode"=>"markdown",
          "reply_markup"=>json_encode(["inline_keyboard"=>[[["text"=>"آمار 👥","callback_data"=>"amar"],["text"=>"پروفایل 👤","callback_data"=>"profile"]],[["text"=>"فروارد همگانی 🗣","callback_data"=>"forward"],["text"=>"بلاک لیست 🚫","callback_data"=>"block"]],[["text"=>"♨️ پیام استارت ربات ♨️","callback_data"=>"start"]]]])
        ]));
      }elseif($data=="profile"){
        var_dump(bot("editMessageText",[
          "chat_id"=>$cl_chatid,
          "text"=>file_get_contents("profile.txt"),
          "message_id"=>$cl_msgid,
          "reply_markup"=>json_encode(["inline_keyboard"=>[[["text"=>"بازگشت 🔙","callback_data"=>"back"],["text"=>"تغییر 🖊","callback_data"=>"changeprofile"]]]])
        ]));
      }elseif($data=="changeprofile"){
        file_put_contents("sudo.txt","profile");
        var_dump(bot("sendMessage",[
          "chat_id"=>$cl_chatid,
          "text"=>"_لطفا پیام خود را که فقط حاوی متن باشد ارسال کنید._",
          "parse_mode"=>"markdown",
          "reply_markup"=>json_encode(["resize_keyboard"=>true,"keyboard"=>[[["text"=>"لغو"]]]])
        ]));
      }elseif($data=="forward"){
        file_put_contents("sudo.txt","forward");
        var_dump(bot("sendMessage",[
          "chat_id"=>$cl_chatid,
          "text"=>"_لطفا پیام خود را ارسال کنید._",
          "parse_mode"=>"markdown",
          "reply_markup"=>json_encode(["resize_keyboard"=>true,"keyboard"=>[[["text"=>"لغو"]]]])]));
      }elseif($data=="start"){
        $txt=file_get_contents("start.txt");
        var_dump(bot("editMessageText",[
          "chat_id"=>$cl_chatid,
          "text"=>"$txt",
          "message_id"=>$cl_msgid,
          "reply_markup"=>json_encode(["inline_keyboard"=>[[["text"=>"بازگشت 🔙","callback_data"=>"back"],["text"=>"تغییر 🖊","callback_data"=>"changestart"]]]])
        ]));
      }elseif($data=="changestart"){
        file_put_contents("sudo.txt","start");
        var_dump(bot("sendMessage",[
          "chat_id"=>$cl_chatid,
          "text"=>"_لطفا پیام خود را که فقط حاوی متن باشد ارسال کنید.کلمات زیر جایگزین خواهند شد.\nuserid با آیدی فرد\nfirstname با نام فرد\nlastname با نام خانوادگی فرد\nusername با یوزرنیم فرد._",
          "parse_mode"=>"markdown",
          "reply_markup"=>json_encode(["resize_keyboard"=>true,"keyboard"=>[[["text"=>"لغو"]]]])
        ]));
      }elseif($data=="block"){
        $array=explode("\n",str_replace("block\n","",file_get_contents("block.txt")));
        if($array[0]!="block"){
          $list=array();
          foreach($array as $key=>$value){
            $list[$key]=array(array("text"=>"$value","callback_data"=>"$value"));
          }
          var_dump(bot("sendMessage",[
            "chat_id"=>$cl_chatid,
            "text"=>"_>>>بلاک لیست<<<_",
            "parse_mode"=>"markdown",
            "reply_markup"=>json_encode(array("inline_keyboard"=>$list))
          ]));
        }else{
          var_dump(bot("sendMessage",[
       