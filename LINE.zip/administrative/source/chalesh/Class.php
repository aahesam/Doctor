<?php

define('API_KEY', '[*[TOKEN]*]');

function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}
function sendmessage($chat_id, $text){
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>$text,
 'parse_mode'=>"MarkDown"
 ]);
 } 
 

function deleteFolder($path){
    if (is_dir($path) === true) {
        $files = array_diff(scandir($path), array('.', '..'));
        foreach ($files as $file)
            deleteFolder(realpath($path) . '/' . $file);
            
        return rmdir($path);
    } else if (is_file($path) === true)
        return unlink($path);
 
    return false;
}
function ForwardMessage($chatid,$from_chat,$message_id){
 bot('ForwardMessage',[
 'chat_id'=>$chatid,
 'from_chat_id'=>$forward_chat,
 'message_id'=>$message_id
 ]);
 }
 function senddocument($chat_id, $document, $caption){
 bot('senddocument',[
 'chat_id'=>$chat_id,
 'document'=>$document,
 'caption'=>$caption
 ]);
 }
 function sendaction($chat_id, $action){
	bot('sendchataction',[
	'chat_id'=>$chat_id,
	'action'=>$action
	]);
	}
	function Forward($KojaShe,$AzKoja,$KodomMSG)
{
    bot('Forward' ,[
        'chat_id'=>$KojaShe,
        'from_chat_id'=>$AzKoja,
        'message_id'=>$KodomMSG
    ]);
}
function save($filename,$TXTdata)
	{
	$myfile = fopen($filename, "w") or die("Unable to open file!");
	fwrite($myfile, "$TXTdata");
	fclose($myfile);
	}
	function objectToArrays( $object ) {
    if( !is_object( $object ) && !is_array( $object ) )
    {
    return $object;
    }
    if( is_object( $object ) )
    {
    $object = get_object_vars( $object );
    }
   return array_map( "objectToArrays", $object );
   }
//-//////
$update = json_decode(file_get_contents('php://input'));
$message = $update->message; 
$chat_id = $message->chat->id;
$name = $message->from->first_name;
$username = $message->from->username;
$from_id = $message->from->id;
$text = $message->text;
$chatid = $update->callback_query->message->chat->id;
$data = $update->callback_query->data;
$admin = [*[ADMIN]*];
$bi = createbot_king_bot;
$sudo = file_get_contents("data/sudo.txt");
$cha = file_get_contents("data/AdsCh.txt");
$tag = file_get_contents("data/id.txt");
$creator = file_get_contents("data/cr.txt");
$start = file_get_contents("data/start.txt");
$message_id = $update->callback_query->message->message_id;
$datetime = json_decode(file_get_contents("http://irapi.ir/time/"));
$date = $datetime->FAdate;
$time = $datetime->FAtime;
$ali = file_get_contents("data/".$chat_id."/ali.txt");
$command = file_get_contents('data/'.$from_id."/command.txt");
mkdir("data/$chat_id");
mkdir("ch");
//---------------//
if($text == '/start'){
 if (!file_exists("data/$from_id/ali.txt")) {
        mkdir("data/$from_id");
        file_put_contents("data/$from_id/ali.txt","none");
        
        $myfile2 = fopen("users.txt", "a") or die("Unable to open file!");
        fwrite($myfile2, "$from_id\n");
        fclose($myfile2);
    $user = file_get_contents("users.txt");
    $member_id = explode("\n",$user);
    $member_count = count($member_id) -1;
          			bot('sendmessage',[
		'chat_id'=>"$admin",
		'text'=>"[یک نفر جدید با ایدی @$username و ایدی عددی $chat_id به ربات اومد!](tg://user?id=$chat_id)
🗓 تاریخ ورود به ربات : $date
⏱ ساعت ورود به ربات : $time
	
	تعداد عضو ها : $member_count
		
		",
		    'parse_mode'=>'MarkDown',
	]);
        }
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"$start

⏰ ساعت : $time
🗓 تاریخ : $date

🆔 @$creator",
 'parse_mode'=>"MarkDown",
  'reply_markup'=>json_encode([
            'keyboard'=>[
              [
              ['text'=>"🔸ساخت چالش"]
              ],
              [
              ['text'=>"😎 سازنده"],['text'=>"🔖 اطلاعات کاربری "]
              ],
              [
                  ['text'=>"📉 آمار ربات"]
                  ],
              ],
              "resize_keyboard"=>true
    ])
    ]);
bot('ForwardMessage' ,[
    'chat_id'=>$chat_id,
    'from_chat_id'=>"@$cha",
    'message_id'=>"$tag",
    ]);
}
elseif($text == "/creator"){
    bot('sendmessage' ,[
        'chat_id'=>$from_id,
        'text'=>"🤖Create Your Robot😃
🤖ربات خود را بسازید😃👇
🆔 @pvnarenj_bot
✊️با سرور قوی و پرسرعت💪
"
        ]);
}
elseif($text == "😎 سازنده"){
    bot('sendmessage' ,[
        'chat_id'=>$chat_id,
        'text'=>"🤖Create Your Robot😃
🤖ربات خود را بسازید😃👇
🆔 @pvnarenj_bot
✊️با سرور قوی و پرسرعت💪
",
        ]);
}
elseif($text == "🔖 اطلاعات کاربری"){
    bot('sendmessage' ,[
        'chat_id'=>$chat_id,
        'text'=>"🌀 نام : $name
🆔 ایدی : @$username
♨️ ایدی عددی : $chat_id",
        'parse_mode'=>"MarkDown",
        ]);
}
elseif($text == '🔸ساخت چالش'){
file_put_contents("data/$chat_id/ali.txt", "j");
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"💯 خوب `$name` جایزه اولین نفری که از طریق لینک وارد ربات شد رو بگو تا بهش بدم...
 
 ⚠️ توجه : `فایل یا استیکر یا عکس و گیف به دست کاربر نمیرسد!`",
 'parse_mode'=>"MarkDown",
 ]);
}
elseif($ali == 'j'){
$r = rand(10000000 , 100000000);
mkdir("ch/$r");
file_put_contents("data/$chat_id/ali.txt", "nono");
file_put_contents("ch/$r/j.txt", $text);
file_put_contents("ch/$r/chat_id.txt", $chat_id);
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"🌀 چالش شما با موفقیت در ساعت ($time) ساخته و ایجاد شد
 🔸 هم اکنون میتوانید لینک زیر را به اشتراک گذاشته و برنده را مشخص کنید!
 
 🌐 http://telegram.me/$bi?start=$r",
 'parse_mode'=>"MarkDown",
 ]);
    								bot('sendmessage',[
		'chat_id'=>"$admin",
		'text'=>"[کاربر $chat_id یک چالش جدید ساخت](tg://user?id=$chat_id)
	
⏰ ساعت ساخت چالش : $time
🗓 تاریخ ساخت چالش : $date

🎁 جایزه :
	$text
		
		🌀 لینک دریافت جایزه : 

http://t.me/$bi?start=$r
		",
		    'parse_mode'=>'MarkDown',
	]);
}
//--------//
 elseif (strpos($text, '/start') !== false) {
        $chid = str_replace("/start ", "", $text);
 if (file_exists("ch/$chid/j.txt")) {
  if (!file_exists("data/$from_id/ali.txt")) {
        mkdir("data/$from_id");
        file_put_contents("data/$from_id/ali.txt","none");
        $myfile2 = fopen("users.txt", "a") or die("Unable to open file!");
        fwrite($myfile2, "$from_id\n");
        fclose($myfile2);
    $user = file_get_contents("users.txt");
    $member_id = explode("\n",$user);
    $member_count = count($member_id) -1;
          
   								bot('sendmessage',[
		'chat_id'=>"$admin",
		'text'=>"[کاربر $chat_id هم اکنون از طریق چالش وارد ربات شد.](tg://user?id=$chat_id)
⏰ ساعت ورود : $time
📟 تاریخ ورود : $date

	تعداد عضو ها : $member_count
		
		",
		    'parse_mode'=>'MarkDown',
	]);
        }
     $a =   file_get_contents("ch/$chid/j.txt");
     $b =   file_get_contents("ch/$chid/chat_id.txt");
            bot('sendMessage', [
                'chat_id' => $chat_id,
                'text' => "🎗 تبریک `$name` عزیز شما برنده شدید!
                
💎 این چالش توسط کاربری با ایدی عددی $b ساخته شده است!

🎁 جایزه : 
$a",
                'parse_mode'=>"MarkDown",
                'reply_markup'=> json_encode([
                    'keyboard'=>[
                        [
                            ['text'=>"🔙 برگشت"]
                       ],
                        [
                     ['text'=>"🔸ساخت چالش"]
                     ]
                            ],
                            'resize_keyboard'=>true
                        ])
                ]);
                        bot('sendMessage', [
                'chat_id' => $b,
                'text' => "🔝 [کاربر $chat_id در ساعت ( $time ) برنده چالش شما شد!](tg://user?id=$chat_id)",
 'parse_mode'=>"MarkDown",
            ]);
            unlink("ch/$chid/j.txt");
            unlink("ch/$chid/chat_id.txt");
            rmdir("ch/".$chid);
deleteFolder("ch/".$chid);
        } else {
          if (!file_exists("data/$from_id/ali.txt")) {
        mkdir("data/$from_id");
        file_put_contents("data/$from_id/ali.txt","none");
        file_put_contents("data/$from_id/member.txt","0");
        $myfile2 = fopen("users.txt", "a") or die("Unable to open file!");
        fwrite($myfile2, "$from_id\n");
        fclose($myfile2);
    $user = file_get_contents("users.txt");
    $member_id = explode("\n",$user);
    $member_count = count($member_id) -1;
          
   								bot('sendmessage',[
		'chat_id'=>"$admin",
		'text'=>"[کاربر $name هم اکنون از طریق چالش وارد ربات شد!](tg://user?id=$chat_id)
	
	تعداد عضو ها : $member_count
		
		",
		    'parse_mode'=>'MarkDown',
	]);
        }
        bot('sendMessage', [
                'chat_id' => $chat_id,
                'text' => "
🚫 آخ آخ دیر رسیدی !

⭕️ یک کاربر زود تر از شما از همین لینک وارد ربات شد!

💯 تلاشت رو بیشتر کن دفعه بعد میبری",
 'parse_mode'=>"MarkDown",
            ]);
}

}
if($text == "🔙 برگشت"){
    bot('sendmessage' ,[
        'chat_id'=>$chat_id,
        'text'=>"↩️ به منوی اول برگشتیم حالا یک گزینه را انتخاب کنید!",
        'parse_mode'=>"MarkDown",
  'reply_markup'=>json_encode([
            'keyboard'=>[
              [
              ['text'=>"🔸ساخت چالش"]
              ],
              [
              ['text'=>"😎 سازنده"],['text'=>"🔖 اطلاعات کاربری "]
              ],
              [
                  ['text'=>"📉 آمار ربات"]
                  ],
              ],
              "resize_keyboard"=>true
        ])
 ]);
}
elseif($text == "/panel" &&$from_id == $admin){
        bot('sendmessage', [
                'chat_id' => $chat_id,
                'text' =>"☑️ سلام ادمین گرامی ( [$name](tg://user?id=$admin) ) به پنل مدیریت خودتون خوش اومدی!
🆔 @$creator",
'parse_mode'=>'MarkDown',
      'reply_markup'=>json_encode([
            'keyboard'=>[
                  [
                  ['text'=>"🔙 برگشت"]
                  ],
                  [
              ['text'=>"👤 آمار"],['text'=>"🌟 تعداد چالش"]
              ],
[
['text'=>"📮 پیام همگانی"],['text'=>"📟 فوروارد همگانی"]
],
[
['text'=>"☣ تنظیم سازنده"]
],
[
['text'=>"⭕️ تنظیم تبلیغ"],['text'=>"📯 تنظیم پیام شروع"]
],
[
    ['text'=>"💰 تنظیم کانال تبلیغات"]
    ],
    [
        ['text'=>"☸ تنظیم ادمین دوم"],['text'=>"✴️ اطلاعات ادمین دوم"]
        ],
              ],
            'resize_keyboard'=>true
        ])
            ]);
}
elseif($text == "✴️ اطلاعات ادمین دوم" && $from_id == $admin){
    sendmessage($admin,"💮 ادمین دوم ربات : [$sudo](tg://user?id=$sudo)","MarkDown");
}
elseif($text == "👤 آمار" && $from_id == $admin){
    $user = file_get_contents("users.txt");
    $member_id = explode("\n",$user);
    $member = count($member_id) -1;
 bot('sendmessage',[
'chat_id'=>$admin,
'text'=>"😎 آمار اعضای ربات : $member
    ",
    'parse_mode'=>"MarkDown",
    'reply_markup'=> json_encode([
        'keyboard'=>[
            [
                ['text'=>"👤 دریافت لیست اعضا"]
                ],
                [
                    ['text'=>"🔙 منوی ادمین"]
                    ],
                ],
                'resize_keyboard'=>true
            ])
     ]);
}
elseif($text == "👤 دریافت لیست اعضا"){
    $list = file_get_contents("users.txt");
    $member_id = explode("\n",$list);
    sendmessage($admin,"👤 لیست اعضای ربات : 
$list","MarkDown");
}
elseif($text == "🌟 تعداد چالش"){
    $chall = scandir("ch");
    $all = count ($chall) -2;
    bot('sendmessage' ,[
        'chat_id'=>$admin,
        'text'=>"🎗 تعداد کل چالش های باز : $all",
        ]);
}
elseif($text == "📉 آمار ربات"){
    $chall = scandir("ch");
    $all = count ($chall) -2;
    $user = file_get_contents("users.txt");
    $member_id = explode("\n",$user);
    $allme = count($member_id) -1;
      bot('sendmessage' ,[
      'chat_id'=>$chat_id,
      'text'=>"📊 آخرین آمار چالش ها و اعضا تا ساعت ($time) و تاریخ ($date) به این صورت میباشد...
      
      
      🔝 چالش های باز : $all
      😎 آمار اعضا : $allme",
      ]);
      bot('sendmessage' ,[
      'chat_id'=>$admin,
      'text'=>"💎 یک نفر آمار ربات شما را در `⏰ ساعت` ($time) دید!
      
👤 اطلاعات کاربر : 
نام : `$name`
ایدی عددی : `$chat_id`
نام کاربری : @$username",
       'parse_mode'=>"MarkDown",
       ]);
}
 elseif($text == "📮 پیام همگانی" && $chat_id == $admin){
    file_put_contents("data/$from_id/ali.txt","send");
 sendaction($chat_id,'typing');
 bot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"📮 پیام خود را به صورت متن ارسال کنید.",
    'parse_mode'=>'html',
    'reply_markup'=>json_encode([
      'keyboard'=>[
   [
['text'=>"🔙 منوی ادمین"]
],
      ],
'resize_keyboard'=>true
    ])
  ]);
}
elseif($ali == "send" && $chat_id == $admin){
    file_put_contents("data/$from_id/ali.txt","no");
 SendAction($chat_id,'typing');
 bot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"فرستاده شد!",
  ]);
 $all_member = fopen( "users.txt", "r");
  while( !feof( $all_member)) {
    $user = fgets( $all_member);
   SendMessage($user,$text,"html");
  }
}
elseif($text == '📟 فوروارد همگانی' && $from_id == $admin){
 save("data/".$from_id."/command.txt","fwd 2 all");
 SendMessage($chat_id,"📮 پیام مورد نظر را فوروارد کنید","html","true",$button_back);
 }
 elseif($command == 'fwd 2 all' && $from_id == $admin){
 save("data/".$from_id."/command.txt","none");
 SendMessage($chat_id,"📮 پیام شما در صف ارسال قرار گرفت.","html","true",$button_manage);
 $all_member = fopen( "users.txt", 'r');
  while( !feof( $all_member)) {
    $user = fgets( $all_member);

   forward($user,$admin,$message_id);
  }
 }
if($text == "🔙 منوی ادمین"){
    bot('sendmessage' ,[
        'chat_id'=>$admin,
        'text'=>"😎 به منوی ادمین برگشتیم ، لطفا یک گزینه را انتخاب کنید!",
        'parse_mode'=>"MarkDown",
        'reply_markup'=> json_encode ([
            'keyboard'=>[
                [
                  ['text'=>"🔙 برگشت"]
                  ],
                  [
              ['text'=>"👤 آمار"],['text'=>"🌟 تعداد چالش"]
              ],
[
['text'=>"📮 پیام همگانی"],['text'=>"📟 فوروارد همگانی"]
],
[
['text'=>"☣ تنظیم سازنده"]
],
[
['text'=>"⭕️ تنظیم تبلیغ"],['text'=>"📯 تنظیم پیام شروع"]
],
[
    ['text'=>"💰 تنظیم کانال تبلیغات"]
    ],
    [
        ['text'=>"☸ تنظیم ادمین دوم"],['text'=>"✴️ اطلاعات ادمین دوم"]
        ],
              ],
            'resize_keyboard'=>true
        ])
            ]);
}
elseif($text == "☣ تنظیم سازنده" && $from_id == $admin){
file_put_contents("data/$from_id/ali.txt","setcr");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"✅ آیدی کانال سازنده را بدون @ ارسال کن...",
]);
}elseif($ali == "setcr"){
file_put_contents("data/$from_id/ali.txt","none");
 file_put_contents("data/cr.txt",$text);
bot('sendMessage',[
    'chat_id'=>$chat_id,
    'text'=>"✴️ ثبت شد!"
    ]);
}
elseif($text == "⭕️ تنظیم تبلیغ" && $from_id == $admin){
file_put_contents("data/$from_id/ali.txt","ads");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"〽️ عدد پیامی که باید از کانال (@$cha) فروارد بشه رو بگو.",
]);
}elseif($ali == "ads"){
file_put_contents("data/$from_id/ali.txt","none");
 file_put_contents("data/id.txt",$text);
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"✅ ثبت شد...",
]);
}
elseif($text == "📯 تنظیم پیام شروع" && $from_id == $admin){
file_put_contents("data/$from_id/ali.txt","start");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"📨 متن پیام استارت رو بفرست.",
]);
}elseif($ali == "start"){
file_put_contents("data/$from_id/ali.txt","none");
 file_put_contents("data/start.txt",$text);
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"✅ متن استارت تغییر کرد...

🔸 متن کنونی : 
    $start",
    ]);
}
elseif($text == "💰 تنظیم کانال تبلیغات" && $from_id == $admin){
 file_put_contents("data/$from_id/ali.txt","ads ch");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"🌀 ایدی کانال تبلیغات را بدون @ ارسال کنید.",
]);
}
elseif($ali == "ads ch"){
file_put_contents("data/$from_id/ali.txt","none");
 file_put_contents("data/AdsCh.txt",$text);
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"🔸 تنظیم شد!",
'parse_mode'=>"MarkDown"
]);
}
elseif($text == "☸ تنظیم ادمین دوم" && $from_id == $admin){
 file_put_contents("data/$from_id/ali.txt","sudo");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"♊️ ایدی عددی ادمین دوم ربات رو ارسال کنید.",
]);
sendmessage($sudo,"👀 شما ادمین شدید برای رفتن به بخش مدیریتی کلمه `/sudo` را ارسال کنید.","MarkDown");
}
elseif($ali == "sudo"){
file_put_contents("data/$from_id/ali.txt","none");
 file_put_contents("data/sudo.txt",$text);
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"⚛ کاربر $sudo به عنوان ادمین دوم ربات در ساعت ($time) انتخاب شد.

♎️ برای رفتن به پنل مدیریت ادمین دوم کلمه /sudo را باید ادمین دوم ارسال کند ",
'parse_mode'=>"MarkDown"
]);
}
elseif($text == "/sudo"){
    bot('sendmessage' ,[
        'chat_id'=>$sudo,
        'text'=>"☑️ سلام ادمین گرامی ( [$name](tg://user?id=$sudo) ) به پنل مدیریت خودتون خوش اومدی!
🆔 @$creator",
        'parse_mode'=>"MarkDown",
        'reply_markup'=> json_encode ([
            'keyboard'=>[
                [
                  ['text'=>"🔙 برگشت"]
                  ],
                  [
              ['text'=>"👥 آمار"],['text'=>"👀 تعداد چالش"]
              ],
[
['text'=>"📨 پیام همگانی"]
],
              ],
            'resize_keyboard'=>true
        ])
            ]);
}
elseif($text == "👥 آمار" && $from_id == $sudo){
    $user = file_get_contents("users.txt");
    $member_id = explode("\n",$user);
    $member = count($member_id) -1;
 bot('sendmessage',[
'chat_id'=>$sudo,
'text'=>"😎 آمار اعضای ربات : $member",
 ]);
}
elseif($text == "👀 تعداد چالش"){
    $chall = scandir("ch");
    $all = count ($chall) -2;
    bot('sendmessage' ,[
        'chat_id'=>$sudo,
        'text'=>"🎗 تعداد کل چالش های باز : $all",
        ]);
}
elseif($text == "📨 پیام همگانی" && $chat_id == $sudo){
    file_put_contents("data/$from_id/ali.txt","send sudo");
 sendaction($chat_id,'typing');
 bot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"📮 پیام خود را به صورت متن ارسال کنید.",
    'parse_mode'=>'html',
    'reply_markup'=>json_encode([
      'keyboard'=>[
   [
['text'=>"🔙 برگشت"]
],
      ],
'resize_keyboard'=>true
    ])
  ]);
}
elseif($ali == "send sudo" && $chat_id == $sudo){
    file_put_contents("data/$from_id/ali.txt","no");
 SendAction($chat_id,'typing');
 bot('sendmessage',[
    'chat_id'=>$chat_id,
    'text'=>"📮 پیام شما ارسال شد.",
  ]);
 $all_member = fopen( "users.txt", "r");
  while( !feof( $all_member)) {
    $user = fgets( $all_member);
   SendMessage($user,$text,"html");
  }
}

unlink("error_log");

?>