<?php
define('API_KEY','#token');
function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}

@$update = json_decode(file_get_contents('php://input'));
@$message = $update->message;
@$chat_id = $message->chat->id;
@$from_id = $message->from->id;
@$first = $message->from->first_name;
@$message_id = $message->message_id;
@$text = $message->text;
@$type = $message->chat->type;
@$reply = $message->reply_to_message->from->id;

@$newmem = $message->new_chat_member;
@$leftmem = $message->left_chat_member;

@$allgp = file_get_contents("gp.txt");
@$gp_che = file_get_contents("gp/$chat_id/che.txt");
@$gp_add = file_get_contents("gp/$chat_id/add.txt");
@$gp_timer = file_get_contents("gp/$chat_id/timer.txt");
@$user_add = file_get_contents("gp/$chat_id/user/$from_id/add.txt");
@$user_addko = file_get_contents("gp/$chat_id/user/$from_id/addkon.txt");

$admin = #admin;
$botid = #bot_id; 

$ubot = "@#bot_username";
$usbot = "#bot_username";
$channel = #channel_id;


function SendMessage($chatid,$text,$parsmde,$id){
	bot('sendMessage',[
	'chat_id'=>$chatid,
	'text'=>$text,
	'parse_mode'=>$parsmde,
	'reply_to_message_id'=>$id
	]);
}
function SendMessage2($chatid,$text,$parsmde,$id){
	$b = bot('sendMessage',[
	'chat_id'=>$chatid,
	'text'=>$text,
	'parse_mode'=>$parsmde,
	'reply_to_message_id'=>$id
    ])->result->message_id;
    return $b;
}
function DelMessage($chat,$msg){
    bot('DeleteMessage',[
        'chat_id'=>$chat,
        'message_id'=>$msg
    ]);
}
function getChatMember($chat,$user){
    $b = bot('getChatMember',[
        'chat_id'=>$chat,
        'user_id'=>$user
    ])->result->status;
    return $b;
}
$rank = getChatMember($chat_id,$from_id);
$bot_rank = getChatMember($chat_id,$botid);
$ch_member = getChatMember($channel,$from_id);

if($type != "private"){
    if($newmem != null){
        $id = $newmem->id;
        $user = $newmem->is_bot;
        if($id == $botid && $user == true){
            SendMessage($chat_id,"😋 سلام سلام ، ورود خودم رو خوش آمد میگم !
            👈🏻 برای اضافه کردن گروه /add را ارسال کنید .
            ⭕️ ربات حتما حتما باید در گروه ادمین باشد . ⭕️","html",$message_id);
            return false;
        }
        if(file_exists("gp/$chat_id")){
            if(!file_exists("gp/$chat_id/user/$from_id")){
                mkdir("gp/$chat_id/user/$from_id");
                file_put_contents("gp/$chat_id/user/$from_id/add.txt","0");
                file_put_contents("gp/$chat_id/user/$from_id/addkon.txt","yes");
            }
            if($rank != "creator"){
                if($from_id != $admin){
                    if($from_id != $id){
                        if($id != $botid){
                            if($user == true){
                                SendMessage($chat_id,"⭕️ ربات ها جز افراد حساب نمی‌شوند !
                                🌐 بنابراین تعداد افراد افزوده شده توسط $first تغیری نمی‌کند !","html",$message_id);
                                return false;
                            }else{
                                $new_gp_add = $gp_add + 1;
                                file_put_contents("gp/$chat_id/add.txt",$new_gp_add);
                                $user_add = file_get_contents("gp/$chat_id/user/$from_id/add.txt");
                                $new_user_add = $user_add + 1;
                                file_put_contents("gp/$chat_id/user/$from_id/add.txt",$new_user_add);
                                if($new_user_add == $gp_che){
                                    file_put_contents("gp/$chat_id/user/$from_id/addkon.txt","no");
                                    SendMessage($chat_id,"✅ کاربر $first عزیز ، تعداد افراد افزوده شده توسط شما به حد نصاب رسید و تمامی محدودیت های گفتگو برداشته شد !","html",$message_id);
                                }
                            }
                        }
                    }
                }
            } 
        }
    }
    if($from_id != $admin){
        if($rank != "creator"){
            if(file_exists("gp/$chat_id")){
                if($leftmem != null){
                    DelMessage($chat_id,$message_id);
                    return false;
                }
                if(!file_exists("gp/$chat_id/user/$from_id")){
                    mkdir("gp/$chat_id/user/$from_id");
                    file_put_contents("gp/$chat_id/user/$from_id/add.txt","0");
                    file_put_contents("gp/$chat_id/user/$from_id/addkon.txt","yes");
                }
                $user_new_add = file_get_contents("gp/$chat_id/user/$from_id/add.txt");
                $user_new_add_kon = file_get_contents("gp/$chat_id/user/$from_id/addkon.txt");
                if($user_new_add_kon != "no" && $user_new_add < $gp_che){
                    DelMessage($chat_id,$message_id);
                    $msg = SendMessage2($chat_id,"✴️ $first عزیز 
                    برای رفع محدودیت های گفتگو باید $gp_che نفر را عضو کنید !
                    
                    شما تا به حال $user_new_add نفر را عضو کرده اید !","html");
                    sleep($gp_timer);
                    DelMessage($chat_id,$msg);
                }
            }
        }
    }
    if(strpos($allgp,"$chat_id") === false){
        file_put_contents("gp.txt",$allgp."$chat_id\n");
    }
    if($ch_member != "creator" && $ch_member != "administrator" && $ch_member != "member" && $rank == "creator"){
        SendMessage($chat_id,"🌐 برای استفاده از ربات باید در کانال ما عضو شوید !
        
        🆔 @SaleAntiSpam","html",$message_id);
        return false;
    }
    if(preg_match('/^\/([Nn]o[Aa]dd)/s',$text) && $rank == "creator" && $reply != null && $reply != $botid && $reply != $admin){
        if(file_exists("gp/$chat_id")){
            if(!file_exists("gp/$chat_id/user/$reply")){
                mkdir("gp/$chat_id/user/$reply");
                file_put_contents("gp/$chat_id/user/$reply/add.txt","0");
                file_put_contents("gp/$chat_id/user/$reply/addkon.txt","no");
            }
            file_put_contents("gp/$chat_id/user/$reply/addkon.txt","no");
            SendMessage($chat_id,"📊 تمامی محدودیت های کاربر $reply برداشته شد !","html",$message_id);
        }else{
            SendMessage($chat_id,"⭕️ گروه به لیست گروه ها اضافه نشده است ، جهت اضافه کردن /add را ارسال کنید !","html",$message_id);
        }
    }
    if(preg_match('/^\/([Yy]es[Aa]dd)/s',$text) && $rank == "creator" && $reply != null && $reply != $botid && $reply != $admin){
        if(file_exists("gp/$chat_id")){
            if(!file_exists("gp/$chat_id/user/$reply")){
                mkdir("gp/$chat_id/user/$reply");
                file_put_contents("gp/$chat_id/user/$reply/add.txt","0");
                file_put_contents("gp/$chat_id/user/$reply/addkon.txt","yes");
            }
            $user_new_yes_add = file_get_contents("gp/$chat_id/user/$reply/add.txt");
            if($user_new_yes_add > $gp_che){
                SendMessage($chat_id,"⭕️ تعداد افراد افزوده شده توسط $reply به حد نصاب رسیده است و شما نمی‌توانید ایشان را محدود کنید !","html",$message_id);
                return false;
            }
            file_put_contents("gp/$chat_id/user/$reply/addkon.txt","yes");
            SendMessage($chat_id,"🌐 کاربر $reply باموفقیت محدود شد !","html",$message_id);
        }else{
            SendMessage($chat_id,"⭕️ گروه به لیست گروه ها اضافه نشده است ، جهت اضافه کردن /add را ارسال کنید !","html",$message_id);            
        }
    }
    if(preg_match('/^\/([Tt]imer) (.*)/',$text) && $rank == "creator"){
        if(file_exists("gp/$chat_id")){
            preg_match('/^\/([Tt]imer) (.*)/',$text,$match);
            $time = $match[2];
            if(preg_match('/^([0-9])/',$time) && $time != 0 && $time < 10){
                $new_time = $time + 3;
                file_put_contents("gp/$chat_id/timer.txt",$new_time);
                SendMessage($chat_id,"❇️ تایم حذف پیام باموفقیت به $time تغیر کرد !","html",$message_id);
            }else{
                SendMessage($chat_id,"🌐 فقط اعداد انگلیسی ، عدد مورد نظر نباید بیشتر از 10 باشد و 0 هم نمیتواند باشد !","html",$message_id);
            }
        }else{
            SendMessage($chat_id,"⭕️ گروه به لیست گروه ها اضافه نشده است ، جهت اضافه کردن /add را ارسال کنید !","html",$message_id);
        }
    }
    if(preg_match('/^\/([Ss]et[Aa]dd) (.*)/',$text) && $rank == "creator"){
        if(file_exists("gp/$chat_id")){
            preg_match('/^\/([Ss]et[Aa]dd) (.*)/',$text,$match);
            $new_add = $match[2];
            if(preg_match('/^([0-9])/',$new_add) && $new_add != 0 && $new_add < 20){
                file_put_contents("gp/$chat_id/che.txt",$new_add);
                SendMessage($chat_id,"❇️ محدودیت افزودن اعضا باموفقیت به $new_add تغیر کرد !","html",$message_id);
            }else{
                SendMessage($chat_id,"🌐 فقط اعداد انگلیسی ، عدد مورد نظر نباید بیشتر از 20 باشد و 0 هم نمیتواند باشد !","html",$message_id);
            }
        }else{
            SendMessage($chat_id,"⭕️ گروه به لیست گروه ها اضافه نشده است ، جهت اضافه کردن /add را ارسال کنید !","html",$message_id);
        }
    }
    if($text == "/settings" || $text == "/settings".$ubot){
        if(file_exists("gp/$chat_id")){
            if($rank == "creator"){
                bot('Sendmessage',[
                    'chat_id'=>$chat_id,
                    'text'=>"👤✅ ادمین عزیز. می‌توانید از پنل زیر تنظیمات گروه خود را مشاهده کنید.",
                    'parse_mode'=>"html",
                    'reply_markup'=>json_encode([
                        'inline_keyboard'=>[
                            [['text'=>"♨️ تامیر حذف پیام",'callback_data'=>"s"],['text'=>($gp_timer - 3),'callback_data'=>"s"]],
                            [['text'=>"👤 اعضا افزوده شده",'callback_data'=>"s"],['text'=>"$gp_add",'callback_data'=>"s"]],
                            [['text'=>"👮🏻 محدودیت افزودن ",'callback_data'=>"s"],['text'=>"$gp_che",'callback_data'=>"s"]],
                            [['text'=>"➖ ➖ ➖ ➖ ➖ ➖ ➖ ➖ ➖",'callback_data'=>"s"]],
                            [['text'=>"🗯 پشتیبانی ",'url'=>"https://t.me/PvResanM_Bot"]]              
                        ]
                    ])
                ]);
            }
        }else{
            SendMessage($chat_id,"⭕️ گروه به لیست گروه ها اضافه نشده است ، جهت اضافه کردن /add را ارسال کنید !","html",$message_id);
        }
    }
    if($text == "/add" || $text == "/add".$ubot){
        if($rank == "creator"){
           if($bot_rank != "member"){
               if(!file_exists("gp/$chat_id")){
                   mkdir("gp/$chat_id");
                   mkdir("gp/$chat_id/user");
                   file_put_contents("gp/$chat_id/add.txt","0");
                   file_put_contents("gp/$chat_id/che.txt","2");
                   file_put_contents("gp/$chat_id/timer.txt","5");
                   SendMessage($chat_id,"✅ گروه با موفقیت افزوده شد !
                   👈🏻 جهت دیدن راهنما دستور /help را ارسال کنید !","html");
               }else{
                SendMessage($chat_id,"📊 گروه از قبل اضافه شده بوده است !","html",$message_id);
               }
           }else{
            SendMessage($chat_id,"⭕️ ابتدا ربات را در گروه ادمین کند سپس دستور /add را ارسال کنید !","html",$message_id);
           }
        }
    }
    if($text == "/help" || $text == "/help".$ubot){
        if(file_exists("gp/$chat_id")){
            if($rank == "creator"){
                SendMessage($chat_id,"⚠️ به بخش راهنما خوش آمدید !


💠 /add
💠 با زدن این دستور ربات در گروه شما شروع به کار می‌کند !

💠 /settings
💠 با زدن این دستور اطلاعات گروه و تعداد افراد افزوده شده و... به شما داده می‌شود !

💠 /noadd
💠 با زدن این دستور و ریپلای کردن روی پیام شخص مورد نظر ، محدودیت های آن شخص بدون آنکه فردی را عضو گروه کرده باشد برداشته می‌شود !

💠 /yesadd
💠 با زدن این دستور و ریپلای روی پیام فرد مورد نظر ، آن شخص محدود شده و مجبور به افزودن افراد می‌شود !

💠 /timer [NUM]
💠 با زدن این دستور میتوانید تایمر حذف پیام را به حسب ثانیه کنترل کنید !
برای مثال : 
/timer 3


💠 /setadd [NUM]
💠 با زدن این دستور میتوانید تعداد افرادی که باید عضو گروه شوند تا محدودیت برداشته شود را مدیریت کنید !
برای مثال:
/setadd 2


💠 /help
💠 با زدن این دستور همین متن را دریافت میکنید !","html",$message_id);
            }
        }else{
            SendMessage($chat_id,"⭕️ گروه به لیست گروه ها اضافه نشده است ، جهت اضافه کردن /add را ارسال کنید !","html",$message_id);
        }
    }
}
if($type == "private"){
    if($ch_member != "creator" && $ch_member != "administrator" && $ch_member != "member"){
        SendMessage($chat_id,"🌐 برای استفاده از ربات باید در کانال ما عضو شوید !
        
        🆔 @SaleAntiSpam","html",$message_id);
        return false;
    }
    if($text == "/start"){
        if(strpos($allgp,"$chat_id") === false){
            file_put_contents("gp.txt",$allgp."$chat_id\n");
        }
        bot('SendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"سلام $first عزیز 😋
    🗯 به ربات اد کن گروه خوش اومدی!
    
    + این ربات چه کاری انجام میده؟
    - با افزودن این ربات به گروه خود اعضا باید تعدادی را در گروه عضو کنند تا بتوانند با یکدیگر گفتگو کنند!
    
    + آیا این ربات امن هست؟!
    - بله کاملا امن هست. اطلاعات شما پیش ما محفوظ است!
    
    - چجوری باید باهاش کار کنم؟
    + با استفاده از دکمه شیشه ای پایین ربات را به گروه خود برده و بعد ربات را ادمین کنید سپس دستور
    /add
    را در گروه ارسال کنید. ربات خودش همه کارها را بصورت خودکار انجام ‌می‌دهد!
    
    👤 برنامه نویس: @LastSudo",
    'parse_mode'=>"html",
    'reply_to_message_id'=>$message_id,
    'reply_markup'=>json_encode([
    'inline_keyboard'=>[
         [['text'=>"🗯 اضافه کردن به گروه!",'url'=>"http://telegram.me/".$usbot."?startgroup=new"]],
         [['text'=>"👤 پشتیبانی ",'url'=>"http://t.me/PvResanM_Bot"]],
         [['text'=>"📢 کانال ما ",'url'=>"https://t.me/SaleAntiSpam"]]
         ]
      ])
     ]);
    }
}
unlink("error_log");
?>