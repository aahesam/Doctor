<?php

set_time_limit(0);

ob_start();

include("jdf.php");

$API_KEY = '[*[TOKEN]*]';
##------------------------------##
define('API_KEY', $API_KEY);
function bot($method, $datas = [])
{
    $url = "https://api.telegram.org/bot" . API_KEY . "/" . $method;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $datas);
    $res = curl_exec($ch);
    if (curl_error($ch)) {
        var_dump(curl_error($ch));
    } else {
        return json_decode($res);
    }
}

function sendmessage($chat_id, $text)
{
    bot('sendMessage', [
        'chat_id' => $chat_id,
        'text' => $text,
        'parse_mode' => "MarkDown"
    ]);
}

function deletemessage($chat_id, $message_id)
{
    bot('deletemessage', [
        'chat_id' => $chat_id,
        'message_id' => $message_id,
    ]);
}

function sendaction($chat_id, $action)
{
    bot('sendchataction', [
        'chat_id' => $chat_id,
        'action' => $action
    ]);
}

function Forward($KojaShe, $AzKoja, $KodomMSG)
{
    bot('ForwardMessage', [
        'chat_id' => $KojaShe,
        'from_chat_id' => $AzKoja,
        'message_id' => $KodomMSG
    ]);
}

function sendphoto($chat_id, $photo, $action)
{
    bot('sendphoto', [
        'chat_id' => $chat_id,
        'photo' => $photo,
        'action' => $action
    ]);
}

function objectToArrays($object)
{
    if (!is_object($object) && !is_array($object)) {
        return $object;
    }
    if (is_object($object)) {
        $object = get_object_vars($object);
    }
    return array_map("objectToArrays", $object);
}


//====================$hadi======================//
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$channel_post = $update->message->channel_post;
$code = file_get_contents("data/code.txt");
$code2 = file_get_contents("data/code2.txt");
$chid = $update->channel_post->message->message_id;
$chat_id = $message->chat->id;
$message_id = $message->message_id;
$from_id = $message->from->id;
$c_id = $message->forward_from_chat->id;
$forward_id = $update->message->forward_from->id;
$forward_chat = $update->message->forward_from_chat;
$forward_chat_username = $update->message->forward_from_chat->username;
$forward_chat_msg_id = $update->message->forward_from_message_id;
@$shoklt = file_get_contents("data/$chat_id/shoklat.txt");
@$penlist = file_get_contents("data/pen.txt");
$text = $message->text;
@mkdir("data/$chat_id");
@$ali = file_get_contents("data/$chat_id/ali.txt");
@$list = file_get_contents("users.txt");
$ADMIN = [*[ADMIN]*];
$idbot = file_get_contents("data/idbot.txt");
$uadmin = adaminsss;
$frosh = file_get_contents("data/frosh.txt");
$channel = file_get_contents("data/channel.txt");
$hadi = file_get_contents("data/almasi.txt");
$rah = file_get_contents("data/rah.txt");
$gh = file_get_contents("data/gh.txt");
$def = file_get_contents("data/gha.txt");
$channe2l = file_get_contents("data/channel2.txt");
$listbon = file_get_contents("data/pen.txt");
$chatid = $update->callback_query->message->chat->id;
$data = $update->callback_query->data;
$message_id2 = $update->callback_query->message->message_id;
$fromm_id = $update->inline_query->from->id;
$fromm_user = $update->inline_query->from->username;
$inline_query = $update->inline_query;
$query_id = $inline_query->id;
$fatime = jdate("h:i:s");
$fadate = jdate("Y F d");
//====================$hadi======================//
if ($text == "/start") {

        $user = file_get_contents('users.txt');
        $members = explode("\n", $user);
        if (!in_array($from_id, $members)) {
            $add_user = file_get_contents('users.txt');
            $add_user .= $from_id . "\n";
            file_put_contents("data/$chat_id/membrs.txt", "0");
            file_put_contents("data/$chat_id/shoklat.txt", "10");
            file_put_contents('users.txt', $add_user);
        }
        file_put_contents("data/$chat_id/ali.txt", "no");
        sendAction($chat_id, 'typing');
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "🎈 سلام به ربات ممبر گیر خوش اومدید.
شما با این ربات میتونی کلی ممبر بگیرید🎈 

👇یک گزینه را انتخاب کنید👇",
            'parse_mode' => "MarkDown",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "🗳جمع کردن الماس💎", 'callback_data' => "a"], ['text' => "📍ثبت ممبر📍", 'callback_data' => "m"]
                        ],
                        [
['text' => "📦 طرح ویژه 📦", 'callback_data' => "t"], ['text' => "📌عملیات های من📌", 'callback_data' => "d"]
                         ],
                                         [
['text' => "💳 خرید الماس💳", 'callback_data' => "f"]
                         ],
                         [
['text' => "📒راهنما📒", 'callback_data' => "rah"],['text' => "📂قوانین📁", 'callback_data' => "gha"]
                         ],
                         [
                        ['text' => "📪پشتیبانی ربات📫", 'url' => "https://telegram.me/$def"]
                    ],
                    
                ]
            ])
        ]);
    } elseif (strpos($penlist, "$from_id")) {
        SendMessage($chat_id, "کاربر گرامی شما از سرور ما مسدود شده اید لطفا دیگر پیام نفرستید
باتشکر
اگر اشتباهی مسدود شدید به مدیریت خبر دهید تا شمارا ازاد کند
@adamimsss 👈ادمین");
    } elseif (strpos($text, '/start') !== false && $forward_chat_username == null) {
        $newid = str_replace("/start ", "", $text);
        if ($from_id == $newid) {
            bot('sendMessage', [
                'chat_id' => $chat_id,
                'text' => "شما نمی توانید با لینک دعوت خود عضو ربات شوید و سکه ای دریافت نمی کنید✅",
            ]);
        } elseif (strpos($list, "$from_id") !== false) {
            SendMessage($chat_id, "شما قبلا در این ربات عضو شده بودید و نمی توانید با لینک اختصاصی دوستتان عضو ربات شوید");
        } else {
            sendAction($chat_id, 'typing');
            @$sho = file_get_contents("data/$newid/shoklat.txt");
            $getsho = $sho + 10;
            file_put_contents("data/$newid/shoklat.txt", $getsho);
            @$sea = file_get_contents("data/$newid/membrs.txt");
            $getsea = $sea + 1;
            file_put_contents("data/$newid/membrs.txt", $getsea);
            $user = file_get_contents('users.txt');
            $members = explode("\n", $user);
            if (!in_array($from_id, $members)) {
                $add_user = file_get_contents('users.txt');
                $add_user .= $from_id . "\n";
                file_put_contents("data/$chat_id/membrs.txt", "0");
                file_put_contents("data/$chat_id/shoklat.txt", "10");
                file_put_contents('users.txt', $add_user);
            }
            file_put_contents("data/$chat_id/ali.txt", "No");
            sendmessage($chat_id, "تبریک شما با دعوت کاربر $newid عضو ربات ما شدید❤️");
            bot('sendmessage', [
                'chat_id' => $chat_id,
                'text' => "🎈 سلام به ربات ممبر گیر خوش اومدید.
شما با این ربات میتونی کلی ممبر بگیرید🎈 

👇یک گزینه را انتخاب کنید👇",
                'parse_mode' => "MarkDown",
                'reply_markup' => json_encode([
                    'inline_keyboard' => [
                        [
['text' => "🗳جمع کردن الماس💎", 'callback_data' => "a"], ['text' => "📍ثبت ممبر📍", 'callback_data' => "m"]
                        ],
                        [
['text' => "📦 طرح ویژه 📦", 'callback_data' => "t"], ['text' => "📌عملیات های من📌", 'callback_data' => "d"]
                         ],
                         [
['text' => "💳 خرید الماس💳", 'callback_data' => "f"]
                         ],
                         [
['text' => "📒راهنما📒", 'callback_data' => "rah"],['text' => "📂قوانین📁", 'callback_data' => "gh"]
                         ],
                         [
                        ['text' => "📪پشتیبانی ربات📫", 'url' => "https://telegram.me/$def"]
                    ],
                         
                    ]
                ])
            ]);
            SendMessage($newid, "تبریک یکی با لینک اختصاصی شما وارد ربات شد و ??10
الماس دریافت کردید");
        }
    }
    elseif ($data == "home") {
    unlink("cod/$chatid.txt");
        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "کمی صبر کنید",
            'show_alert' => false
        ]);
        file_put_contents("data/$chatid/ali.txt", "no");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "منوی اصلی 

☑️ یک گزینه رو انتخاب کن ☑️",
            'parse_mode' => "MarkDown",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "🗳جمع کردن الماس💎", 'callback_data' => "a"], ['text' => "📍ثبت ممبر📍", 'callback_data' => "m"]
                        ],
                        [
['text' => "📦 طرح ویژه 📦", 'callback_data' => "t"], ['text' => "📌عملیات های من📌", 'callback_data' => "d"]
                         ],
                         [
['text' => "💳 خرید الماس💳", 'callback_data' => "f"]
                         ],
                         [
['text' => "📒راهنما📒", 'callback_data' => "rah"],['text' => "📂قوانین📁", 'callback_data' => "gh"]
                         ],
                         [
                        ['text' => "📪پشتیبانی ربات📫", 'url' => "https://telegram.me/$def"]
                    ],
                         
                ]
            ])
        ]);
    } elseif ($data == "a") {
        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "یه لحظه صبر کن",
            'show_alert' => false
        ]);
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "💎 الماس بگیر 💎

☑️ یک گزینه رو انتخاب کن ☑️",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "🆔کانال ببین الماس بگیر💎", 'url' => "https://telegram.me/$hadi"]
                    ],
                    [
 ['text' => "📢دریافت10الماس برای عضویت کانال📢", 'url' => "https://telegram.me/$hadi"]
                    ],
                    [
['text' => "🛍فروشگاه💎", 'callback_data' => "f"], ['text' => "❤معرفی💎", 'callback_data' => "b"]
                    ],
                    [
                        ['text' => "🔚بازگشت🔚", 'callback_data' => "home"]
                    ]
                ]
            ])
        ]);
    } elseif ($data == "k") {
        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "کمی صبر کنید",
            'show_alert' => false
        ]);
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "&",
            'reply_markup' => $ptn
        ]);
    } elseif ($data == "1") {
        $myfile2 = fopen("cod/$chatid.txt", "a") or die("Unable to open file!");
        fwrite($myfile2, " ");
        fclose($myfile2);
        $cod = file_get_contents("cod/$chatid.txt");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "membar",
            'reply_markup' => $ptn
        ]);
    } elseif ($data == "2") {
        $myfile2 = fopen("cod/$chatid.txt", "a") or die("Unable to open file!");
        fwrite($myfile2, " ");
        fclose($myfile2);
        $cod = file_get_contents("cod/$chatid.txt");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => ",
",
            'reply_markup' => $ptn
        ]);
    } elseif ($data == "3") {
        $myfile2 = fopen("cod/$chatid.txt", "a") or die("Unable to open file!");
        fwrite($myfile2, ",");
        fclose($myfile2);
        $cod = file_get_contents("cod/$chatid.txt");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "
",
            'reply_markup' => $ptn
        ]);
    } elseif ($data == "4") {
        $myfile2 = fopen("cod/$chatid.txt", "a") or die("Unable to open file!");
        fwrite($myfile2, ",");
        fclose($myfile2);
        $cod = file_get_contents("cod/$chatid.txt");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => ",
",
            'reply_markup' => $ptn
        ]);
    } elseif ($data == "5") {
        $myfile2 = fopen("cod/$chatid.txt", "a") or die("Unable to open file!");
        fwrite($myfile2, "5");
        fclose($myfile2);
        $cod = file_get_contents("cod/$chatid.txt");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => ",",
            'reply_markup' => $ptn
        ]);
    } elseif ($data == "6") {
        $myfile2 = fopen("cod/$chatid.txt", "a") or die("Unable to open file!");
        fwrite($myfile2, " ");
        fclose($myfile2);
        $cod = file_get_contents("cod/$chatid.txt");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => ",",
            'reply_markup' => $ptn
        ]);
    } elseif ($data == "7") {
        $myfile2 = fopen("cod/$chatid.txt", "a") or die("Unable to open file!");
        fwrite($myfile2, " ");
        fclose($myfile2);
        $cod = file_get_contents("cod/$chatid.txt");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => ",",
            'reply_markup' => $ptn
        ]);
    } elseif ($data == "8") {
        $fromm_id = $update->inline_query->from->id;
        $myfile2 = fopen("cod/$chatid.txt", "a") or die("Unable to open file!");
        fwrite($myfile2, " ");
        fclose($myfile2);
        $cod = file_get_contents("cod/$chatid.txt");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => ",",
            'reply_markup' => $ptn
        ]);
    } elseif ($data == "0") {
        $myfile2 = fopen("cod/$chatid.txt", "a") or die("Unable to open file!");
        fwrite($myfile2, " ");
        fclose($myfile2);
        $cod = file_get_contents("cod/$chatid.txt");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => ",",
            'reply_markup' => $ptn
        ]);
    } elseif ($data == "0") {
        $myfile2 = fopen("cod/$chatid.txt", "a") or die("Unable to open file!");
        fwrite($myfile2, " ");
        fclose($myfile2);
        $cod = file_get_contents("cod/$chatid.txt");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => ",",
            'reply_markup' => $ptn
        ]);
    } elseif ($data == "chk") {
        $fromm_id = $update->inline_query->from->id;
        $ct = file_get_contents("cod/$chatid.txt");
        $jd = file_get_contents("data/code2.txt");
        if ($cod == $code && $cod != null) {
            @$sho = file_get_contents("data/$chatid/shoklat.txt");
            $getsho = $sho + $rsf;
            file_put_contents("data/$chatid/shoklat.txt", $getsho);
            unlink("cod/$chatid.txt");
            file_put_contents("data/code.txt", "");
            file_put_contents("data/code2.txt", "");
            bot('answercallbackquery', [
                'callback_query_id' => $update->callback_query->id,
                'text' => "#############267864377777477887----++++#####",
                'show_alert' => true
            ]);
            bot('sendMessage', [
                'chat_id' => @ssstim,
                'text' => ".",

            ]);
            file_put_contents("data/$chatid/ali.txt", "no");
            bot('editmessagetext', [
                'chat_id' => $chatid,
                'message_id' => $message_id2,
                'text' => "منوی اصلی 

☑️ یک گزینه رو انتخاب کن ☑️",
                'parse_mode' => "MarkDown",
                'reply_markup' => json_encode([
                    'inline_keyboard' => [
                       [
['text' => "🗳جمع کردن الماس💎", 'callback_data' => "a"], ['text' => "📍ثبت ممبر📍", 'callback_data' => "m"]
                        ],
                        [
['text' => "📦 طرح ویژه 📦", 'callback_data' => "t"], ['text' => "📌عملیات های من📌", 'callback_data' => "d"]
                         ],
                         
                 ]
                ])
            ]);
        } else {
            unlink("cod/$chatid.txt");
            bot('answercallbackquery', [
                'callback_query_id' => $update->callback_query->id,
                'text' => "skip",
                'show_alert' => true
            ]);
            file_put_contents("data/$chatid/ali.txt", "no");
            bot('editmessagetext', [
                'chat_id' => $chatid,
                'message_id' => $message_id2,
                'text' => "منوی اصلی 

☑️ یک گزینه رو انتخاب کن ☑️",
                'parse_mode' => "MarkDown",
                'reply_markup' => json_encode([
                    'inline_keyboard' => [
                        [
['text' => "🗳جمع کردن الماس💎", 'callback_data' => "a"], ['text' => "📍ثبت ممبر📍", 'callback_data' => "m"]
                        ],
                        [
['text' => "📦 طرح ویژه 📦", 'callback_data' => "t"], ['text' => "📌عملیات های من📌", 'callback_data' => "d"]
                         ],
                 
                    ]
                ])
            ]);
        }
     } elseif ($data == "b") {
        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "کمی صبر کنید",
            'show_alert' => false
        ]);
        bot('sendmessage', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "عضو برای کانالت میخوای؟😃
اونم به صورت کاملا واقعی و رایگان؟😳🤤

پس بدو بیا ربات زیر امتحان کن اگه واقعی نبود پاک کن👇👇
 لینک ورود :
http://telegram.me/[*[botid]*]?start=$chatid",
        ]);
        bot('sendmessage', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "😎 هر کاربری👤 که با
لینکت👆وارد ربات شه
۱۰ الماس 💎🎁 بهت داده  میشه

☑️یک گزینه رو انتخاب کن ☑️",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "🔚برگشت🔚", 'callback_data' => "home"]
                    ],
                ]
            ])
        ]);
    } elseif ($data == "d") {
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "👑 داشبورد 👑 

☑️ یک گزینه رو انتخاب کن ☑️",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "💎الماس های من💎", 'callback_data' => "c"]
                    ],
                    [
                        ['text' => "💵خرید💵", 'callback_data' => "char"], ['text' => "↔️ انتقال‌ها ↔️", 'callback_data' => "gogem"]
                   ],
                   [
                        ['text' => "بازگشت🔚", 'callback_data' => "home"]
                    ],
                ]
            ])
        ]);
    } elseif ($data == "char") {
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "💵 خریدها 💵

ا********************
☑️ یک گزینه رو انتخاب کن ☑️",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "بازگشت🔚", 'callback_data' => "home"]
                    ],
                ]
            ])
        ]);

    } elseif ($data == "gogem") {
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "↔️ انتقال‌ها ↔️

ا********************

☑️ یک گزینه رو انتخاب کن ☑️",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "بازگشت🔚", 'callback_data' => "home"]
                    ],
                ]
            ])
       ]);
    } elseif ($data == "t") {
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "🎗طرح‌طلایی🎗

طرح‌طلایی🎗فعال نیست ❌

✅ با داشتن طرح‌طلایی🎗به ازای عضویت در هر کانال 🆔 دو الماس 💎 دریافت می‌کنید

☑️ یک گزینه رو انتخاب کن ☑️",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "بازگشت🔚", 'callback_data' => "home"], ['text' => "🎗خریدطرح‌طلایی", 'url' => "http://telegram.me/$def"]
                    ],
                ]
            ])
       ]);
    } elseif ($data == "f") {
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "$frosh
@",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "بازگشت به منوی اصلی ", 'callback_data' => "home"]
                   ],
                ]
            ])
        ]);
    } elseif ($data == "c") {
        @$sho = file_get_contents("data/$chatid/shoklat.txt");
        @$sea = file_get_contents("data/$chatid/membrs.txt");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "الماس‌های من : 💎 $sho 💎

شناسه شما : $chatid

☑️ یک گزینه رو انتخاب کن ☑️",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "🔚بازگشت🔚", 'callback_data' => "home"]
                    ],
                ]
            ])
        ]);
    } elseif ($data == "d") {
        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "کمی صبر کنید",
            'show_alert' => false
        ]);
        file_put_contents("data/$chatid/ali.txt", "for");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "لطفا پیامی از کاربری که میخواهید برایش الماس انتقال دهید بفرستید✅💎",
        ]);
    } elseif ($ali == "for") {
        if ($from_id == $forward_id) {
            SendMessage($chat_id, "شرمنده پیام خودتون را برام فروارد نکنید☹️️");
        } else {
            if (strpos($list, "$forward_id") !== false) {
                file_put_contents("data/$chat_id/ali.txt", "fore");
                file_put_contents("data/$chat_id/for.txt", $forward_id);
                bot('sendMessage', [
                    'chat_id' => $chat_id,
                    'text' => "خوب چه مقدار الماس💎 میخواهید برای کاربر $forward_id انتقال بدید😊 ",
                    'reply_markup' => json_encode([
                        'inline_keyboard' => [
                            [
                                ['text' => "ولش بریم منوی اصلی🙃", 'callback_data' => "home"]
                            ],
                        ]
                    ])
                ]);
            } else {
                SendMessage($chat_id, "شرمنده این کاربر در ربات ما عضو نمیباشد☹️");
            }
        }
    } elseif ($ali == "fore") {
        if (preg_match('/^([0-9])/', $text)) {
            if ($shoklt > $text) {
                $fr = file_get_contents("data/$chat_id/for.txt");
                $fle = file_get_contents("data/$fr/shoklat.txt");
                $fl = file_get_contents("data/$chat_id/shoklat.txt");
                $s = $text;
                $getsh = $fl - $s;
                file_put_contents("data/$chat_id/shoklat.txt", $getsh);
                SendMessage($chat_id, "الماس💎 های شما با موفقیت به کاربر مورد نظر شما انتقال داده شدند");
                $getshe = $fle + $s;
                file_put_contents("data/$fr/shoklat.txt", $getshe);
                SendMessage($fr, "تبریک کاربر $chat_id برای شما $text الماس انتقال داد💎🙃");
            } else {
                SendMessage($chat_id, "ببخشید الماس های شما کافی نیست
حداقل باید 1الماس💎
داشته باشید و‌شما ندارید");
            }
        } else {
            SendMessage($chat_id, "خوب کاربر عزیز یه عدد فقط بصورت لاتین بفرستید 😶");
        }
    } elseif ($data == "m") {
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "📍به بخش ثبت سفارش ممبر خوش آمدید📍

✔️لطفا انتخاب کنید چند ممبر میخواهید هر ممبر برابر با 2الماس هست می باشد✔️",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "20ممبر👥", 'callback_data' => "seen20"], ['text' => "45ممبر👥", 'callback_data' => "seen45"], ['text' => " 80ممبر👥", 'callback_data' => "seen80"]
                    ],
                    [
                        ['text' => "130ممبر👥", 'callback_data' => "seen130"], ['text' => "240ممبر👥", 'callback_data' => "seen240"], ['text' => "300ممبر👥", 'callback_data' => "seen300"]
                    ],
                    [
                        ['text' => "برگشت به منوی اصلی ", 'callback_data' => "home"]
                    ],
                ]
            ])
        ]);
    }
    elseif ($data == "rah") {
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "راهنما👇
$rah",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "بازگشت🔚", 'callback_data' => "home"]
                    ],
                ]
            ])
        ]);

    }
    elseif ($data == "gh") {
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "قوانین👇
$gh",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "بازگشت🔚", 'callback_data' => "home"]
                    ],
                ]
            ])
        ]);

    }
        elseif ($data == "seen20") {
        file_put_contents("data/$chatid/ted.txt", "20");
        $aaa = file_get_contents("data/$chatid/ted.txt");
        $shoklt = file_get_contents("data/$chatid/shoklat.txt");
        if ($shoklt > $aaa) {
            bot('answercallbackquery', [
                'callback_query_id' => $update->callback_query->id,
                'text' => "کمی صبر کنید",
                'show_alert' => false
            ]);
            file_put_contents("data/$chatid/ali.txt", "seen2");

            bot('editmessagetext', [
                'chat_id' => $chatid,
                'message_id' => $message_id2,
                'text' => "1⃣این ربات رو ادمین چنلی که میخوای واسش ممبر بگیری کن
2⃣ برای بالا رفتن کیفیت ممبر دهی 
اول یوزنیم چنلتون رو بدون @ به یک چنل عمومی بفرستید سپس به این ربات فروارد کنید


یوزنیم حتما باید بدون @باشد برای مثال
$channel
باید نوشته بشه: $hadi",
            ]);
        } else {
            bot('answercallbackquery', [
                'callback_query_id' => $update->callback_query->id,
                'text' => "ببخشید تعداد الماس های شما برای دریافت ممبر کافی نیست❌",
                'show_alert' => true
            ]);
        }
    } elseif ($data == "seen45") {
        file_put_contents("data/$chatid/ted.txt", "45");
        $aaa = file_get_contents("data/$chatid/ted.txt");
        $shoklt = file_get_contents("data/$chatid/shoklat.txt");
        if ($shoklt > $aaa) {
            bot('answercallbackquery', [
                'callback_query_id' => $update->callback_query->id,
                'text' => "کمی صبر کنید",
                'show_alert' => false
            ]);
            file_put_contents("data/$chatid/ali.txt", "seen2");

            bot('editmessagetext', [
                'chat_id' => $chatid,
                'message_id' => $message_id2,
                'text' => "1⃣این ربات رو ادمین چنلی که میخوای واسش ممبر بگیری کن
2⃣ برای بالا رفتن کیفیت ممبر دهی 
اول یوزنیم چنلتون رو بدون @ به یک چنل عمومی بفرستید سپس به این ربات فروارد کنید


یوزنیم حتما باید بدون @باشد برای مثال
$channel
باید نوشته بشه: $hadi",
            ]);
        } else {
            bot('answercallbackquery', [
                'callback_query_id' => $update->callback_query->id,
                'text' => "ببخشید تعداد الماس های شما برای دریافت ممبر کافی نیست❌",
                'show_alert' => true
            ]);
        }
    } elseif ($data == "seen80") {
        file_put_contents("data/$chatid/ted.txt", "80");
        $aaa = file_get_contents("data/$chatid/ted.txt");
        $shoklt = file_get_contents("data/$chatid/shoklat.txt");
        if ($shoklt > $aaa) {
            bot('answercallbackquery', [
                'callback_query_id' => $update->callback_query->id,
                'text' => "کمی صبر کنید",
                'show_alert' => false
            ]);
            file_put_contents("data/$chatid/ali.txt", "seen2");

            bot('editmessagetext', [
                'chat_id' => $chatid,
                'message_id' => $message_id2,
                'text' => "1⃣این ربات رو ادمین چنلی که میخوای واسش ممبر بگیری کن
2⃣ برای بالا رفتن کیفیت ممبر دهی 
اول یوزنیم چنلتون رو بدون @ به یک چنل عمومی بفرستید سپس به این ربات فروارد کنید


یوزنیم حتما باید بدون @باشد برای مثال
$channel
باید نوشته بشه: $hadi",
            ]);
        } else {
            bot('answercallbackquery', [
                'callback_query_id' => $update->callback_query->id,
                'text' => "ببخشید تعداد الماس های شما برای دریافت ممبر کافی نیست❌",
                'show_alert' => true
            ]);
        }
    } elseif ($data == "seen130") {
        file_put_contents("data/$chatid/ted.txt", "130");
        $aaa = file_get_contents("data/$chatid/ted.txt");
        $shoklt = file_get_contents("data/$chatid/shoklat.txt");
        if ($shoklt > $aaa) {
            bot('answercallbackquery', [
                'callback_query_id' => $update->callback_query->id,
                'text' => "کمی صبر کنید",
                'show_alert' => false
            ]);
            file_put_contents("data/$chatid/ali.txt", "seen2");

            bot('editmessagetext', [
                'chat_id' => $chatid,
                'message_id' => $message_id2,
                'text' => "1⃣این ربات رو ادمین چنلی که میخوای واسش ممبر بگیری کن
2⃣ برای بالا رفتن کیفیت ممبر دهی 
اول یوزنیم چنلتون رو بدون @ به یک چنل عمومی بفرستید سپس به این ربات فروارد کنید


یوزنیم حتما باید بدون @باشد برای مثال
$channel
باید نوشته بشه: $hadi",
            ]);
        } else {
            bot('answercallbackquery', [
                'callback_query_id' => $update->callback_query->id,
                'text' => "ببخشید تعداد الماس های شما برای دریافت ممبر کافی نیست❌",
                'show_alert' => true
            ]);
        }
    } elseif ($data == "seen240") {
        file_put_contents("data/$chatid/ted.txt", "240");
        $aaa = file_get_contents("data/$chatid/ted.txt");
        $shoklt = file_get_contents("data/$chatid/shoklat.txt");
        if ($shoklt > $aaa) {
            bot('answercallbackquery', [
                'callback_query_id' => $update->callback_query->id,
                'text' => "کمی صبر کنید",
                'show_alert' => false
            ]);
            file_put_contents("data/$chatid/ali.txt", "seen2");

            bot('editmessagetext', [
                'chat_id' => $chatid,
                'message_id' => $message_id2,
                'text' => "1⃣این ربات رو ادمین چنلی که میخوای واسش ممبر بگیری کن
2⃣ برای بالا رفتن کیفیت ممبر دهی 
اول یوزنیم چنلتون رو بدون @ به یک چنل عمومی بفرستید سپس به این ربات فروارد کنید


یوزنیم حتما باید بدون @باشد برای مثال
$channel
باید نوشته بشه: $hadi",
            ]);
        } else {
            bot('answercallbackquery', [
                'callback_query_id' => $update->callback_query->id,
                'text' => "ببخشید تعداد الماس های شما برای دریافت ممبر کافی نیست❌",

                'show_alert' => true
            ]);
        }
    } elseif ($data == "seen300") {
        file_put_contents("data/$chatid/ted.txt", "300");
        $aaa = file_get_contents("data/$chatid/ted.txt");
        $shoklt = file_get_contents("data/$chatid/shoklat.txt");
        if ($shoklt < $aaa) {
            bot('answercallbackquery', [
                'callback_query_id' => $update->callback_query->id,
                'text' => "ببخشید تعداد الماس های شما برای دریافت ممبر کافی نیست❌",
                'show_alert' => true
            ]);
        } else {
            bot('answercallbackquery', [
                'callback_query_id' => $update->callback_query->id,
                'text' => "کمی صبر کنید",
                'show_alert' => false
            ]);
            file_put_contents("data/$chatid/ali.txt", "seen2");

            bot('editmessagetext', [
                'chat_id' => $chatid,
                'message_id' => $message_id2,
                'text' => "1⃣این ربات رو ادمین چنلی که میخوای واسش ممبر بگیری کن
2⃣ برای بالا رفتن کیفیت ممبر دهی 
اول یوزنیم چنلتون رو بدون @ به یک چنل عمومی بفرستید سپس به این ربات فروارد کنید


یوزنیم حتما باید بدون @باشد برای مثال
$channel
باید نوشته بشه: $hadi",
            ]);
        }
    } elseif ($ali == "seen2") {
        if ($forward_chat_username != null) {
            $msg_id = bot('ForwardMessage', [
                'chat_id' => $channel,
                'from_chat_id' => "$forward_chat_username",
                'message_id' => $forward_chat_msg_id
            ])->result->message_id;
            bot('sendMessage', [
                'chat_id' => $channel,
                'text' => "‌درخواست ممبر جدید👇👥
چنل http://telegram.me/$text
(@$textاول روی گزینه (رفتن به
 بزنید سپس عضو کانال $text بشوید
سپس روی گزینه دریافت الماس بزنید و یک الماس دریافت کنید✅💎",
                'reply_to_message_id' => $msg_id,
                'parse_mode' => "MarkDown",
                'reply_markup' => json_encode([
                    'inline_keyboard' => [
                        [
                            ['text' => "دریافت الماس💎", 'callback_data' => "ok"], ['text' => "راهنما❓❔", 'callback_data' => "helpposr"]

                    ],
                    [
                        ['text' => "رفتن‌به@$text", 'url' => "http://telegram.me/$text"]
                        ],
                    ]
                ])
            ]);

             $al = file_get_contents("data/$chat_id/ted.txt");
            $sho = file_get_contents("data/$chat_id/shoklat.txt");
            $getsho = $sho - $al;
            file_put_contents("data/$chat_id/shoklat.txt", $getsho);
             $don = file_get_contents("data/done.txt");
             $getdon = $don + 1;
            file_put_contents("data/done.txt", $getdon);
            file_put_contents("ads/cont/$msg_id.txt", $al);
            file_put_contents("ads/date/$msg_id.txt", $fadate);
            file_put_contents("ads/time/$msg_id.txt", $fatime);
            file_put_contents("ads/admin/$msg_id.txt", $chat_id);
            file_put_contents("ads/seen/$msg_id.txt", "0");
            file_put_contents("ads/user/$msg_id.txt", "");
            file_put_contents("data/$chat_id/ali.txt", "no");
            bot('sendMessage', [
                'chat_id' => $chat_id,
                'text' => "خوب کاربر گرامی درخواست ممبرشما با موفقیت در کانال ثبت شد👥
ساعت درخواست ممبر👥 :$fatime 
 📅تاریخ درخواست  : $fadate
〰〰〰〰〰〰〰〰〰〰〰〰
برای رفتن به چنلی که سفارشات بهش ارسال میشه از لینک http://telegram.me/$hadi استفاده کنید✅
〰〰〰〰〰〰〰〰〰〰〰〰
تعداد ممبر درخواستی شما: $al",
            ]);
        } else {
            sendmessage($chat_id, "لطفا برای اینکه ربات ازبابت سفارش شما خیالش راحت باشد
اول ربات رو ادمین چنلی که میخواین واسش ممبر بگیرید کنید
یوزنیم چنلتون رو بدون @ برای مثال
$hadi 
 اول به یک چنل عمومی بفرستید بعد به این ربات بفرستید تا امنیت و کیفیت بالا برود");
        }
    }
    if ($data == "ok") {
        $message_id12 = $update->callback_query->message->reply_to_message->message_id;
        $fromm_id = $update->callback_query->from->id;
         $ue = file_get_contents("ads/user/$message_id12.txt");
         $se = file_get_contents("ads/seen/$message_id12.txt");
        if (strpos($ue, "$fromm_id") !== false) {
            bot('answercallbackquery', [
                'callback_query_id' => $update->callback_query->id,
                'text' => "شما قبلا از این سفارش الماس💎 گرفتی",
                'show_alert' => false
            ]);
        } else {
            $user = file_get_contents("ads/user/$message_id12.txt");
            $members = explode("\n", $user);
            if (!in_array($fromm_id, $members)) {
                $add_user = file_get_contents("ads/user/$message_id12.txt");
                $add_user .= $fromm_id . "\n";
                file_put_contents("ads/user/$message_id12.txt", $add_user);
            }
            $getse = $se + 1;
            file_put_contents("ads/seen/$message_id12.txt", $getse);
             $sho = file_get_contents("data/$fromm_id/shoklat.txt");
            $getsho = $sho + 1;
            file_put_contents("data/$fromm_id/shoklat.txt", $getsho);
            bot('answercallbackquery', [
                'callback_query_id' => $update->callback_query->id,
                'text' => "💎2الماس دریافت کردید|تعداد الماس: $sho",
                'show_alert' => false
            ]);
        }
        $end = file_get_contents("ads/seen/$message_id12.txt");
        $ad = file_get_contents("ads/admin/$message_id12.txt");
        $co = file_get_contents("ads/cont/$message_id12.txt");
        $te = file_get_contents("ads/time/$message_id12.txt");
        $de = file_get_contents("ads/date/$message_id12.txt");
        if ($end == $co) {
            file_put_contents("data/$chat_id/ali.txt", "no");
            bot('sendMessage', [
                'chat_id' => $ad,
                'text' => "درخواست ممبر شما به پایان رسید✅👥
〰〰〰〰〰〰〰〰〰〰〰
مشخصات👇👇
〰〰〰〰〰〰〰〰〰〰〰
👁‍🗨تعداد ممبر درخواستی شما: $co
⏰ساعت درخواست ممبر: $te
📆تاریخ درخواست ممبر: $de
ساعت اتمام درخواست : $fatime
##########the end##########",
                'parse_mode' => "MarkDown"
             ]);
        }
    }

////----
if ($chatid == $ADMIN or $chat_id == $ADMIN) {
    if ($text == "/panel") {
        file_put_contents("data/$chat_id/ali.txt", "no");
        sendAction($chat_id, 'typing');
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "👑 خب مدیر من به بخش مدیریت خوش اومدی از گزینه های زیر استفاده کن👑",
            'parse_mode' => "MarkDown",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "📈آمار و نمودار📊", 'callback_data' => "am"],['text' => "ارسال پیام به همه🖍", 'callback_data' => "send"]
                    ],
                    [
                       ['text' => "💎الماس به کاربر👥", 'callback_data' => "buy"],['text' => "بلاک کردن کاربر🤓", 'callback_data' => "pen"], ['text' => "فروارد همگانی🤓", 'callback_data' => "fwd"]
                    ],
                    [
                        ['text' => "✅انبلاک کردن✅", 'callback_data' => "unpen"],['text' => "📪تنظیم پشتیبانی📪", 'callback_data' => "setc210"]
                    ],
                    [
                        ['text' => "✅تنظیم چنل ارسال سفارشات📈", 'callback_data' => "setc"]
                    ],
                            [
                        ['text' => "📍تنظیم چنل دریافت الماس📍", 'callback_data' => "setc4"]
                  ],
                    [
                        ['text' => "📒تنظیم متن راهنما📒", 'callback_data' => "setc99"],['text' => "✏️تنظیم متن قوانین✏️", 'callback_data' => "setc09"]
                    ],
                                              
                   [
                        ['text' => "✔️تنظیم متن خرید الماس✔️", 'callback_data' => "setc2"]
                  ],
                  [
                        ['text' => "❔راهنمای ادمین👤", 'callback_data' => "helpadmin"], ['text' => "⚫لیست سیاه⚫", 'callback_data' => "listbon"]
                    ]
                ]
            ])
        ]);
    } elseif ($data == "listbon") {

       bot('editmessagetext', [
           'chat_id' => $chat_id,
           'message_id' => $message_id2,
           'text' => "$listbon
$listbun",
           'reply_markup' => json_encod([

'inline_keyboard' => [
                    [
                        ['text' => "بازگشت منوی اصلی", 'callback_data' => "home"]
                      ],
                  ]
              ])
         ]);
    } elseif ($data == "am") {
        $user = file_get_contents("users.txt");
        $member_id = explode("\n", $user);
        $member_count = count($member_id) - 1;
        @$don = file_get_contents("data/done.txt");
        @$enf = file_get_contents("data/enf.txt");
        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "تعداد ممبر ها👥 : $member_count
تعداد سفارشات: $don
تعداد سفارشات انجام شده📈: $enf",

            'show_alert' => true
        ]);
    } elseif ($data == "send") {
        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "کمی صبر کنید",
            'show_alert' => false
        ]);
        file_put_contents("data/$chatid/ali.txt", "send");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "خوب پیام خودتون را برام بفرستید تا بفرستم برای تمامی کاربران ربات",
        ]);
    } elseif ($ali == "send") {
        file_put_contents("data/$chat_id/ali.txt", "no");
        $fp = fopen("users.txt", 'r');
        while (!feof($fp)) {
            $ckar = fgets($fp);
            sendmessage($ckar, $text);
        }
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "با موفقیت برای همه کاربران ارسال شد",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "حله بریم منوی اصلی", 'callback_data' => "home"]
                    ],
                ]
            ])
        ]);
    } elseif ($data == "fwd") {
        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "کمی صبر کنید",
            'show_alert' => false
        ]);
        file_put_contents("data/$chatid/ali.txt", "fwd");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "خوب پیام خود را فروارد کنید تابه همه اعضا فرستاده شود",
        ]);
    } elseif ($ali == 'fwd') {
        file_put_contents("data/$chat_id/ali.txt", "no");
        $forp = fopen("users.txt", 'r');
        while (!feof($forp)) {
            $fakar = fgets($forp);
            Forward($fakar, $chat_id, $message_id);
        }
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "با موفقیت فروارد شد.",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "حله بریم منوی اصلی", 'callback_data' => "home"]
                    ],
                ]
            ])
        ]);
    } elseif ($data == "pen") {
        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "کمی صبر کنید",
            'show_alert' => false
        ]);
        file_put_contents("data/$chatid/ali.txt", "pen");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "فقط ایدی عددیشو بفرست تا بلاک بشه از ربات😡",
        ]);
    } elseif ($ali == 'pen') {
        $myfile2 = fopen("data/pen.txt", 'a') or die("Unable to open file!");
        fwrite($myfile2, "$text\n");
        fclose($myfile2);
        file_put_contents("data/$chat_id/ali.txt", "No");
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => " با موفقیت بلاکش کردم😤
 ایدیش هم 
 $text ",
            'parse_mode' => "MarkDown",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "حله بریم منوی اصلی", 'callback_data' => "home"]
                    ],
                ]
            ])
        ]);
    } elseif ($data == "unpen") {
        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "کمی صبر کنید",
            'show_alert' => false
        ]);
        file_put_contents("data/$chatid/ali.txt", "unpen");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "برای انبلاک کردن فرد کافیست ایدی عددی اون را بفرستید",
        ]);
    } elseif ($ali == 'unpen') {
        $newlist = str_replace($text, "", $penlist);
        file_put_contents("data/pen.txt", $newlist);
        file_put_contents("data/$chat_id/ali.txt", "No");
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "حله انبلاک کردمش
 ایدیش هم 
 $text ",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "حله بریم منوی اصلی", 'callback_data' => "home"]
                    ],
                ]
            ])
        ]);
    } 
    elseif ($data == "setc") {
        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "کمی صبر کنید",
            'show_alert' => false
        ]);
        file_put_contents("data/$chatid/ali.txt", "setc");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "خوب یوزر نیم چنل را بفرست    همراه با @ بفرستید  ",
        ]);
    } elseif ($ali == 'setc') {
        file_put_contents("data/channel.txt", $text);
        file_put_contents("data/$chat_id/ali.txt", "No");
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "چنل ارسال سفارشات با موفقیت تنظیم شد✅ ",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "حله بریم منوی اصلی", 'callback_data' => "home"]
                    ],
                ]
            ])
        ]);
    } 
    elseif ($data == "setc99") {
        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "کمی صبر کنید",
            'show_alert' => false
        ]);
        file_put_contents("data/$chatid/ali.txt", "setc99");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "📒متنی که میخوای واسه دکمه راهنما تنظیم بشه رو بفرست📒",
        ]);
    } elseif ($ali == 'setc99') {
        file_put_contents("data/rah.txt", $text);
        file_put_contents("data/$chat_id/ali.txt", "No");
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "📌حله متن راهنما تنظیم شد📌",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "حله بریم منوی اصلی", 'callback_data' => "home"]
                    ],
                ]
            ])
        ]);
    } 
        elseif ($data == "setc09") {
        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "کمی صبر کنید",
            'show_alert' => false
        ]);
        file_put_contents("data/$chatid/ali.txt", "setc09");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "📒متنی که میخوای واسه دکمه قوانین تنظیم بشه رو بفرست📒",
        ]);
    } elseif ($ali == 'setc09') {
        file_put_contents("data/gh.txt", $text);
        file_put_contents("data/$chat_id/ali.txt", "No");
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "📌حله متن قوانین تنظیم شد📌",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "حله بریم منوی اصلی", 'callback_data' => "home"]
                    ],
                ]
            ])
        ]);
    } 
    elseif ($data == "setc210") {
        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "کمی صبر کنید",
            'show_alert' => false
        ]);
        file_put_contents("data/$chatid/ali.txt", "setc210");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "📌 آیدی پشتیبانی را بدون @ وارد کنید",
        ]);
    } elseif ($ali == 'setc210') {
        file_put_contents("data/gha.txt", $text);
        file_put_contents("data/$chat_id/ali.txt", "No");
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "📌حله آیدی پشتیبانی تنظیم شد📌",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "حله بریم منوی اصلی", 'callback_data' => "home"]
                    ],
                ]
            ])
        ]);
    } 
    elseif ($data == "setc4") {
        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "کمی صبر کنید",
            'show_alert' => false
        ]);
        file_put_contents("data/$chatid/ali.txt", "setc4");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "خب آیدی کانال را بدون @ وارد کنید",
        ]);
    } elseif ($ali == 'setc4') {
        file_put_contents("data/almasi.txt", $text);
        file_put_contents("data/$chat_id/ali.txt", "No");
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "چنل ارسال سفارشات با موفقیت تنظیم شد✅ ",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "حله بریم منوی اصلی", 'callback_data' => "home"]
                    ],
                ]
            ])
        ]);
    } 
     elseif ($data == "setc2") {
        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "کمی صبر کنید",
            'show_alert' => false
        ]);
        file_put_contents("data/$chatid/ali.txt", "setc2");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "📌متنی که میخواهید برای دکمه راهنما قرار گیرد را ارسال کنید📌",
        ]);
    } elseif ($ali == 'setc2') {
        file_put_contents("data/frosh.txt", $text);
        file_put_contents("data/$chat_id/ali.txt", "No");
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "📝 متن دکمه خرید الماس تنظیم شد📝
 $text ",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "حله بریم منوی اصلی", 'callback_data' => "home"]
                    ],
                ]
            ])
        ]);
        
        
        
        
        
    }
     elseif ($data == "buy") {
        bot('answercallbackquery', [
            'callback_query_id' => $update->callback_query->id,
            'text' => "کمی صبر کنید",
            'show_alert' => false
        ]);
        file_put_contents("data/$chatid/ali.txt", "buy");
        bot('editmessagetext', [
            'chat_id' => $chatid,
            'message_id' => $message_id2,
            'text' => "خوب ایدی عددی کاربر را بفرست️",
        ]);
    } elseif ($ali == 'buy') {
        file_put_contents("data/buy.txt", $text);
        file_put_contents("data/$chat_id/ali.txt", "buy2");
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "خوب تعداد الماس ها چقدر باشه",
            'parse_mode' => "MarkDown"
        ]);
    } elseif ($ali == 'buy2') {
    $buy = file_get_contents("data/buy.txt");
          $fle = file_get_contents("data/$buy/shoklat.txt");
               $getshe = $fle + $text;
                file_put_contents("data/$buy/shoklat.txt", $getshe);
        file_put_contents("data/$chat_id/ali.txt", "");
        bot('sendMessage', [
            'chat_id' => $buy,
            'text' => "کاربر ممبر گیر الماسی👥💎
از طرف مدیریت ربات  تعداد $text الماس💎 به حساب شما واریز شد😊",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "حله بریم منوی اصلی", 'callback_data' => "home"]
                    ],
                ]
            ])
        ]);
        bot('sendMessage', [
                    'chat_id' => $chat_id,
            'text' => "با موفقیت فرستاده شد",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "حله بریم منوی اصلی", 'callback_data' => "home"]
                    ],
                ]
            ])
        ]);
    }

}

?>