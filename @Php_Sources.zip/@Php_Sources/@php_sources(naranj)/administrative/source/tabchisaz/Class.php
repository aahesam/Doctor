<?php
ob_start();
define('API_KEY','[*[TOKEN]*]');
$admin = "[*[ADMIN]*]";
$token = "API_KEY";
	?>