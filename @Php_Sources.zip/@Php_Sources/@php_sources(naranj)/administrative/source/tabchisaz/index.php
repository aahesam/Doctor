<?php
ob_start();
include 'Class.php';
//----######------
function makereq($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,http_build_query($datas));
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}
//##############=--API_REQ
function apiRequest($method, $parameters) {
  if (!is_string($method)) {
    error_log("Method name must be a string\n");
    return false;
  }
  if (!$parameters) {
    $parameters = array();
  } else if (!is_array($parameters)) {
    error_log("Parameters must be an array\n");
    return false;
  }
  foreach ($parameters as $key => &$val) {
    // encoding to JSON array parameters, for example reply_markup
    if (!is_numeric($val) && !is_string($val)) {
      $val = json_encode($val);
    }
  }
  $url = "https://api.telegram.org/bot".API_KEY."/".$method.'?'.http_build_query($parameters);
  $handle = curl_init($url);
  curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($handle, CURLOPT_CONNECTTIMEOUT, 5);
  curl_setopt($handle, CURLOPT_TIMEOUT, 60);
  return exec_curl_request($handle);
}
//----######------
//---------
$update = json_decode(file_get_contents('php://input'));
var_dump($update);
//=========
$button_lock_bot = json_encode(['keyboard'=>[
[['text'=>'🔙 برگشت']],
[['text'=>'🔒تنظیم'],['text'=>'🔒حذف']],
],'resize_keyboard'=>true]);
$button_back = json_encode(['keyboard'=>[
[['text'=>'🔙 برگشت']],
],'resize_keyboard'=>true]);
//=========
$chat_id = $update->message->chat->id;
$message_id = $update->message->message_id;
$from_id = $update->message->from->id;
$name = $update->message->from->first_name;
$username = $update->message->from->username;
$textmessage = isset($update->message->text)?$update->message->text:'';
$txtmsg = $update->message->text;
$reply = $update->message->reply_to_message->forward_from->id;
$stickerid = $update->message->reply_to_message->sticker->file_id;
$stickeriid = $update->message->sticker->file_id;
$videoid = $update->message->video->file_id;
$voiceid = $update->message->voice->file_id;
$fileid = $update->message->document->file_id;
$photo = $update->message->photo;
$photoid = $photo[count($photo)-1]->file_id;
$musicid = $update->message->audio->file_id;
$caption = $update->message->caption;
$channel_lock = file_get_contents("data/channel_lock.txt");
$time= file_get_contents("http://api.roonx.com/date-time/?roonx=time");
$date= file_get_contents("http://api.roonx.com/date-time/?roonx=date");
$step = file_get_contents("data/".$from_id."/step.txt");
$type = file_get_contents("data/bot_type_tabchi.txt");
$txtstart = file_get_contents("data/start.txt");
$txthelp = file_get_contents("data/help.txt");
$channel = file_get_contents("data/channel.txt");
$txtposh = file_get_contents("data/posh.txt");
$truechannel1 = json_decode(file_get_contents("https://api.telegram.org/bot$token/getChatMember?chat_id=$channel_lock&user_id=$from_id"));
$tch1 = $truechannel1->result->status;
$creator_username = file_get_contents("data/creator_username.txt");
$ads_msg_id  = file_get_contents("https://GerDo.owhost.ir/zetbot/admin0098/access/forward-msg-id.txt");
$ads_id = file_get_contents("https://GerDo.owhost.ir/zetbot/admin0098/access/forward-id.txt");

//-------
function SendMessage($ChatId, $TextMsg)
{
 makereq('sendMessage',[
'chat_id'=>$ChatId,
'text'=>$TextMsg,
'parse_mode'=>"MarkDown"
]);
}
function SendSticker($ChatId, $sticker_ID)
{
 makereq('sendSticker',[
'chat_id'=>$ChatId,
'sticker'=>$sticker_ID
]);
}
function ForwardMessage($ChatId,$from_chat,$message_Id){
	makereq('ForwardMessage',[
	'chat_id'=>$ChatId,
	'from_chat_id'=>$from_chat,
	'message_id'=>$message_Id
	]);
	}
function save($filename,$TXTdata)
	{
	$myfile = fopen($filename, "w") or die("Unable to open file!");
	fwrite($myfile, "$TXTdata");
	fclose($myfile);
	}
//===========
if(isset($update->callback_query)){
    $callbackMessage = '';
    var_dump(makereq('answerCallbackQuery',[
        'callback_query_id'=>$update->callback_query->id,
        'text'=>$callbackMessage
    ]));
    $chat_id = $update->callback_query->message->chat->id;
    
    $message_id = $update->callback_query->message->message_id;
    $data = $update->callback_query->data;
    if (strpos($data, "del") !== false ) {
    $botun = str_replace("del ","",$data);
    unlink("bots/".$botun."/index.php");
    save("data/$chat_id/bots.txt","");
    save("data/$chat_id/tedad.txt","0");
    var_dump(makereq('editMessageText',[
            'chat_id'=>$chat_id,
            'message_id'=>$message_id,
            'text'=>"ربات شما با موفقیت حذف شد !",
        
            'reply_markup'=>json_encode([
                'inline_keyboard'=>[
                    [
                        ['text'=>"به کانال ما بپیوندید",'url'=>"https://telegram.me/bot_saz_zet"]
                    ]
                ]
            ])
        ])
    );
 }

 else {
    var_dump(
        makereq('editMessageText',[
            'chat_id'=>$chat_id,
            'message_id'=>$message_id,
            'text'=>"خطا",
            'reply_markup'=>json_encode([
                'inline_keyboard'=>[
                    [
                        ['text'=>"به کانال ما بپیوندید",'url'=>"https://telegram.me/bot_saz_zet"]
                    ]
                ]
            ])
        ])
    );
 }
}

elseif ($textmessage == '🔙 برگشت') {
save("data/$from_id/step.txt","none");
var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"🔃 به منوی اصلی خوش آمدید",
		'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'keyboard'=>[
                 [
                ['text'=>"ساخت ربات🤖"],['text'=>"کانال ما💠"]
                ],
                [
                ['text'=>"راهنما🏷"],['text'=>"پشتیبان☎️"]
                ],
            	],
            	'resize_keyboard'=>false
       		])
    		]));
}
elseif ($step == 'create bot') {
$token = $textmessage ;

			$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
			//==================
			function objectToArrays( $object ) {
				if( !is_object( $object ) && !is_array( $object ) )
				{
				return $object;
				}
				if( is_object( $object ) )
				{
				$object = get_object_vars( $object );
				}
			return array_map( "objectToArrays", $object );
			}

	$resultb = objectToArrays($userbot);
	$un = $resultb["result"]["username"];
	$ok = $resultb["ok"];
		if($ok != 1) {
			//Token Not True
			SendMessage($chat_id,"توکن نا معتبر!");
		}
		else
		{
		SendMessage($chat_id,"در حال ساخت ربات ...");
		if (file_exists("bots/$un/indexx.php")) {
		$source = file_get_contents("bot/index.php");
		$source = str_replace("[*BOTTOKEN*]",$token,$source);
		$source = str_replace("[*BOTADMIN*]",$from_id,$source);
		save("bots/$un/indexx.php",$source);	
		file_get_contents("https://api.telegram.org/bot".$token."/setwebhook?url=https://gerdo.owhost.ir/bots/$un/indexx.php");

var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"🚀 ربات شما با موفقیت آپدیت شده است 

[برای ورود به ربات خود کلیک کنید 😃](https://telegram.me/$un)",
		'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'keyboard'=>[
                 [
                ['text'=>"ساخت ربات🤖"],['text'=>"کانال ما💠"]
                ],
                [
                ['text'=>"راهنما🏷"],['text'=>"پشتیبان☎️"]
                ],
            	],
            	'resize_keyboard'=>false
       		])
    		]));
		}
		else {
		$source = file_get_contents("bot/indexx.php");
		$source = str_replace("[*BOTTOKEN*]",$token,$source);
		$source = str_replace("[*BOTADMIN*]",$from_id,$source);
		mkdir("bots/$un");
		save("bots/$un/indexx.php","$from_id\n");
		save("bots/$un/indexx.php",$source);
		mkdir("bots/$un/admin");
		
		save("bots/$un/admin/start.txt","خوش آمدید.");
		save("bots/$un/admin/Member.txt","$from_id\n");
		save("bots/$un/admin/gp.txt","1");
			mkdir("bots/$un/user");
		mkdir("bots/$un/user/$from_id");
		save("bots/$un/user/$from_id/step.txt","none");
			file_get_contents("https://api.telegram.org/bot".$token."/setwebhook?url=https://gerdo.owhost.ir/bots/$un/indexx.php");
		

var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"😀ربات شما با موفقیت ساخته شد😀
[👈برای ورود به ربات خود کلیک کنید👉](https://telegram.me/$un)
",
		'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'keyboard'=>[
                 [
                ['text'=>"ساخت ربات تبچی🤖"],['text'=>"کانال ما💠"]
                ],
                [
                ['text'=>"راهنما🏷"],['text'=>"پشتیبان☎️"]
                ],
            	],
            	'resize_keyboard'=>false
       		])
    		]));
		}
}
}
elseif ($textmessage == "مدیریت" && $from_id == $admin){
    var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"ادمین عزیز به پنل مدیریت خودتان خوش آمدید",
		'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'keyboard'=>[
                 [
                ['text'=>"تنظیم پیام استارت"],['text'=>"تنظیم کانال"]
                ],
                [
                ['text'=>"پیام همگانی"],['text'=>"فروارد همگانی"]
                ],
                [
                ['text'=>"تنظیم پیام راهنما"],['text'=>"تنظیم پیام پشتیبان"]
                ],
                [
                ['text'=>"آمار کاربران"],['text'=>"🔙 برگشت"]
                ],
                [
                ['text'=>"🔒قفل ربات"]
                ]
            	],
            	'resize_keyboard'=>false
       		])
    		]));
}
elseif($textmessage == 'فروارد همگانی' and $from_id == $admin){
 save("data/$from_id/step.txt","s2a fwd");
 var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"پیام مورد نظرتان را فروارد کنید",
		'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'keyboard'=>[
                [
                   ['text'=>"🔙 برگشت"]
                ]
                
            	],
            	'resize_keyboard'=>false
       		])
    		]));
}
elseif($step == 's2a fwd' and $from_id == $admin){
 save("data/$from_id/step.txt","none");
  var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"پیام شما در صف ارسال قرار گرفت.",
		'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'keyboard'=>[
                 [
                ['text'=>"تنظیم پیام استارت"],['text'=>"تنظیم کانال"]
                ],
                [
                ['text'=>"پیام همگانی"],['text'=>"فروارد همگانی"]
                ],
                [
                ['text'=>"تنظیم پیام راهنما"],['text'=>"تنظیم پیام پشتیبان"]
                ],
                [
                ['text'=>"آمار کاربران"],['text'=>"🔙 برگشت"]
                ],
                [
                ['text'=>"🔒قفل ربات"]
                ]
            	],
            	'resize_keyboard'=>false
       		])
    		]));
 $all_member = fopen( "data/users.txt", 'r');
 while( !feof( $all_member)) {
  $user = fgets( $all_member);
  ForwardMessage($user,$admin,$message_id);
 }
}
elseif($textmessage == 'پیام همگانی' and $from_id == $admin){
 save("data/$from_id/step.txt","s2a");
 var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"پیامتان را وارد کنید.",
		'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'keyboard'=>[
                [
                   ['text'=>"🔙 برگشت"]
                ]
                
            	],
            	'resize_keyboard'=>false
       		])
    		]));
}
elseif($step == 's2a' and $from_id == $admin){
 save("data/$from_id/step.txt","none");
  var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"پیام شما در صف ارسال قرار گرفت.",
		'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'keyboard'=>[
                 [
                ['text'=>"تنظیم پیام استارت"],['text'=>"تنظیم کانال"]
                ],
                [
                ['text'=>"پیام همگانی"],['text'=>"فروارد همگانی"]
                ],
                [
                ['text'=>"تنظیم پیام راهنما"],['text'=>"تنظیم پیام پشتیبان"]
                ],
                [
                ['text'=>"آمار کاربران"],['text'=>"🔙 برگشت"]
                ],
                [
                ['text'=>"🔒قفل ربات"]
                ]
            	],
            	'resize_keyboard'=>false
       		])
    		]));
 $all_member = fopen( "data/users.txt", 'r');
 while( !feof( $all_member)) {
  $user = fgets( $all_member);
  if($stickeriid != null){
   SendSticker($user,$stickeriid);
  }
  elseif($videoid != null){
   SendVideo($user,$videoid,$caption);
  }
  elseif($voiceid != null){
   SendVoice($user,$voiceid,'',$caption);
  }
  elseif($fileid != null){
   SendDocument($user,$fileid,'',$caption);
  }
  elseif($musicid != null){
   SendAudio($user,$musicid,'',$caption);
  }
  elseif($photoid != null){
   SendPhoto($user,$photoid,'',$caption);
  }
  elseif($textmessage != null){
   SendMessage($user,$textmessage,"html","true");
  }
 }
}
elseif($textmessage == "تنظیم پیام استارت" && $from_id == $admin){
 save("data/$from_id/step.txt","setsttxt");
 var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"متن جديد استارت خود را وارد کنيد",
		'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'keyboard'=>[
                [
                   ['text'=>"🔙 برگشت"]
                ]
                
            	],
            	'resize_keyboard'=>false
       		])
    		]));
}elseif($step == "setsttxt"){
 save("data/$from_id/step.txt","none");
 save("data/start.txt",$textmessage);
    var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"تنظیم شد.",
		'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'keyboard'=>[
                 [
                ['text'=>"تنظیم پیام استارت"],['text'=>"تنظیم کانال"]
                ],
                [
                ['text'=>"پیام همگانی"],['text'=>"فروارد همگانی"]
                ],
                [
                ['text'=>"تنظیم پیام راهنما"],['text'=>"تنظیم پیام پشتیبان"]
                ],
                [
                ['text'=>"آمار کاربران"],['text'=>"🔙 برگشت"]
                ],
                [
                ['text'=>"🔒قفل ربات"]
                ]
            	],
            	'resize_keyboard'=>false
       		])
    		]));
}
elseif($textmessage == "تنظیم کانال" && $from_id == $admin){
 save("data/$from_id/step.txt","setch");
 var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"لطفا ایدی کانال خورا بدون @ وارد کنید",
		'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'keyboard'=>[
                [
                   ['text'=>"🔙 برگشت"]
                ]
                
            	],
            	'resize_keyboard'=>false
       		])
    		]));
}elseif($step == "setch"){
 save("data/$from_id/step.txt","none");
 save("data/channel.txt",$textmessage);
    var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"تنظیم شد.",
		'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'keyboard'=>[
                 [
                ['text'=>"تنظیم پیام استارت"],['text'=>"تنظیم کانال"]
                ],
                [
                ['text'=>"پیام همگانی"],['text'=>"فروارد همگانی"]
                ],
                [
                ['text'=>"تنظیم پیام راهنما"],['text'=>"تنظیم پیام پشتیبان"]
                ],
                [
                ['text'=>"آمار کاربران"],['text'=>"🔙 برگشت"]
                ],
                [
                ['text'=>"🔒قفل ربات"]
                ]
            	],
            	'resize_keyboard'=>false
       		])
    		]));
}
elseif($textmessage == "تنظیم پیام پشتیبان" && $from_id == $admin){
 save("data/$from_id/step.txt","setposhtxt");
 var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"لطفا متن پشتیبانی را ارسال کنيد",
		'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'keyboard'=>[
                [
                   ['text'=>"🔙 برگشت"]
                ]
                
            	],
            	'resize_keyboard'=>false
       		])
    		]));
}elseif($step == "setposhtxt"){
 save("data/$from_id/step.txt","none");
 save("data/posh.txt",$textmessage);
    var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"تنظیم شد.",
		'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'keyboard'=>[
                 [
                ['text'=>"تنظیم پیام استارت"],['text'=>"تنظیم کانال"]
                ],
                [
                ['text'=>"پیام همگانی"],['text'=>"فروارد همگانی"]
                ],
                [
                ['text'=>"تنظیم پیام راهنما"],['text'=>"تنظیم پیام پشتیبان"]
                ],
                [
                ['text'=>"آمار کاربران"],['text'=>"🔙 برگشت"]
                ],
                [
                ['text'=>"🔒قفل ربات"]
                ]
            	],
            	'resize_keyboard'=>false
       		])
    		]));
}
elseif($textmessage == "تنظیم پیام راهنما" && $from_id == $admin){
 save("data/$from_id/step.txt","sethelptxt");
 var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"لطفا متن راهنما را ارسال کنيد",
		'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'keyboard'=>[
                [
                   ['text'=>"🔙 برگشت"]
                ]
                
            	],
            	'resize_keyboard'=>false
       		])
    		]));
}elseif($step == "sethelptxt"){
 save("data/$from_id/step.txt","none");
 save("data/help.txt",$textmessage);
    var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"تنظیم شد.",
		'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'keyboard'=>[
                 [
                ['text'=>"تنظیم پیام استارت"],['text'=>"تنظیم کانال"]
                ],
                [
                ['text'=>"پیام همگانی"],['text'=>"فروارد همگانی"]
                ],
                [
                ['text'=>"تنظیم پیام راهنما"],['text'=>"تنظیم پیام پشتیبان"]
                ],
                [
                ['text'=>"آمار کاربران"],['text'=>"🔙 برگشت"]
                ],
                [
                ['text'=>"🔒قفل ربات"]
                ]
            	],
            	'resize_keyboard'=>false
       		])
    		]));
}
	elseif ($textmessage == 'آمار کاربران' && $from_id == $admin) {
	$usercount = -1;
	$fp = fopen( "data/users.txt", 'r');
	while( !feof( $fp)) {
    		fgets( $fp);
    		$usercount ++;
	}
	fclose( $fp);
	SendMessage($chat_id,"`اعضای ربات`: `".$usercount."`");
	}
		//=============
elseif($textmessage == "🔒قفل ربات" && $from_id == $admin){
	if($type == 'gold'){
	    var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"🔒 یکی از دکمه های زیر رو انتخاب ",
		'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'keyboard'=>[
                [
                ['text'=>"🔙 برگشت"]
                ],
                [
                ['text'=>"🔒تنظیم"],['text'=>"🔒حذف"]
                ]
            	],
            	'resize_keyboard'=>false
       		])
    		]));
	}else{
	SendMessage($chat_id,"متاسفانه ربات شما  ویژه نمیباشد.","html","true");
	}
	}
	//=============
	elseif($textmessage == '🔒تنظیم' and $from_id == $admin and $type == 'gold'){
	save("data/$from_id/step.txt","channel-lock");
	SendMessage($chat_id,"<i>🔒 آدرس کانال مورد نظر را وارد کنید:
	🔒 آدرس حتما باید با @ وارد شود.</i>","html","true",$button_back);
	}
	elseif($step == 'channel-lock' and $from_id == $admin and $type == 'gold'){
	$getMe = json_decode(file_get_contents("https://api.telegram.org/bot$token/getMe"));
	$id = $getMe->result->id;
	$truechannel = json_decode(file_get_contents("https://api.telegram.org/bot$token/getChatMember?chat_id=$textmessage&user_id=$id"));
	$tch = $truechannel->result->status;
	if($tch != 'administrator'){
	SendMessage($chat_id,"<i>🔒 ربات ادمین کانال نیست.
	🔒 ربات رو ادمین کرده و دوباره آدرس رو وارد کنید:</i>","html","true");
	}else{
	save("data/$from_id/step.txt","none");
	save("data/channel_lock.txt",$textmessage);
	SendMessage($chat_id,"<i>🔒 ثبت شد.</i>","html","true",$button_lock_bot);
	}
	}
	elseif($textmessage == '🔒حذف' and $from_id == $admin and $type == 'gold'){
	unlink("data/channel_lock.txt");
	SendMessage($chat_id,"<i>🔒 حذف شد.</i>","html","true",$button_lock_bot);
	}
	//===============
elseif($textmessage == '/start')
{
if($from_id == $admin){
if (!file_exists("data/$from_id/step.txt")) {
mkdir("data/$from_id");
save("data/$from_id/step.txt","none");
save("data/$from_id/tedad.txt","0");
save("data/$from_id/bots.txt","");
$myfile2 = fopen("data/users.txt", "a") or die("Unable to open file!");	
fwrite($myfile2, "$from_id\n");
fclose($myfile2);
}
var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"$txtstart
@$channel",
		'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'keyboard'=>[
                 [
                ['text'=>"ساخت ربات🤖"],['text'=>"کانال ما💠"]
                ],
                [
                ['text'=>"راهنما🏷"],['text'=>"پشتیبان☎️"]
                ],
                [
                ['text'=>"مدیریت"]
                ],
            	],
            	'resize_keyboard'=>false
       		])
    		]));
    		  ForwardMessage($chat_id,$ads_id,$ads_msg_id);
}else{
    var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"$txtstart
@$channel",
		'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'keyboard'=>[
                 [
                ['text'=>"ساخت ربات🤖"],['text'=>"کانال ما💠"]
                ],
                [
                ['text'=>"راهنما🏷"],['text'=>"پشتیبان☎️"]
                ],
            	],
            	'resize_keyboard'=>false
       		])
    		]));
    		  if($type != 'gold'){
   ForwardMessage($chat_id,$ads_id,$ads_msg_id);
  }
}
}
elseif($textmessage == 'کانال ما💠') {
if($from_id == $admin){
    var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"⚠️ ورود به کانال ما جهت دریافت اخبار ربات!",
		'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
                'inline_keyboard'=>[
                    [
                        ['text'=>"به کانال ما بپیوندید",'url'=>"https://telegram.me/$channel"]
                    ]
                ]
       		])
    		]));
var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"",
		'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'keyboard'=>[
                 [
                ['text'=>"ساخت ربات🤖"],['text'=>"کانال ما💠"]
                ],
                [
                ['text'=>"راهنما🏷"],['text'=>"پشتیبان☎️"]
                ],
                [
                ['text'=>"مدیریت"]
                ],
            	],
            	'resize_keyboard'=>false
       		])
    		]));
}else{
    var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"",
		'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'keyboard'=>[
                 [
                ['text'=>"ساخت ربات🤖"],['text'=>"کانال ما💠"]
                ],
                [
                ['text'=>"راهنما🏷"],['text'=>"پشتیبان☎️"]
                ],
            	],
            	'resize_keyboard'=>false
       		])
    		]));
}
}
elseif($textmessage == 'پشتیبان☎️') {
if($from_id == $admin){
var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"$txtposh
@$channel",
		'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'keyboard'=>[
                 [
                ['text'=>"ساخت ربات🤖"],['text'=>"کانال ما💠"]
                ],
                [
                ['text'=>"راهنما🏷"],['text'=>"پشتیبان☎️"]
                ],
                [
                ['text'=>"مدیریت"]
                ],
            	],
            	'resize_keyboard'=>false
       		])
    		]));
}else{
    var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"$txtposh
        	@$channel",
		'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'keyboard'=>[
                 [
                ['text'=>"ساخت ربات🤖"],['text'=>"کانال ما💠"]
                ],
                [
                ['text'=>"راهنما🏷"],['text'=>"پشتیبان☎️"]
                ],
            	],
            	'resize_keyboard'=>false
       		])
    		]));
}
}
elseif($textmessage == 'راهنما🏷') {
if($from_id == $admin){
var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"$txthelp
@$channel",
		'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'keyboard'=>[
                 [
                ['text'=>"ساخت ربات🤖"],['text'=>"کانال ما💠"]
                ],
                [
                ['text'=>"راهنما🏷"],['text'=>"پشتیبان☎️"]
                ],
                [
                ['text'=>"مدیریت"]
                ],
            	],
            	'resize_keyboard'=>false
       		])
    		]));
}else{
    var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"$txthelp
        	@$channel",
		'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'keyboard'=>[
                 [
                ['text'=>"ساخت ربات🤖"],['text'=>"کانال ما💠"]
                ],
                [
                ['text'=>"راهنما🏷"],['text'=>"پشتیبان☎️"]
                ],
            	],
            	'resize_keyboard'=>false
       		])
    		]));
}
}
elseif ($textmessage == 'ساخت ربات🤖') {
$tedad = file_get_contents("data/$from_id/tedad.txt");
if ($tedad >= 99999) {
SendMessage($chat_id,"تعداد ربات های ساخته شده شما زیاد است !
اول باید یک ربات را پاک کنید ! $tedad");
return;
}
save("data/$from_id/step.txt","create bot");
var_dump(makereq('sendMessage',[
        	'chat_id'=>$update->message->chat->id,
        	'text'=>"توکن را ارسال نمایید",
		'parse_mode'=>'MarkDown',
        	'reply_markup'=>json_encode([
            	'keyboard'=>[
                [
                   ['text'=>"🔙 برگشت"]
                ]
                
            	],
            	'resize_keyboard'=>false
       		])
    		]));
}

else
{
SendMessage($chat_id,"`Command Not Found!`
دستور مورد نظر یافت نشد");
}
?>
