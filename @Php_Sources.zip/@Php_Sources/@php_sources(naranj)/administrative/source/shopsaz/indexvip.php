<?php
define('API_KEY','*TOKEN*');
function makereq($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,http_build_query($datas));
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}
function apiRequest($method, $parameters) {
  if (!is_string($method)) {
    error_log("Method name must be a string\n");
    return false;
  }
  if (!$parameters) {
    $parameters = array();
  } else if (!is_array($parameters)) {
    error_log("Parameters must be an array\n");
    return false;
  }
  foreach ($parameters as $key => &$val) {
    // encoding to JSON array parameters, for example reply_markup
    if (!is_numeric($val) && !is_string($val)) {
      $val = json_encode($val);
    }
  }
  $url = "https://api.telegram.org/bot".API_KEY."/".$method.'?'.http_build_query($parameters);
  $handle = curl_init($url);
  curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($handle, CURLOPT_CONNECTTIMEOUT, 5);
  curl_setopt($handle, CURLOPT_TIMEOUT, 60);
  return exec_curl_request($handle);
}
$update = json_decode(file_get_contents('php://input'));
var_dump($update);
$chat_id = $update->message->chat->id;
$message_id = $update->message->message_id;
$from_id = $update->message->from->id;
$name = $update->message->from->first_name;
$username = $update->message->from->username;
$textmessage = isset($update->message->text)?$update->message->text:'';
$reply = $update->message->reply_to_message->forward_from->id;
$stickerid = $update->message->reply_to_message->sticker->file_id;
$button_back = json_encode(['keyboard'=>[
[['text'=>'بازگشت']],
],'resize_keyboard'=>true]);
$command = file_get_contents('data/admin/'.$from_id."/command.txt");
$command1 = file_get_contents('data/users/'.$from_id."/command.txt");
$message_id = $update->message->message_id;
$date = file_get_contents("https://provps.ir/td?td=date");
$time = file_get_contents("https://provps.ir/td?td=time");
$photo = $update->message->photo;
$video = $update->message->video;
$sticker = $update->message->sticker;
$file = $update->message->document;
$music = $update->message->audio;
$text = $update->message->text;
$wait = file_get_contents('data/users/'.$from_id."/wait.txt");
$coin_wait = file_get_contents('data/users/'.$wait."/coin.txt");
$voice = $update->message->voice;
$forward = $update->message->forward_from;
$admin = *ADMIN*;
$channl = file_get_contents("data/chan.txt");
$coin = file_get_contents("data/users/$from_id/coin.txt");
$run = file_get_contents("data/users/".$from_id."/run.txt");
$Member = file_get_contents("data/member.txt");
$botids = *botid*;
//-------
function SendMessage($ChatId, $TextMsg)
{
 makereq('sendMessage',[
'chat_id'=>$ChatId,
'text'=>$TextMsg,
'parse_mode'=>"MarkDown"
]);
}
function SendSticker($ChatId, $sticker_ID)
{
 makereq('sendSticker',[
'chat_id'=>$ChatId,
'sticker'=>$sticker_ID
]);
}
function Forward($KojaShe,$AzKoja,$KodomMSG)
{
makereq('ForwardMessage',[
'chat_id'=>$KojaShe,
'from_chat_id'=>$AzKoja,
'message_id'=>$KodomMSG
]);
}
function save($filename,$TXTdata)
	{
	$myfile = fopen($filename, "w") or die("Unable to open file!");
	fwrite($myfile, "$TXTdata");
	fclose($myfile);
	}
    $step = "";
    if (file_exists("data/users/$from_id/step.txt")) {
      $step = file_get_contents("data/users/$from_id/step.txt");
    }
    if ($textmessage == "/cancel") {
        save("data/users/$from_id/command.txt","none");
var_dump(makereq('sendMessage',[
        'chat_id'=>$update->message->chat->id,
        'text'=>"`تمامی موارد کنسل شدند ✅
یکی از دکمه هارو انتخاب کنید ☝`",
        'parse_mode'=>'MarkDown',
        'reply_markup'=>json_encode([
            'keyboard'=>[
              [
                ['text'=>"محصولات 🛒"],['text'=>"خرید الماس 💎"]
              ],
       [
                ['text'=>"راهنما ⚠️"],['text'=>"الماس رایگان 🎁"]
              ],
        [
                  ['text'=>"پشتیبانی 👤"],['text'=>"اطلاعات حساب 💰"]
			  ],
		[
				  ['text'=>"انتقال الماس 💎"],['text'=>'کد هدیه 🏆']

              ],
            ]
        ])
    ]));
	save("data/users/$from_id/step.txt","none");
 }
	elseif ($textmessage == "بازگشت") {
	
file_put_contents("data/users/".$from_id."/es.txt","no");
file_put_contents("data/users/".$from_id."/run.txt","no");
var_dump(makereq('sendMessage',[
        'chat_id'=>$update->message->chat->id,
        'text'=>"`با موفقیت به منوی اصلی بازگشتید
یکی از دکمه هارو انتخاب کنید ☝`
",
        'parse_mode'=>'MarkDown',
        'reply_markup'=>json_encode([
            'keyboard'=>[
              [
                ['text'=>"محصولات 🛒"],['text'=>"خرید الماس 💎"]
              ],
       [
                ['text'=>"راهنما ⚠️"],['text'=>"الماس رایگان 🎁"]
              ],
        [
                  ['text'=>"پشتیبانی 👤"],['text'=>"اطلاعات حساب 💰"]
			  ],
		[
			['text'=>"انتقال الماس 💎"],['text'=>'کد هدیه 🏆']
              ],
               ],
        ])
    ]));
	save("data/users/$from_id/step.txt","none");
}
if($textmessage == "انتقال الماس 💎"){
file_put_contents("data/users/".$from_id."/run.txt","cs");
      $keyboard = [
	  [
		['text'=>'بازگشت']
	]
];
      var_dump(makereq('sendMessage',[
           'chat_id'=>$update->message->chat->id,
           'text'=>"*لطفا* `شناسه عددی🆔` *شخص مورد نظر را ارسال کنید🛑*",
     'parse_mode'=>'MarkDown',
           'reply_markup'=>json_encode([
               'keyboard'=>$keyboard,
               'resize_keyboard'=>true
           ])
       ]));
} 
if($run == "cs"){
if(file_exists("data/users/".$textmessage."/coin.txt")){
file_put_contents("data/users/".$from_id."/run.txt","cs2");
file_put_contents("data/users/".$from_id."/es.txt",$textmessage);
      $keyboard = [
	  [
		['text'=>'بازگشت']
	]
];
      var_dump(makereq('sendMessage',[
           'chat_id'=>$update->message->chat->id,
           'text'=>"*تعداد* `الماس های💎` *مورد نظر را ارسال کنید🛑*\n*تعداد الماس های فعلی شما :*` $coin 💎`",
     'parse_mode'=>'MarkDown',
           'reply_markup'=>json_encode([
               'keyboard'=>$keyboard,
               'resize_keyboard'=>true
           ])
       ]));
}else{
      $keyboard = [
	  [
		['text'=>'بازگشت']
	]
];
      var_dump(makereq('sendMessage',[
           'chat_id'=>$update->message->chat->id,
           'text'=>"_کاربر یافت نشد❌_",
     'parse_mode'=>'MarkDown',
           'reply_markup'=>json_encode([
               'keyboard'=>$keyboard,
               'resize_keyboard'=>true
           ])
       ]));
}
}
if($run == "cs2"){
if($coin >= $textmessage){
      $keyboard = [
	  [
		['text'=>'بازگشت']
	]
];
$sf = file_get_contents("data/users/".$from_id."/es.txt");
$del = $coin - $textmessage;
file_put_contents("data/users/".$from_id."/coin.txt",$del);
$coin2 = file_get_contents("data/users/".$sf."/coin.txt");
$add = $coin2 + $textmessage;
file_put_contents("data/users/".$sf."/coin.txt",$add);
file_put_contents("data/users/".$from_id."/es.txt","no");
file_put_contents("data/users/".$from_id."/run.txt","no");
      var_dump(makereq('sendMessage',[
           'chat_id'=>$update->message->chat->id,
           'text'=>"_عملیات با موفقیت انجام شد✅_",
     'parse_mode'=>'MarkDown',
           'reply_markup'=>json_encode([
               'keyboard'=>$keyboard,
               'resize_keyboard'=>true
           ])
       ]));
      var_dump(makereq('sendMessage',[
           'chat_id'=>$sf,
           'text'=>"*تعداد* `$textmessage` *الماس به شما انتقال داده شد✅*\n\n*توسط ↙️*\n*👤Name 👉* `$name`\n*🆔Username 👉* `@$username`\n*🌐UserID 👉* `$from_id`\n\n*تعداد الماس های جدید شما :*  `$add 💎`",
     'parse_mode'=>'MarkDown',
           'reply_markup'=>json_encode([
               'keyboard'=>$keyboard,
               'resize_keyboard'=>true
           ])
       ]));
}else{ 
file_put_contents("data/users/".$from_id."/es.txt","no");
file_put_contents("data/users/".$from_id."/run.txt","no");
sendMessage($chat_id,"_Error❌_\n`تعداد الماس یافت نشد⭕️`");
}
   }
    elseif ($step == "useCode") {
      if (file_exists("data/codes/$textmessage.txt")) {
        $price = file_get_contents("data/codes/$textmessage.txt");
        $coin = file_get_contents("data/users/".$from_id."/coin.txt");
        settype($coin,"integer");
        $newcoin = $coin + $price;
        save("data/users/".$from_id."/coin.txt",$newcoin);
        unlink("data/codes/$textmessage.txt");
        save("data/users/$from_id/step.txt","none");
var_dump(makereq('sendMessage',[
        'chat_id'=>$update->message->chat->id,
        'text'=>"الماس های شما به مقدار `$price` افزایش یافت",
        'parse_mode'=>'MarkDown',
        'reply_markup'=>json_encode([
            'keyboard'=>[
              [
                ['text'=>"محصولات 🛒"],['text'=>"خرید الماس 💎"]
              ],
       [
                ['text'=>"راهنما ⚠️"],['text'=>"الماس رایگان 🎁"]
              ],
        [
                  ['text'=>"پشتیبانی 👤"],['text'=>"اطلاعات حساب 💰"]
			  ],
	    [
		          ['text'=>"انتقال الماس 💎"],['text'=>'کد هدیه 🏆']
              ],
            ]
                   ])
    ]));
sendMessage("@$channl","➖➖➖➖➖➖➖➖\n*کد با موفقیت استفاده شد✅*\n\n*⏰ در ساعت ↙️*\n\n⏰ `$time `\n\n*👤 توسط ↙️*\n\n*👤Name 👉*  `$name`\n*🆔Username 👉*  `@$username`\n*🌐UserID 👉* `$from_id`\n\n*💎الماس های دریافت شده از این کد↙️*\n\n💎 `$price`\n➖➖➖➖➖➖➖➖");
}
      else {
        SendMessage($chat_id,"`کد وارد شده نا معتبر است\nیا استفاده شده است .`");
      }
    }
    elseif ($step == "settitle") {
      SendMessage($chat_id,"📝توضیحات محصول را ارسال نمایید.");
      $count = file_get_contents("data/products/count.txt");
      save("data/products/$count.txt",$textmessage."(******)");
      save("data/products/$textmessage.txt",$count);
      save("data/users/$from_id/step.txt","setabout");
    }
    elseif ($step == "setabout") {
      SendMessage($chat_id,"🔗لینک دانلود محصول را ارسال نمایید.\n❗️هنگامی کاربر محصول را خریداری کند لینک دانلود برای او ارسال میشود. ");
      $count = file_get_contents("data/products/count.txt");
      $last= file_get_contents("data/products/$count.txt");
      save("data/products/$count.txt",$last.$textmessage."(******)");
      save("data/users/$from_id/step.txt","successLink");
    }
    elseif ($step == "successLink") {
      SendMessage($chat_id,"🌀قیمت محصول را ارسال نمایید.");
      $count = file_get_contents("data/products/count.txt");
      $last= file_get_contents("data/products/$count.txt");
      save("data/products/$count.txt",$last.$textmessage."(******)");
      save("data/users/$from_id/step.txt","setprice");
    }
    elseif ($step == "setprice") {

      $count = file_get_contents("data/products/count.txt");
      $last = file_get_contents("data/products/$count.txt");
      save("data/products/$count.txt",$last.$textmessage."");
      save("data/users/$from_id/step.txt","none");
      settype($count,"integer");
      $newcount = $count + 20;
      save("data/products/count.txt",$newcount);
     save("data/products/$newcount.txt");
     $newcountt = $newcount + 9836;
      SendMessage($chat_id,"محصول با موفقیت به لیست محصول ها اضافه شد✅\n🌐شناسه محصول 👈 2142$newcountt");
    }
    elseif ($textmessage == "محصول جدید 🛒" && $from_id == $admin) {
       sendMessage($chat_id,"⚜️نام محصول را ارسال نمایید.");
	        save("data/users/$from_id/step.txt","settitle");
}
    elseif ($textmessage == "محصولات 🛒") {
      $keyboard = [
	  [
		['text'=>'بازگشت']
	]
];
      $count = file_get_contents("data/products/count.txt");
      $n = 0;
      $text = "";
      while ($n <= $count ) {
        $post = file_get_contents("data/products/$n.txt");
        $arrayPost = explode('(******)',$post);
        $n = $n + 1;
        array_push($keyboard,[$arrayPost['0']]);
      }
      json_encode($keyboard);

      var_dump(makereq('sendMessage',[
           'chat_id'=>$update->message->chat->id,
           'text'=>"*تعداد الماس 💎 های شما 👈* `$coin 💎`
`💰محصولات فروشگاه  👇 `",
     'parse_mode'=>'MarkDown',
           'reply_markup'=>json_encode([
               'keyboard'=>$keyboard,
               'resize_keyboard'=>true
           ])
       ]));

    }
  //============
  elseif($textmessage == 'فروارد همگانی ✅' and $from_id == $admin){
mkdir("data/admin/$from_id");
save("data/admin/".$from_id."/command.txt","s2a fwd");
	SendMessage($chat_id,"`پیام مورد نظر را فوروارد کنید ➡ :`");
	}
	elseif($command == 's2a fwd' and $from_id == $admin){
	save("data/admin/".$from_id."/command.txt","none");
	SendMessage($chat_id,"📮 پیام شما در صف ارسال قرار گرفت.");
	$all_member = fopen( "data/member.txt", 'r');
		while( !feof( $all_member)) {
 			$user = fgets( $all_member);
	Forward($user,$admin,$message_id);
		}
	}
	//===========
	//===========
	elseif($text == 'پیام همگانی 👥' and $from_id == $admin){
	save("data/admin/".$from_id."/command.txt","s2a");
	SendMessage($chat_id," پیامتون رو ارسال کنید ⚠ :");
	}
	elseif($command == 's2a' and $from_id == $admin){
	save("data/admin/".$from_id."/command.txt","none");
	SendMessage($chat_id," پیام شما در صف ارسال قرار گرفت. ✅");
	$all_member = fopen( "data/member.txt", 'r');
		while( !feof( $all_member)) {
 			$user = fgets( $all_member);
			if($sticker_id != null){
			SendSticker($user,$sticker_id);
			}
			elseif($video_id != null){
			SendVideo($user,$video_id,$caption);
			}
			elseif($voice_id != null){
			SendVoice($user,$voice_id,'',$caption);
			}
			elseif($file_id != null){
			SendDocument($user,$file_id,'',$caption);
			}
			elseif($music_id != null){
			SendAudio($user,$music_id,'',$caption);
			}
			elseif($photo2_id != null){
			SendPhoto($user,$photo2_id,'',$caption);
			}
			elseif($photo1_id != null){
			SendPhoto($user,$photo1_id,'',$caption);
			}
			elseif($photo0_id != null){
			SendPhoto($user,$photo0_id,'',$caption);
			}
			elseif($text != null){
			SendMessage($user,$text,"html","true");
			}
		}
	}
//============
elseif(strpos($textmessage,'/') !== false) {
  $id = str_replace("/start ","",$textmessage);
mkdir("data/$from_id");
mkdir("data/users/$from_id");
mkdir("data/userss/$from_id");
  if (!file_exists("data/users/$from_id/coin.txt")) {
    
    save("data/users/$from_id/coin.txt","1");
    save("data/users/$from_id/step.txt","none");
    
    save("data/users/$from_id/chance.txt","0|0");

    SendMessage($chat_id,"`👤 ثبت نام با موفقیت انجام شد .`
/start
را دوباره ارسال کنید 😊");

    if ($id != "") {
      if ($id != $from_id) {
          SendMessage($id,"*🌐 کاربر*\n\n`👤 $name | $from_id`\n\n*با لینک شما وارد ربات شد📊و شما * `1 الماس 💎` *دریافت کردید🚀*");
          $coin = file_get_contents("data/users/$id/coin.txt");
          settype($coin,"integer");
          $newcoin = $coin + 1;
          save("data/users/$id/coin.txt",$newcoin);
      }
      else {
        SendMessage($chat_id,"شما قبلا در ربات عضو بودید !");
      }
    }
  }
   if($from_id == $admin){
var_dump(makereq('sendMessage',[
        'chat_id'=>$update->message->chat->id,
        'text'=>"سلام ادمین گرامی به ربات فروشگاهی خود خوش آمدید
		از دکمه های زیر استفاده کنید.
		در ضمن میتوانید از پنل مدیریت برای مدیریت فروشگاه خود استفاده کنید♥",
        
        'reply_markup'=>json_encode([
            'keyboard'=>[
              [
                ['text'=>"محصولات 🛒"],['text'=>"خرید الماس 💎"]
              ],
       [
                ['text'=>"راهنما ⚠️"],['text'=>"الماس رایگان 🎁"]
              ],
        [
                  ['text'=>"پشتیبانی 👤"],['text'=>"اطلاعات حساب 💰"]
			  ],
		[
				  ['text'=>"انتقال الماس 💎"],['text'=>'کد هدیه 🏆']
              ],
			  [
			  ['text'=>"پنل مدیریت"],['text'=>"راهنمای مدیر"]
			  ],
            ]
        ])
    ]));
   }else{
	   var_dump(makereq('sendMessage',[
        'chat_id'=>$update->message->chat->id,
        'text'=>"
		سلام $name 👤
▪️▪️▪️▪️▪️▪️▪️▪️▪️▪️▪️▪️▪️

لطفا روی دکمه (راهنما ⚠️) کلیک کنید .
نگران نباشید این ربات کاملا اتوماتیک عمل میکند و بعد از پرداخت محصول خود را دریافت میکنید 💰
🆔 : @$channl
		",
        
        'reply_markup'=>json_encode([
            'keyboard'=>[
              [
                ['text'=>"محصولات 🛒"],['text'=>"خرید الماس 💎"]
              ],
       [
                ['text'=>"راهنما ⚠️"],['text'=>"الماس رایگان 🎁"]
              ],
        [
                  ['text'=>"پشتیبانی 👤"],['text'=>"اطلاعات حساب 💰"]
			  ],
		[
				  ['text'=>"انتقال الماس 💎"],['text'=>'کد هدیه 🏆']
              ],
            ]
        ])
    ]));
   }
}
    $txxt = file_get_contents('data/member.txt');
$pmembersid= explode("\n",$txxt);
	if (!in_array($chat_id,$pmembersid)) {
		$aaddd = file_get_contents('data/member.txt');
		$aaddd .= $chat_id."
";
    	file_put_contents('data/member.txt',$aaddd);
}
	elseif($textmessage == 'آمار 📊' && $chat_id == $admin)
	{
		$txtt = file_get_contents('data/member.txt');
		$membersidd= explode("\n",$txtt);
		$mmemcount = count($membersidd) -1;
{
sendmessage($chat_id,"*👥تعداد کل اعضای فروشگاه 👈*  `$mmemcount` *کاربر👤*");
}
}
elseif($textmessage == "خرید الماس 💎"){
$pay = file_get_contents("data/shopa.txt");
var_dump(makereq('sendmessage',[
   'chat_id'=>$chat_id,
   'text'=>"♡$pay",
   'reply_markup'=>json_encode([
   'keyboard'=>[
   [
   ['text'=>'بازگشت']
   ],
   ],
   'resize_keyboard'=>true,
   ])
   ]));
   }
 if($textmessage == '📮پیام به کاربر') {
	 if ($from_id = $admin) {
     
     sendmessage($chat_id,"متن پیام خود را وارد کنید");
     save("data/users/$from_id/step.txt","mess");
     }else{
     sendmessage($chat_id,"شما ادمین نیسید");
     }
     }
 if ($step == 'mess') {
    $tm = $textmessage;
    $myfile2 = fopen("data/message.txt", 'w') or die("Unable to open file!");	
fwrite($myfile2, "$tm\n");
fclose($myfile2);

    sendmessage($chat_id,"ای دی عددی کاربر را ارسال کنید");
    save("data/users/$from_id/step.txt","messa");
 }

    if ($step == 'messa') {
      $message = file_get_contents("data/message.txt");
      save("data/$from_id/users/step.txt","none");
      $f = $textmessage;
     sendmessage($f,"سلام $name 👋\n📝ادمین برای شما یک پیام ارسال کرد.\nمتن پیام↙️\n\n$message");
     sendmessage($admin,"پیام شما با موفقیت به کاربر موردنظر ارسال شد✅");
     
  
     }
elseif($textmessage == "راهنمای مدیر" and $from_id == $admin){
	sendMessage($chat_id," ادمین عزیز راهنمای پنل مدیریت به این شرح است:

بخش تنظیم کانال 
این بخش برای تنظیم کردن کانال سازنده ربات است و کد های رایگان به ان کانال ارسال می شود که تنظیم کردن آن الزامیست در غیر این صورت ربات به درستی عمل نمی کند.
➖➖➖➖➖➖➖➖➖➖
بخش کم کردن الماس 
برای کم کردن الماس از کاربر از دستور 
/getcoin id coin 
به جای id ایدی عددی کاربر را قرار دهید و به جای coin تعداد الماس 
مثال 
/getcoin 229364174 500
➖➖➖➖➖➖➖➖➖➖
ارسال الماس از دستور 
/addgem id coin
به جای id ایدی عددی کاربر را قرار دهید و به جای coin تعداد الماس 
مثال 
/addgem 229364174 500
➖➖➖➖➖➖➖➖➖➖
محصول جدید 
برای اضافه کردن محصول از این دستور استفاده کنید 
➖➖➖➖➖➖➖➖➖➖
حذف محصول 
برای حذف محصول از دستور
/delpost name 
به جای name اسم محصول رو وارد کنید 
مثال 
/delpost بمب اتم
➖➖➖➖➖➖➖➖➖➖
پیام همگانی
ارسال پیام به همه کاربران
 توجه داشته باشید اگر اولین بار است پیام همگانی میفرسید یک بار فروارد همگانی بفرسید تا این بخش فعال شود
➖➖➖➖➖➖➖➖➖➖
فروارد همگانی 
فروارد پیام به همه کاربران
➖➖➖➖➖➖➖➖➖➖
آمار 
آمار کاربران ربات 
➖➖➖➖➖➖➖➖➖➖
ساخت کد هدیه 
برای ساختن کد هدیه از دستور
/createcode CODE COIN
به جای CODE کد مورد نظر را قرار دهید و به جای COIN تعداد الماس را وارد کنید 
مثال 
/createcode shop 500
با این دستور کدی به نام shop ساخته می شود که تعداد 500الماس به کاربر میدهد.توجه ادمین بودن ربات در کانال الزامیست برای درست عمل کردن و کانال هم باید تنظیم باشه 
➖➖➖➖➖➖➖➖➖➖
پیام به کاربر 
ارسال پیام به کاربر
با تشکر تیم شاپ ساز❤️ ");
}
elseif ($textmessage == "پنل مدیریت" && $from_id == $admin){
var_dump(makereq('sendMessage',[
        'chat_id'=>$update->message->chat->id,
        'text'=>"*پنل مدیریت با موفقیت باز شد✅*\n\n_➖کانال خود را حتما تنظیم نمایید(از داخل دکمه |تنظیم کانال✔️|)_\n\n`یکی از دکمه هارا انتخاب کنید 👇`",
        'parse_mode'=>'MarkDown',
        'reply_markup'=>json_encode([
            'keyboard'=>[
			[
						['text'=>'تنظیم کانال✔️']
			],
			[
			['text'=>'🔧💰تنظیم متن فروش الماس💵🔧']
			],
	[
	['text'=>'📮پیام به کاربر']
	],
			 [
                ['text'=>"ارسال الماس 💰"],['text'=>"کم کردن الماس 💎"]
              ],
			  [
			    ['text'=>"حذف محصول 🛒"],['text'=>"محصول جدید 🛒"]
			  ],
			  [
			  ['text'=>"فروارد همگانی ✅"],['text'=>"پیام همگانی 👥"]     
			  ],
              [
              ['text'=>'ساخت کد هدیه 🎁'],['text'=>"آمار 📊"]
			  ],
			  ],
        ])
    ]));  
	}

elseif (strpos($textmessage,"/buy2142") !== false) {
  $id = str_replace("/buy2142","",$textmessage);
  $idd = $id - 9836;
  if ($idd == "") {
      SendMessage($chat_id,"`محصول در سیستم موجود نمیباشد ❎`");
  }
  else {
    if (file_exists("data/products/$idd.txt")) {
      $product = file_get_contents("data/products/$idd.txt");
      $array = explode("(******)",$product);
      $price = $array['3'];
      $coin = file_get_contents("data/users/$from_id/coin.txt");
      if ($coin >= $price) {
        $coin = file_get_contents("data/users/".$from_id."/coin.txt");
        settype($coin,"integer");
        $newcoin = $coin - $price;
        save("data/users/".$from_id."/coin.txt",$newcoin);
        SendMessage($chat_id,"محصول مورد نظر با موفقیت خریداری شد ✅");
        SendMessage($chat_id,"کد پیگیری ↙️
👉 2142$idd-$from_id$coin$admin$coin-5

[🌀جهت دانلود محصول خود کلیک نمایید🌀](".$array['2'].")");
      }
      else {
        SendMessage($chat_id,"`شما الماس کافی ندارید ⛔\nتعداد الماس های شما :` $coin");
      }
    }
    else {
      SendMessage($chat_id,"`محصول در سیستم موجود نمیباشد ❎`");
    }
  }

}
elseif ($textmessage == "ارسال الماس 💰" && $from_id == $admin){
sendMessage($chat_id,"ادمین عزیز جهت اهدای الماس به کاربری از دستور زیر استفاده کنید
/addgem USERID COIN

USERID = شناسه عددی کاربر
COIN = تعداد الماس");
}
elseif ($textmessage == "ساخت کد هدیه 🎁" && $from_id == $admin){
sendMessage($chat_id,"برای ساخت کد هدیه از دستور زیر استفاده کنید :
/createcode CODE COIN

CODE = کد موردنظر شما
COIN = تعداد الماس ها");
}
elseif ($textmessage == "کم کردن الماس 💎" && $from_id == $admin){
sendMessage($chat_id,"ادمین عزیز جهت کم کردن سکه کاربری از دستور زیر استفاده کنید
/getcoin USERID COIN

USERID = شناسه عددی کاربر
COIN = تعداد الماس");
}
elseif ($textmessage == "حذف محصول 🛒" && $from_id == $admin){
sendMessage($chat_id,"ادمین عزیز جهت حذف یک محصول از دستور زیر استفاده کنید
/delpost name

name = نام ب");
}
elseif (strpos($textmessage,"/getcoin") !== false && $from_id == $admin) {
  $text = explode(" ",$textmessage);
  if ($text['2'] != "" && $text['1'] != "") {
    $coin = file_get_contents("data/users/".$text['1']."/coin.txt");
    settype($coin,"integer");
    $newcoin = $coin - $text['2'];
    save("data/users/".$text['1']."/coin.txt",$newcoin);
    SendMessage($chat_id,"عملیات فوق با موفقیت انجام شد");
    SendMessage($text['1'],"ادمین از شما ".$text['2']." الماس کم کرد");
  }
  else {
    SendMessage($chat_id,"Syntax Error!");
  }
}
elseif (strpos($textmessage,"/delpost") !== false && $from_id == $admin) {
  $id = str_replace("/delpost ","",$textmessage);
  if (file_exists("data/products/$id.txt")) {
    $product = file_get_contents("data/products/$id.txt");
    $array = explode("(******)",$product);
    $title = $array['0'];
    unlink("data/products/$title.txt");
    unlink("data/products/$id.txt");
    SendMessage($chat_id,"محصول حذف شد");
  }
  else {
    SendMessage($chat_id,"محصول یافت نشد .");
  }
}
elseif (strpos($textmessage,"کد هدیه 🏆") !== false) {
  save("data/users/$from_id/step.txt","useCode");
var_dump(makereq('sendMessage',[
        'chat_id'=>$update->message->chat->id,
        'text'=>"`کد هدیه را ارسال کنید 💰 :`",
        'parse_mode'=>'MarkDown',
        'reply_markup'=>json_encode([
            'keyboard'=>[
              [
                ['text'=>"بازگشت"]
              ]
            ],
            'resize_keyboard'=>true
        ])
    ]));  
}
  //===============
elseif (strpos($textmessage,"/createcode") !== false && $from_id == $admin) {
  $text = explode(" ",$textmessage);
  $code = $text['1'];
  $value = $text['2'];
    save("data/codes/$code.txt","$value");
  SendMessage("@$channl","➖➖➖➖➖➖➖➖\n*کد جدید ساخته شد✅*\n\n*🔖 کد »* `$code`\n\n *💎 تعداد الماس »* `$value`\n➖➖➖➖➖➖➖➖\n*🌀هرکی زود کد بالا رو داخل فروشگاه و در بخش* `کد هدیه 🏆`*بزنه برندست🌀*\n➖➖➖➖➖➖➖➖\n*Time* ➡️ `$time`\n\n*Date* ➡️ `$date`\n➖➖➖➖➖➖➖➖");
}
elseif (strpos($textmessage,"/addgem") !== false && $from_id == $admin) {
  $text = explode(" ",$textmessage);
  if ($text['2'] != "" && $text['1'] != "") {
    $coin = file_get_contents("data/users/".$text['1']."/coin.txt");
    settype($coin,"integer");
    $newcoin = $coin + $text['2'];
    save("data/users/".$text['1']."/coin.txt",$newcoin);
    SendMessage($text['1'],"تعداد ".$text['2']." الماس به شما اضافه شد");
  }
  else {
    SendMessage($chat_id,"Syntax Error!");
  }
}

  //===============
  elseif($text == 'پشتیبانی 👤'){
  file_put_contents('data/users/'.$from_id."/command.txt","contact");
  SendMessage($chat_id,"`پیامتون رو در قالب یک متن ارسال کنید تا به دست پشتیبانی برسد :`
جهت لغو دستور :
/cancel
را ارسال کنید ➡");
  }
  elseif($command1 == 'contact'){
  if($text){
  file_put_contents('data/users/'.$from_id."/command.txt","none");
  SendMessage($chat_id,"پیام شما ثبت شد و بزودی جواب داده میشود ✅");
  if($from_username == null){
  $from_username = '---';
  }else{
  $from_username = "@$from_username";
  }
  SendMessage($admin,"
کاربری با مشخصات : 
$from_id
$username
یک پیام به شما ارسال کرد ✅
متن پیام :
 $text");
  }else{
  SendMessage($chat_id,"`فقط متن میتوانید ارسال کنید ❎ .`");
  }
  }
  //===============
elseif($textmessage == "راهنما ⚠️"){
sendMessage($chat_id,"`راهنما ربات فروشگاه 💰 :\n شما با این ربات میتوانید محصولات با ارزش را هم به صورت پولی و هم به صورت رایگان دریافت کنید 💸\nشما برای خرید محصولات نیاز به الماس دارید که میتوانید با کلیک بر روی دکمه (خرید الماس 💎) الماس بخرید\nپول کافی برای خرید الماس ندارید؟\nمشکلی نیست میتوانید با کلیک بر روی دکمه (الماس رایگان 🎁) الماس را به صورت رایگان دریافت کنید ☺️`\n🆔 @$channl");
}
elseif($textmessage == "الماس رایگان 🎁"){
sendMessage($chat_id,"سلام 🙃\nبرای دریافت الماس رایگان ابتدا ما به شما یک لینک اختصاصی میدیم 😚\nو هر 1 نفری که با لینک شما وارد ربات شوند تعداد 1 الماس دریافت میکنید 💎\nلینک شما در پیام بعدی ارسال میشود ☺️");
}
if($textmessage == "الماس رایگان 🎁"){

sendMessage($chat_id,"`لینک شما :` [https://telegram.me/$botids?start=$from_id]️");
}
elseif($textmessage == "اطلاعات حساب 💰"){
sendMessage($chat_id,"➖➖➖➖➖➖➖➖\n*👤نام شما :* `$name`\n*🌐یوزر ایدی شما :* `$from_id`\n*💎تعداد الماس های شما :* `$coin`\n➖➖➖➖➖➖➖➖");
}
else {
  if (file_exists("data/products/$textmessage.txt")) {
    $id = file_get_contents("data/products/$textmessage.txt");
    $product = file_get_contents("data/products/$id.txt");
    $idd = $id + 9836;
    $array = explode("(******)",$product);

    SendMessage($chat_id,"*🌐نام محصول 👈*  `".$array['0']."`

*📝توضیحات محصول ↙️*
    `".$array['1']."`

*💰قیمت محصول 👈* `".$array['3']." الماس 💎`

 *⭕️جهت لغو دستور* /cancel *را ارسال نمایید.*

*🔹خرید محصول با دستور* 👈   /buy2142".$idd);
  }
}unlink ("error_log");

if ($textmessage == 'تنظیم کانال✔️') {
   if ($from_id = $admin) {
$setc = file_get_contents("data/chan.txt");
if ($setc >= 1) {
sendmessage($chat_id,"شما یک کانال قبلا تنظیم کرده اید.اول کانال خود حذف کنید(در منوی اصلی ربات)سپس مجددا تلاش کنید");
}else{
   save("data/users/$from_id/step.txt","rob");
   var_dump(makereq('sendmessage',[
   'chat_id'=>$chat_id,
   'text'=>'مدیر گرامی ایدی کانال خود را بدون اتساین (@)  ارسال نمایید.
   ربات را حتما داخل کانال خود ادمین کنید زیرا کد های رایگان در کانال شما ارسال میشود!',
   'reply_markup'=>json_encode([
   'keyboard'=>[
   [
   ['text'=>'بازگشت']
   ],
   ],
   'resize_keyboard'=>true,
   ])
   ]));
   }
   }
   }
elseif($step == 'rob') {
$text = $textmessage;
$myfile2 = fopen("data/chan.txt", 'w') or die("Unable to open file!");	
fwrite($myfile2, "$text\n");
fclose($myfile2);
save("data/chann.txt","1");
SendMessage($chat_id,"کانال شما با موفقیت تنظیم شد✅");
save("data/users/$from_id/step.txt","none");
}

if ($textmessage == '🔧💰تنظیم متن فروش الماس💵🔧') {
    if ($from_id = $admin) {
  save("data/users/$from_id/step.txt","shopa");
  sendmessage($chat_id,"لطفا متن مود نظرتو وارد کن");
  }
  }
  if ($step == 'shopa') {
      $s = $textmessage;
      save("data/shopa.txt","$s");
     save("data/users/$from_id/step.txt","none"); sendmessage($chat_id,"عملیات با موفقیت انجام شد");
      
      }
      if ($textmessage == '/creator') {
sendmessage($chat_id,"🤖Create Your Robot😃
🤖ربات خود را بسازید😃👇
🆔 @FireCreateBot
✊️با سرور قوی و پرسرعت💪
ساخته شده توسط ربات ساز 👆");
}
?>