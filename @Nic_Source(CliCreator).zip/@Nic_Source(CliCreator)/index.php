<?php
error_reporting(0);
/*
✖️کانال نیک سورس✖️
مرجع تخصصی سورس ربات های تلگرامی:

🔸کانال ما:
➰ T.me/Nic_Source ➰

💥خرید هاست:
NicMizban.tk
*/
set_time_limit(0);

ob_start();
include("jdf.php");
$API_KEY = 'توکن';
define('API_KEY', $API_KEY);
function bot($method, $datas = [])
{
    $url = "https://api.telegram.org/bot" . API_KEY . "/" . $method;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $datas);
    $res = curl_exec($ch);
    if (curl_error($ch)) {
        var_dump(curl_error($ch));
    } else {
        return json_decode($res);
    }
}
//----------------------------------------------------------
function sendmessage($chat_id, $text)
{
    bot('sendMessage', [
        'chat_id' => $chat_id,
        'text' => $text,
        'parse_mode' => "MarkDown"
    ]);
}
 function deletefolder($path) { 
     if ($handle=opendir($path)) { 
       while (false!==($file=readdir($handle))) { 
         if ($file<>"." AND $file<>"..") { 
           if (is_file($path.'/'.$file))  { 
             @unlink($path.'/'.$file); 
             } 
           if (is_dir($path.'/'.$file)) { 
             deletefolder($path.'/'.$file); 
             @rmdir($path.'/'.$file); 
            } 
          } 
        } 
      } 
 }
function deletemessage($chat_id, $message_id)
{
    bot('deletemessage', [
        'chat_id' => $chat_id,
        'message_id' => $message_id,
    ]);
}

function sendaction($chat_id, $action)
{
    bot('sendchataction', [
        'chat_id' => $chat_id,
        'action' => $action
    ]);
}

function Forward($KojaShe, $AzKoja, $KodomMSG)
{
    bot('ForwardMessage', [
        'chat_id' => $KojaShe,
        'from_chat_id' => $AzKoja,
        'message_id' => $KodomMSG
    ]);
}

function sendphoto($chat_id, $photo, $action)
{
    bot('sendphoto', [
        'chat_id' => $chat_id,
        'photo' => $photo,
        'action' => $action
    ]);
}

	function EditMessageText($chat_id,$message_id,$text,$parse_mode,$disable_web_page_preview,$keyboard){
	 bot('editMessagetext',[
    'chat_id'=>$chat_id,
	'message_id'=>$message_id,
    'text'=>$text,
    'parse_mode'=>$parse_mode,
	'disable_web_page_preview'=>$disable_web_page_preview,
    'reply_markup'=>$keyboard
	]);
	}
function objectToArrays($object)
{
    if (!is_object($object) && !is_array($object)) {
        return $object;
    }
    if (is_object($object)) {
        $object = get_object_vars($object);
    }
    return array_map("objectToArrays", $object);
}
function save2($filename,$TXTdata)
  {
  $myfile = fopen($filename, "a") or die("Unable to open file!");
  fwrite($myfile, "$TXTdata");
  fclose($myfile);
  }
 //------------------------------------------------------------------------------
 $admin_keyboard = json_encode([
			'resize_keyboard'=>true,
                'keyboard' => [
                                     [
                        ['text' => "📊 آمار کلی ربات 📊"]
                    ],
				  [
					
                        ['text' => "🕹امتیاز ربات دوم🕹"],['text'=>"🖲امتیاز ویژه کردن🖲"]
                    ],
					  [
                    ['text' => "تنظیم امتیاز زیرمجموعه 🎗"], ['text' => "💥حذف ربات💥"]
                    ],
                   [
                        ['text' => "📌تنظیم چنل🔐"], ['text' => "✨ساخت کد امتیاز✨"]
                    ],
[
['text' => "💸 امتیاز به کاربر"],['text' => "هدیه همگانی 🎉"]
],
                    [
                        ['text' => "🗳 ارسال"], ['text' => "🗂 فروارد"]
                    ],
                    [
                        ['text' => "❌ بلاک"], ['text' => "♻️ انبلاک"]
                    ], 
                    
                  
                       [
                        ['text'=>"برگشت به منو اصلی"]
                    ]
                ]
            ]);
 $back_keyboard = json_encode([
     'resize_keyboard'=>true,
     'keyboard'=>[
         [['text'=>"🔚 برگشت به منوی ادمین"]]
         ]
     ]);
//-------------------------------------------------------------------
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$code = file_get_contents("data/code.txt");
$chid = $update->channel_post->message->message_id;
$chat_id = $message->chat->id;
$message_id = $message->message_id;
$from_id = $message->from->id;
$c_id = $message->forward_from_chat->id;
$rpto = $update->message->reply_to_message->forward_from->id;
$forward_id = $update->message->forward_from->id;
$forward_chat = $update->message->forward_from_chat;
$forward_chat_username = $update->message->forward_from_chat->username;
$forward_chat_msg_id = $update->message->forward_from_message_id;
$shoklt = file_get_contents("data/$chat_id/shoklat.txt");
$robot = file_get_contents("data/$chat_id/robot.txt");
$firstname = $message->from->first_name;
$lastname = $message->from->last_name;
$username = $message->from->username;
$sea = file_get_contents("data/$chat_id/membrs.txt");
$penlist = file_get_contents("data/pen.txt");
@$penlist = file_get_contents("data/pen.txt");
$text = $message->text;
@mkdir("data/$chat_id");
@$ali = file_get_contents("data/$chat_id/ali.txt");
@$list = file_get_contents("users.txt");
$ADMIN = ادمین 1;
$ADMI = ادمین2;
$channel = "@Nic_Source";//ایدی کانال
$host_folder = "https://pvsaz.hosteliya.ir/";//masir source
$idbot = file_get_contents("data/idbot.txt");
$uadmin = adaminsss;
$frosh = file_get_contents("data/frosh.txt");
$h = file_get_contents("data/h.txt");
$bnz = file_get_contents("data/bnz.txt");
$ct = file_get_contents("data/ct.txt");
$mb = file_get_contents("data/mb.txt");
$mg = file_get_contents("data/mg.txt");
$mch = file_get_contents("data/mch.txt");
$zm = file_get_contents("data/zm.txt");
$ms = file_get_contents("data/ms.txt");
$chtab = -1001160454989;
$kanal = file_get_contents("data/kanal.txt");
$channel = file_get_contents("data/channel.txt");
$channe2l = file_get_contents("data/channel2.txt");
$listbon = file_get_contents("data/pen.txt");
$chatid = $update->callback_query->message->chat->id;
$data = $update->callback_query->data;
$message_id2 = $update->callback_query->message->message_id;
$fromm_id = $update->inline_query->from->id;
$fromm_user = $update->inline_query->from->username;
$inline_query = $update->inline_query;
$query_id = $inline_query->id;
$inch = json_decode(file_get_contents("https://api.telegram.org/bot".API_KEY."/getChatMember?chat_id=@Creator_CliBot&user_id=$from_id"))->result->status;
$isjoin = bot('getChatMember',['chat_id'=>"@Creator_CliBot",'user_id'=>$from_id]);
$isjoin = $isjoin->result->status;
$message_id222 = $update->message->message_id;
//======================================رادین=============================================//
$fatime = jdate("h:i:s");
$fadate = jdate("Y F d");
$timing = date("Y-m-d-h-i-sa");
$timing = str_replace("am","",$timing);
$timing = str_replace("pm","",$timing);
	mkdir("flood");
$metti_khan = file_get_contents("flood/$timing-$from_id.txt");
$timing_spam = $metti_khan+1;
file_put_contents("flood/$timing-$from_id.txt","$timing_spam");

$metti_khan2 = file_get_contents("flood/$timing-$from_id.txt");
if($metti_khan2 >= 8){
SendMessage($chat_id, "شما به دلیل اسپم زدن بلاک شدید❌");
 $myfile2 = fopen("data/pen.txt", 'a') or die("Unable to open file!");
        fwrite($myfile2, "$from_id\n");
        fclose($myfile2);
return false;

}
  //===============
  //=========
    if (strpos($penlist , "$from_id") !== false) {
  return false;
  }
  elseif (strpos($block , "$from_id") !== false) {
  return false;
  }
  elseif ($from_id != $chat_id and $from_id != $admin1 and $chat_id != -1001290239207) {
  LeaveChat($chat_id);
  }
  elseif (strpos($penlist , "$from_id") !== false  ) {
  SendMessage($chat_id,"کاربر عزیز شما از ربات بلاک شدید🚫");
 }
  //===============
/* Button */
$button_vije = json_encode(['keyboard'=>[
[['text'=>"◻️◽️▫️حساب کاربری▫️◽️◻️"]],
[['text'=>"🎐رایگان🎐"],['text'=>'💰خرید💰']],
[['text'=>'🔙 برگشت به منوی اصلی']],
],'resize_keyboard'=>true]);
//------------------------------------------------------------
$button_official_fa = json_encode(['keyboard'=>[
[['text'=>'🛠ساخت ربات🛠']],
[['text'=>"🗑حذف ربات🗑"],['text'=>'👑ویژه کردن👑']],
[['text'=>'🤝زیـرمـجـموعـه گـیری🤝']],
[['text'=>"❇️آنلاین کردن ربات❇️"],['text'=>'🎁❨کـدرایگان ⃘⃭❩🎁']],
[['text'=>"👨🏻‍💻پشتیبانی آنلاین👩🏻‍💻"]],
[['text'=>'🌟راهنما🌟'],['text'=>"⛔️قوانین⛔️"]],
],'resize_keyboard'=>true]);
//-------------------------------------------------------------------------
$button_back2 = json_encode(['keyboard'=>[
[['text'=>'↩️برگشت به منوی ادمین']],
],'resize_keyboard'=>true]);
//------------------------------------------------------------------
$my = json_encode(['inline_keyboard'=>[
[
 ['text' => "𖤍ᴇʟɪʏᴀ™¦ نیک سورس𖤍", 'url' => "https://t.me/joinchat/AAAAAEUrI03tPkDF6ADSbg"]
],
]
]);
//----------------------------------------------------------------
$button_create = json_encode(['keyboard'=>[
[['text'=>"📡تبچی📡"],['text'=>"🚨ضدلینک🚨"]],
[['text'=>"⏳کلیکر⏳"],['text'=>"👤سلف بات🗣"]],
[['text'=>"🤹‍♂️سرگرمی🎭"]],
[['text'=>"💣اسپمر💣"],['text'=>"🛡آیدی دزد(تگ گیر)"]],
[['text'=>'🔙 برگشت به منوی اصلی']],
],'resize_keyboard'=>true]);
//-------------------------------------------------------------------
$button_zed = json_encode(['keyboard'=>[
[ ['text'=>"🚨ضدلینک نوع2️⃣"],['text'=>"🚨ضدلینک نوع1️⃣"]],
[['text'=>'🔙 برگشت به منوی اصلی']],
],'resize_keyboard'=>true]);
//-------------------------------------------------------------------
$button_name = json_encode(['keyboard'=>[
[ ['text'=>"👁‍🗨آی بازید🗨"],['text'=>"👁‍🗨دورباته🗯"]],
[['text'=>'🔙 برگشت به منوی اصلی']],
],'resize_keyboard'=>true]);
//-------------------------------------------------------------------
$button_tabi = json_encode(['keyboard'=>[
[ ['text'=>"🔻تبچی نوع دوم🔺"],['text'=>"🔻تبچی نوع اول🔺"]],
[['text'=>'🔙 برگشت به منوی اصلی']],
],'resize_keyboard'=>true]);
//-------------------------------------------------------------------
$button_fan = json_encode(['keyboard'=>[
[['text'=>"⏱تایم بوت⏰"],['text'=>"✂️کلینر✂️"]],
[['text'=>'🔙 برگشت به منوی اصلی']],
],'resize_keyboard'=>true]);
//------------------------------------------------------------------
$button_back = json_encode(['keyboard'=>[
[['text'=>'🔙 برگشت به منوی اصلی']],
],'resize_keyboard'=>true]);
//------------------------------------------------
if(!file_exists("data/$from_id")){file_put_contents("data/$from_id/membrs.txt","0");}
if ($text =="/start") {
    	if($isjoin != "left")
	{
        $user = file_get_contents('users.txt');
        $members = explode("\n", $user);
        if (!in_array($from_id, $members)) {
            $add_user = file_get_contents('users.txt');
            $add_user .= $from_id . "\n";
           
            file_put_contents('users.txt', $add_user);	
        }
        file_put_contents("data/$chat_id/ali.txt", "no");
        sendAction($chat_id, 'typing');
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "💎 سلــام $firstname 😺

✳️ به رباتساز آنلاین نیک سورس خوش اومدی❤️

✴️ با استفاده از این رباتساز میتوانید انواع رباتهای آنلاین بدون هیچ سروری بسازید و استفاده کنید.

⚜️ برای ساخت ربات دکمه (🛠ساخت ربات🛠) رو بزنید.

🆔 @Nic_Source",
'reply_to_message_id'=>$message_id,
 'reply_markup' => $button_official_fa
]);
	}
	else{
		bot('sendMessage',['chat_id'=>$chat_id,'text'=>"✅ دوست عزیز برای دریافت آخرین ‌اخبار ربات ابتدا وارد کانال زیر شوید:
🔰 @Mehdi_Yousefii
❇️و برای فعال شدن بات در چنل زیر جوین شوید:
🔰 @Nic_Source
📍پس از وارد شدن به کانالها به ربات برگردید و دستور:
📌 /start
را ارسال کنید تا به قسمت اصلی ربات وارد شوید.","html","true",$button_remove]);
	}
}
elseif (strpos($penlist, "$chat_id")!== false) {
        SendMessage($chat_id, "کاربر گرامی شما از سرور ما مسدود شده اید لطفا دیگر پیام نفرستید
باتشکر
اگر اشتباهی مسدود شدید به مدیریت خبر دهید تا شمارا ازاد کند
@Mehdi_Yousefii 👈ادمین");
    } elseif (strpos($text, '/start') !== false && $forward_chat_username == null) {
        $newid = str_replace("/start ", "", $text);
        if ($from_id == $newid) {
            bot('sendMessage', [
                'chat_id' => $chat_id,
                'text' => "❌نمیتونید با لینک خودتون عضو ربات بشید و امتیاز بگیرید",
                'reply_to_message_id'=>$message_id,
            ]);
        } elseif (strpos($list, "$from_id") !== false) {
            SendMessage($chat_id, "❌شما نمیتونید دو بار با لینک مخصوص عضو ربات بشید💯");
        } else {
            sendAction($chat_id, 'typing');
		    @$sho = file_get_contents("data/$newid/shoklat.txt");
            $getsho = $sho + $zm;
            file_put_contents("data/$newid/shoklat.txt", $getsho);
            @$sea = file_get_contents("data/$newid/membrs.txt");
            $getsea = $sea + 1;
            file_put_contents("data/$newid/membrs.txt", $getsea);
            $user = file_get_contents('users.txt');
            $members = explode("\n", $user);
            if (!in_array($from_id, $members)) {
                $add_user = file_get_contents('users.txt');
                $add_user .= $from_id . "\n";
           
                file_put_contents('users.txt', $add_user);
            }
            file_put_contents("data/$chat_id/ali.txt", "No");
            	if($isjoin != "left")
	{
            sendmessage($chat_id, "🦋عضویت شما رو تبریک میگم🦋
            ");
            bot('sendmessage', [
                'chat_id' => $chat_id,
                'text' => "💎 سلــام $firstname 😺

✳️ به رباتساز آنلاین نیک سورس خوش اومدی❤️

✴️ با استفاده از این رباتساز میتوانید انواع رباتهای آنلاین بدون هیچ سروری بسازید و استفاده کنید.

⚜️ برای ساخت ربات دکمه (🛠ساخت ربات🛠) رو بزنید.

🆔 @Nic_Source",
'reply_to_message_id'=>$message_id,
 'reply_markup' => $button_official_fa
]);
        SendMessage($newid, "️یک نفر با لینک شما عضو ربات شد

شما [$zm] امتیاز دریافت کردید");
  	}
	else{
		bot('sendMessage',['chat_id'=>$chat_id,'text'=>"✅ دوست عزیز برای دریافت آخرین ‌اخبار ربات ابتدا وارد کانال زیر شوید:
🔰 @Mehdi_Yousefii
❇️و برای فعال شدن بات در چنل زیر جوین شوید:
🔰 @Mehdi_Yousefii
📍پس از وارد شدن به کانالها به ربات برگردید و دستور:
📌 /start
را ارسال کنید تا به قسمت اصلی ربات وارد شوید.","html","true",$button_remove]);
	}      }
    }
elseif($inch != "member" && $inch != "creator" && $inch != "administrator"){
		bot('sendMessage',['chat_id'=>$chat_id,'text'=>"✅ دوست عزیز برای دریافت آخرین ‌اخبار ربات ابتدا وارد کانال زیر شوید:
🔰 @Mehdi_Yousefii
❇️و برای فعال شدن بات در چنل زیر جوین شوید:
🔰 @Nic_Source
📍پس از وارد شدن به کانالها به ربات برگردید و دستور:
📌 /start
را ارسال کنید تا به قسمت اصلی ربات وارد شوید.","html","true",$button_remove]);       
}

//============================نیک سورس==============================//
 elseif (($text == "🗑حذف ربات🗑")!== false) {
 var_dump(bot('sendMessage',[
 'chat_id' => $chat_id,
                'text' => "📛با حذف ربات تمامی اطلاعات ربات انلاینتون حذف خواهد شد و قابل برگشت نخواهد بود
❇️توجه کنید که اکانت ربات شما حذف نمیشود فقط سرور از اکانت خارج میشود و ربات غیرفعال میشود

🔰آیا موافقید رباتتون حذف شود؟؟
 ",
  'parse_mode'=>'MarkDown',
     'reply_markup'=>json_encode([
         'keyboard'=>[
         [['text'=>"حذف نکن❌"],['text'=>'حذف کن✅']],
         ],
         'resize_keyboard'=>true
     ])
 ]));
}
//---------------------------------------------------
 elseif (($text == "حذف کن✅")!== false) {

if(file_exists("cliBot/$chat_id")) {

deletefolder("cliBot/$chat_id");
DeleteFolder("cliBot/$chat_id");
rmdir("cliBot/$chat_id");
  unlink("radin/user/$chat_id/create.txt");  
   unlink("data/$chat_id/robot.txt");  
  file_put_contents("data/$chat_id/ali.txt", "no");
bot('sendmessage', [
'chat_id' => $chat_id,
'text' => "ربات شما با موفقیت حذف شد👍
✅هم اکنون میتونید یک ربات جدید بسازید",
'reply_to_message_id'=>$message_id,
       'reply_markup' => $button_official_fa
]);
}else {
bot('sendmessage', [
'chat_id' => $chat_id,
'text' => "⚠️شما تابحال رباتی نساخته اید!",
'reply_to_message_id'=>$message_id,
       'reply_markup' => $button_official_fa
]);
 }
}
//------------------------------------------------------
 elseif (($text == "حذف نکن❌")!== false) { 
  file_put_contents("data/$chat_id/ali.txt", "no");
bot('sendmessage', [
'chat_id' => $chat_id,
'text' => "♻️به منوی اصلی برگشتیم:",
'reply_to_message_id'=>$message_id,
       'reply_markup' => $button_official_fa
]);
}		
//============================رادین============================//
  elseif ($text == "👑ویژه کردن👑") {
    unlink("cod/$chat_id.txt");
        file_put_contents("data/$chat_id/ali.txt", "no");
        bot('SendMessage', [
            'chat_id' => $chat_id,
            'text' => "🎊به بخش ویژه کردن ربات خوش اومدی📥
✅باویژه کردن تعداد دفعات آفلاینی ربات شما کاهش یافته و به صفر میرسد
🎏از موارد زیر یکیو انتخاب کن📤
",
            'parse_mode' => "MarkDown",
            'reply_to_message_id'=>$message_id,
           'reply_markup' => $button_vije
]);
}
//============================رادین============================//
  elseif ($text == "🎐رایگان🎐") {
    unlink("cod/$chat_id.txt");
        file_put_contents("data/$chat_id/ali.txt", "no");
        bot('SendMessage', [
            'chat_id' => $chat_id,
            'text' => "🚨در حال حاضر تا اطلاع ثانوی بخش ویژه غیرفعال میباشد و  ویژه شدن تنها از طریق خرید انجام میشود
",
          
]);
}
//===========================================================//
elseif ($text == "🔙 برگشت به منوی اصلی") {
    unlink("cod/$chat_id.txt");
	
        file_put_contents("data/$chat_id/ali.txt", "no");
        bot('SendMessage', [
            'chat_id' => $chat_id,
            'text' => "📦 به صفحه اصلی ربات برگشتیم.
📍لطفا از دکمه های زیر یکی را انتخاب کنید.
",
            'parse_mode' => "MarkDown",
            'reply_to_message_id'=>$message_id,
           'reply_markup' => $button_official_fa
]);
}
//============================================================//
 elseif ($text == "◻️◽️▫️حساب کاربری▫️◽️◻️") {
        bot('sendmessage', [
            'chat_id' => $chat_id,
          
'text'=>"📲اطلاعات حساب کاربری شما:",
'parse_mode'=>'MarkDown',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[
['text'=>"👤》نام شما > { $firstname }",'callback_data'=>"Slm"]
],
[
['text'=>"👤》ایدی شما > {@$username}",'url'=>"http://t.me/$username"]
],
[
['text'=>"📱》شناسه شما > { $from_id }",'callback_data'=>"Slm"]
],
[
['text'=>"💫》امتیاز شما > { $shoklt }",'callback_data'=>"fg"],
], 
[
['text'=>"⚙️》وضیعت شما > { ✅فعال✅}",'callback_data'=>"fal"]
],
]
])
]);
}
//===============================================================//
    elseif (strpos($text,"🎁❨کـدرایگان ⃘⃭❩🎁") !== false) {
 file_put_contents("data/$chat_id/ali.txt","useCode");
 var_dump(bot('sendMessage',[
     'chat_id'=>$update->message->chat->id,
     'text'=>" 💰 کدی که در کانال ارسال شده را بفرستید",
     'parse_mode'=>'MarkDown',
     'reply_markup'=>json_encode([
         'keyboard'=>[
             [
                 ['text'=>"🔙 برگشت به منوی اصلی"]
             ]
         ],
         'resize_keyboard'=>true
     ])
 ]));
}
elseif ($ali == "useCode") {
 if (file_exists("data/code2.txt")) {
	 $code2 = file_get_contents("data/code2.txt");
  $sho = file_get_contents("data/$chat_id/shoklat.txt");
  settype($sho,"integer");
  $getsho = $sho + $code2;
  file_put_contents("data/$chat_id/shoklat.txt", $getsho);
  unlink("data/code2.txt");
  file_put_contents("data/$chat_id/ali.txt","none");
  var_dump(bot('sendMessage',[
      'chat_id'=>$update->message->chat->id,
      'text'=>"تبریک کد شما درست بود و شما برنده امتیاز رایگان شدید 🎉
        اونم $code2 امتیاز💰
✅حالا از قسمت ویژه کردن با این امتیازی که الان گرفتی برو رباتتو ویژه کن✨",
      'parse_mode'=>'MarkDown',
       'reply_markup' => $button_official_fa
  ]));
                      bot('sendMessage', [
                'chat_id' => "@$kanal",
                'text' => "
🎁کد: 🎈  $code 🎈
 
 استفاده شد💥

 🔥توسط :

 🌱نام فرد🌱  :  $firstname $lastname

🆔 ایدی فرد : $chat_id
 
⏰ساعت : $fatime

⚡️مبارکش ⚡️
منتظر کدهای جدید باشید✨
  ",
   ]);
 }
 else {
  SendMessage($chat_id,"این کد استفاده شده و شما نمیتونید مجدد استفاده کنید.😄
شایدم اشتباه میزنی کد رو🤔");
 }
}
//===============================================================//
elseif ($text == "🤝زیـرمـجـموعـه گـیری🤝") {
       $bot = bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
🔥رباتساز آنلاین نیک سورس😄

با قابلیت ساخت رباتهای آنلاین cli

💠قابلیت:
🔸سرور قدرتمند
🔹سرعت عالی_بدون افی
🔸ساخت ربات ضدلینک 
🔹ساخت ربات تبچی 
🔸ساخت ربات سلف
🔹ساخت ربات تگ گیر
🔸ساخت ربات کلیکر 
و.... 
برای ورود به رباتساز آنلاین نیک سورس🤩
لینک زیر را لمس کنید😎
https://telegram.me/Nic_Source?start=$chat_id",
        ])->result->message_id;
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "کاربر گرامی شما این بنر بالایی رو به دوستان ، کانال ، گروه های خود ارسال کنید 

هر یک کاربری که رو لینک شما بزند و وارد ربات شده و استارت را بزند شما $zm امتیاز دریافت میکنید",
'reply_to_message_id'=>$bot
        ]);
    }  
//======================================================//
	 elseif ($text == "💰خرید💰") {

bot('sendMessage',[
 'chat_id'=>$chat_id,  
 'text'=>'⭕'
 ]);
 sleep(0.3);
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'🔴🔴'
 ]);
sleep(0.3);
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'🔵🔵'
 ]);
 sleep(0.3);
bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'⚪️⚪️'
 ]);
 sleep(0.3);
bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'⚫️⚫️'
 ]);
 sleep(0.3);
bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'🔴🔴'
 ]);
 sleep(0.3);
bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'🔵🔵'
 ]);
 sleep(0.3);
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
            'text' => "🎈 برای ویژه کردن ربات خود با هزینه و دریافت تعرفه ها میتوانید به پشتیبانی مراجعه کنید.
",
'reply_to_message_id'=>$message_id,
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                ['text' => "⚜️حساب پشتیبانی⚜️", 'url' => "https://telegram.me/Mehdi_Yousefii"]
                    ]
                ]
            ])
        ]);
    }
//=======================Ch : @Nic_Source =====================//
   elseif ($text == "👨🏻‍💻پشتیبانی آنلاین👩🏻‍💻") {
	   file_put_contents("data/$chat_id/ali.txt", "ssp");
     	bot('sendmessage', [
            'chat_id' => $chat_id,
            'message_id' => $message_id2,
            'text' => "🎙خب حالا سوالی درخواستی انتقادی پیشنهادی داری بگو تا مستقیم به مدیر برسه و جوابتو در اسرع وقت ارسال کنه:",
     'parse_mode'=>'MarkDown',
     'reply_markup'=>json_encode([
         'keyboard'=>[
             [
                 ['text'=>"🔙 برگشت به منوی اصلی"]
             ]
         ],
         'resize_keyboard'=>true
     ])
 ]);

    } if ($ali == 'ssp' && $text != "🔙 برگشت به منوی اصلی") {
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "⏳باموفقیت ارسال شد منتظر پاسخ باشید⏳",
        ]);
			 bot('ForwardMessage',[
	'chat_id'=> "530419008",
	'from_chat_id'=>$from_id,
	'message_id'=>$message_id
	]);
    }

 elseif($rpto != "" && $chat_id == $ADMIN){
     bot('sendMessage',[
 'chat_id'=>$rpto,
 'text'=>"دوست عزیز شما یک پیام از طرف پشتیبانی ربات دریافت کردید✔️
------------------------------
$text",
 'parse_mode'=>"HTML",
	 ]);
	      bot('sendMessage',[
 'chat_id'=>$ADMIN,
 'text'=>"پیام شما به فرد ارسال شد✔️",
 'parse_mode'=>"HTML",
	 ]);    
    }	
	//--------------------------------------
	
	  elseif($text == "❇️آنلاین کردن ربات❇️"){
		  if(file_exists("cliBot/$chat_id")) {

					bot('sendmessage', [
'chat_id' => $chat_id,
'text' => "
🏵روی دکمه شیشه ای ضربه زده و لینک را در مرورگر خود باز کنید👇🏼",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                ['text' => "🌪آنلاین کردن🌪️", 'url' => "ادرس هاست/cli/cliBot/$chat_id/index.php"]
                    ]
                ]
            ])
        ]);
		}else {
bot('sendmessage', [
'chat_id' => $chat_id,
'text' => "⚠️شما تابحال رباتی نساخته اید!",
'reply_to_message_id'=>$message_id,
       'reply_markup' => $button_official_fa
]);
 }
}
//=======================Ch : @Nic_Source =====================//	
      elseif($text == "⛔️قوانین⛔️"){
        bot("sendMessage",[
            'chat_id'=>$chat_id,
            'text'=>"💯قوانین ساخت ربات:
🚫ربات های انلاین خودتونو در صورت نیاز بسازید درصورت مشاهده ربات الکی، ربات از سرور پاک خواهد شد📛

🔅 @Nic_Source 🔅",
'reply_to_message_id'=>$message_id,
            'parse_mode'=>'MarkDown'
            
            ]);
    }
//=======================Ch : @Nic_Source =====================//
    elseif($text == "🌟راهنما🌟"){
        bot("sendMessage",[
            'chat_id'=>$chat_id,
            'text'=>"♈️ با هر اکانت فقط میتونید یک ربات آنلاین بسازید
🕎 باهر اکانتی ک استارت میکنید و ربات میسازید همون اکانت ادمین ربات انلاین میباشد
♉️ برای ساخت ربات انلاین از قسمت (🛠ساخت ربات🛠) نوع ربات خودتونو انتخاب کنید و ورود به لینک ادامه ساخت رو بزنیذ
بعد Automatically رو انتخاب کنید و go رو بزنید بعد شماره و کد  بعد user رو انتخاب کنید و شماره و کد رو بزنید و تموم ربات انلاین شما ساخته شد😻

⚜️ @Nic_Source ⚜️",
'reply_to_message_id'=>$message_id,
            'parse_mode'=>'MarkDown'
            
            ]);
    }

//===============================================================================//
elseif($text == "🛠ساخت ربات🛠"){
    unlink("cod/$chat_id.txt");
        file_put_contents("data/$chat_id/ali.txt", "no");
        bot('SendMessage', [
            'chat_id'=>$chat_id,
            'text'=>"📌 خب دوست عزیز لطفا نوع ربات خود را برای ساخت انتخاب کنید",
            'parse_mode' => "MarkDown",
            'reply_to_message_id'=>$message_id,
            'reply_markup' => $button_create
]);
    }
//=======================================================//
		elseif($text == "🚨ضدلینک🚨"){
		
        $shoklt = file_get_contents("data/$chat_id/shoklat.txt");
        if ($shoklt >= 15 ) {
    unlink("cod/$chat_id.txt");
        file_put_contents("data/$chat_id/ali.txt", "no");
		
        bot('SendMessage', [
            'chat_id'=>$chat_id,
            'text'=>"🍃خب نوع ربات تونو انتخاب کنید:",
            'parse_mode' => "MarkDown",
            'reply_to_message_id'=>$message_id,
            'reply_markup' => $button_zed
]);
    
}else {
            bot('sendmessage', [
                'chat_id'=>$chat_id,
                'text' => "متاسفانه شما 15 امتیاز ندارید❌
🔘امتیازات شما: $shoklt
 با آوردن زیر مجموعه به ربات امتیاز خود را افزایش بدید.",
            ]);
        }
    }
//=======================================================//
	elseif($text == "📡تبچی📡"){
		  $shoklt = file_get_contents("data/$chat_id/shoklat.txt");
        if ($shoklt >= 10 ) {
    unlink("cod/$chat_id.txt");
        file_put_contents("data/$chat_id/ali.txt", "no");
        bot('SendMessage', [
            'chat_id'=>$chat_id,
            'text'=>"🐝خب نوع تبچی تونو انتخاب کنید:",
            'parse_mode' => "MarkDown",
            'reply_to_message_id'=>$message_id,
            'reply_markup' => $button_tabi
]);
     
}else {
            bot('sendmessage', [
                'chat_id'=>$chat_id,
                'text' => "متاسفانه شما 10 امتیاز ندارید❌
🔘امتیازات شما: $shoklt
 با آوردن زیر مجموعه به ربات امتیاز خود را افزایش بدید.",
            ]);
        }
    }
	
//=============================================================//
	elseif($text == "🔻تبچی نوع اول🔺"){
@$robot = file_get_contents("data/$chat_id/robot.txt");
          if ( 1 > $robot) {
//-----------------------------------------------------------------------------
			$index = file_get_contents("Source/tabi/index.php");
			$index = str_replace("**ADMIN**", $from_id, $index);
				$plugin = file_get_contents("Source/tabi/plugin.php");
			$plugin = str_replace("**ADMIN**", $from_id, $plugin);
//---------------------------------------------------------------------------------
	mkdir("cliBot/$chat_id");
	copy("Source/tabi/index.php","cliBot/$chat_id/index.php");
	copy("Source/tabi/plugin.php","cliBot/$chat_id/plugin.php");
	mkdir("cliBot/$chat_id/plugins");
	copy("Source/tabi/plugins/addall.php","cliBot/$chat_id/plugins/addall.php");
	copy("Source/tabi/plugins/countchats.php","cliBot/$chat_id/plugins/countchats.php");
	copy("Source/tabi/plugins/help.php","cliBot/$chat_id/plugins/help.php");
    copy("Source/tabi/plugins/ping.php","cliBot/$chat_id/plugins/ping.php");
	copy("Source/tabi/plugins/link.php","cliBot/$chat_id/plugins/link.php");
	copy("Source/tabi/plugins/option.php","cliBot/$chat_id/plugins/option.php");
	copy("Source/tabi/plugins/sendads.php","cliBot/$chat_id/plugins/sendads.php");
copy("Source/index.html","cliBot/$chat_id/index.html");
//------------------------------------------------------------------------------------------
	file_put_contents("cliBot/$chat_id/index.php",$index);
				file_put_contents("cliBot/$chat_id/plugin.php",$plugin);
//---------------------------------------------------------------------------------------------
@$robot = file_get_contents("data/$chat_id/robot.txt");
            $getbot = $robot + 1;
			 $sho = file_get_contents("data/$chat_id/shoklat.txt");
            $getshoo = $sho - 10;
            file_put_contents("data/$chat_id/shoklat.txt", $getshoo);
//------------------------------------------------------------------------------------------
bot('sendMessage',[
 'chat_id'=>$chat_id,  
 'text'=>'☑️درحال ساخت...'
 ]);
 sleep(0.5);
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'3️⃣'
 ]);
 sleep(0.5);
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'2️⃣'
 ]);
 sleep(0.5);
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'1️⃣'
 ]);
 sleep(0.5);
 
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'ربات شما تقریبا آماده است حالا از طریق پست بعدی ساخت رباتتو تکمیل کن✅'
 ]);
					bot('sendmessage', [
'chat_id' => $chat_id,
'text' => "ربات آنلاین #🔻تبچی نوع اول🔺
لینک مخصوص شما برای ساخت ربات ساخته شد🔅
❇️برای ساخت ربات انلاین خود روی دکمه شیشه ای یا لینک زیر ضربه بزنید و در صفحه باز شده اطلاعات خود را مرحله به مرحله وارد کنید تا ربات شما اماده شود.
 ✅توجه! ربات شما ویژه نیست و هر چند دقیقه یکبار اف میشود برای انلاین نگه داشتن ربات میتوانید با ارتباط با پشتیبان و یا دکمه روشن کردن که در صفحه اصلی وجود دارد کمک بگیرید.
 ❄️لینک شما :
 https://create-c/$chat_id/index.php",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                ['text' => "📌ورود به لینک ادامه ساخت ربات📍️", 'url' => "ادرس هاست/$chat_id/index.php"]
                    ]
                ]
            ])
        ]);
		  }	else {
            bot('sendmessage', [
                'chat_id'=>$chat_id,
                'text' => "⚠️در حال حاضر شما در سرور ما یک ربات دارید.
♻️برای ساخت ربات بیشتر به پشتیبانی ربات مراجعه کنید و یا ربات فعلی را از بخش حذف ربات پاک کنید و مجددا امتحان کنید.",
            ]);
        }
    }
		//==================================================
	elseif($text == "🚨ضدلینک نوع2️⃣"){
	  unlink("cod/$chat_id.txt");
        file_put_contents("data/$chat_id/ali.txt", "no");
        bot('SendMessage', [
            'chat_id'=>$chat_id,
            'text'=>"بزودی....",
           
]);
    }
	//==================================================
	elseif($text == "🔻تبچی نوع دوم🔺"){
	  unlink("cod/$chat_id.txt");
        file_put_contents("data/$chat_id/ali.txt", "no");
        bot('SendMessage', [
            'chat_id'=>$chat_id,
            'text'=>"بزودی....",
           
]);
    }
//============================================================//
elseif($text == "🤹‍♂️سرگرمی🎭"){
	  unlink("cod/$chat_id.txt");
        file_put_contents("data/$chat_id/ali.txt", "no");
        bot('SendMessage', [
            'chat_id'=>$chat_id,
            'text'=>"🍃خب نوع ربات تونو انتخاب کنید:",
            'parse_mode' => "MarkDown",
            'reply_to_message_id'=>$message_id,
            'reply_markup' => $button_fan
]);
    }
	
//=============================================================//
	elseif($text == "⏱تایم بوت⏰"){
@$robot = file_get_contents("data/$chat_id/robot.txt");
          if ( 1 > $robot) {
			  //-------------------------------------
	mkdir("cliBot/$chat_id");
	copy("Source/time/index.php","cliBot/$chat_id/index.php");
	copy("Source/time/jdf.php","cliBot/$chat_id/jdf.php");
	copy("Source/index.html","cliBot/$chat_id/index.html");
//---------------------------------------------------------------------------------------------
@$robot = file_get_contents("data/$chat_id/robot.txt");
            $getbot = $robot + 1;
            file_put_contents("data/$chat_id/robot.txt", $getbot);
//------------------------------------------------------------------------------------------
bot('sendMessage',[
 'chat_id'=>$chat_id,  
 'text'=>'☑️درحال ساخت...'
 ]);
 sleep(0.5);
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'3️⃣'
 ]);
 sleep(0.5);
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'2️⃣'
 ]);
 sleep(0.5);
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'1️⃣'
 ]);
 sleep(0.5);
 
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'ربات شما تقریبا آماده است حالا از طریق پست بعدی ساخت رباتتو تکمیل کن✅'
 ]);
					bot('sendmessage', [
'chat_id' => $chat_id,
'text' => "ربات آنلاین #⏱تایم بوت⏰
لینک مخصوص شما برای ساخت ربات ساخته شد🔅
❇️برای ساخت ربات انلاین خود روی دکمه شیشه ای یا لینک زیر ضربه بزنید و در صفحه باز شده اطلاعات خود را مرحله به مرحله وارد کنید تا ربات شما اماده شود.
 ✅توجه! ربات شما ویژه نیست و هر چند دقیقه یکبار اف میشود برای انلاین نگه داشتن ربات میتوانید با ارتباط با پشتیبان و یا دکمه روشن کردن که در صفحه اصلی وجود دارد کمک بگیرید.
 ❄️لینک شما :
 ادرس هاست/$chat_id/index.php",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                ['text' => "📌ورود به لینک ادامه ساخت ربات📍️", 'url' => "ادرس هاست/$chat_id/index.php"]
                    ]
                ]
            ])
        ]);
		  }	else {
            bot('sendmessage', [
                'chat_id'=>$chat_id,
                'text' => "⚠️در حال حاضر شما در سرور ما یک ربات دارید.
♻️برای ساخت ربات بیشتر به پشتیبانی ربات مراجعه کنید و یا ربات فعلی را از بخش حذف ربات پاک کنید و مجددا امتحان کنید.",
            ]);
        }
    }
		
//=============================================================//
	elseif($text == "✂️کلینر✂️"){
@$robot = file_get_contents("data/$chat_id/robot.txt");
          if ( 1 > $robot) {
//-----------------------------------------------------------------------------
			$config = file_get_contents("Source/clean/config.php");
			$config = str_replace("**ADMIN**", $from_id, $config);
//---------------------------------------------------------------------------------
	mkdir("cliBot/$chat_id");
	copy("Source/clean/config.php","cliBot/$chat_id/config.php");
	copy("Source/clean/chert.php","cliBot/$chat_id/chert.php");
	copy("Source/clean/index.php","cliBot/$chat_id/index.php");
	copy("Source/clean/PG.php","cliBot/$chat_id/PG.php");
	copy("Source/index.html","cliBot/$chat_id/index.html");
//------------------------------------------------------------------------------------------
	file_put_contents("cliBot/$chat_id/config.php",$config);
			
//---------------------------------------------------------------------------------------------
@$robot = file_get_contents("data/$chat_id/robot.txt");
            $getbot = $robot + 1;
            file_put_contents("data/$chat_id/robot.txt", $getbot);
//------------------------------------------------------------------------------------------
bot('sendMessage',[
 'chat_id'=>$chat_id,  
 'text'=>'☑️درحال ساخت...'
 ]);
 sleep(0.5);
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'3️⃣'
 ]);
 sleep(0.5);
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'2️⃣'
 ]);
 sleep(0.5);
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'1️⃣'
 ]);
 sleep(0.5);
 
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'ربات شما تقریبا آماده است حالا از طریق پست بعدی ساخت رباتتو تکمیل کن✅'
 ]);
					bot('sendmessage', [
'chat_id' => $chat_id,
'text' => "ربات آنلاین #✂️کلینر✂️
لینک مخصوص شما برای ساخت ربات ساخته شد🔅
❇️برای ساخت ربات انلاین خود روی دکمه شیشه ای یا لینک زیر ضربه بزنید و در صفحه باز شده اطلاعات خود را مرحله به مرحله وارد کنید تا ربات شما اماده شود.
 ✅توجه! ربات شما ویژه نیست و هر چند دقیقه یکبار اف میشود برای انلاین نگه داشتن ربات میتوانید با ارتباط با پشتیبان و یا دکمه روشن کردن که در صفحه اصلی وجود دارد کمک بگیرید.
 ❄️لینک شما :
 ادرس هاست/$chat_id/index.php",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                ['text' => "📌ورود به لینک ادامه ساخت ربات📍️", 'url' => "ادرس هاست/$chat_id/index.php"]
                    ]
                ]
            ])
        ]);
		  }	else {
            bot('sendmessage', [
                'chat_id'=>$chat_id,
                'text' => "⚠️در حال حاضر شما در سرور ما یک ربات دارید.
♻️برای ساخت ربات بیشتر به پشتیبانی ربات مراجعه کنید و یا ربات فعلی را از بخش حذف ربات پاک کنید و مجددا امتحان کنید.",
            ]);
        }
    }
	
//=============================================================//
	elseif($text == "🚨ضدلینک نوع1️⃣"){
@$robot = file_get_contents("data/$chat_id/robot.txt");
          if ( 1 > $robot) {
//-----------------------------------------------------------------------------
			$index = file_get_contents("Source/zed/index.php");
			$index = str_replace("**ADMIN**", $from_id, $index);
//---------------------------------------------------------------------------------
	mkdir("cliBot/$chat_id");
	copy("Source/zed/index.php","cliBot/$chat_id/index.php");
	copy("Source/zed/plugin.php","cliBot/$chat_id/plugin.php");
	copy("Source/zed/func.php","cliBot/$chat_id/func.php");
	mkdir("cliBot/$chat_id/plugins");
	copy("Source/zed/plugins/addrem.php","cliBot/$chat_id/plugins/addrem.php");
	copy("Source/zed/plugins/admin.php","cliBot/$chat_id/plugins/admin.php");
    copy("Source/zed/plugins/ping.php","cliBot/$chat_id/plugins/ping.php");
	copy("Source/zed/plugins/convert.php","cliBot/$chat_id/plugins/convert.php");
	copy("Source/zed/plugins/delmsg.php","cliBot/$chat_id/plugins/delmsg.php");
	copy("Source/zed/plugins/filter.php","cliBot/$chat_id/plugins/filter.php");
	copy("Source/zed/plugins/fun.php","cliBot/$chat_id/plugins/fun.php");
	copy("Source/zed/plugins/function.php","cliBot/$chat_id/plugins/function.php");	
	copy("Source/zed/plugins/lockunlock.php","cliBot/$chat_id/plugins/lockunlock.php");
	copy("Source/zed/plugins/msgcheck.php","cliBot/$chat_id/plugins/msgcheck.php");
	copy("Source/zed/plugins/mutehammer.php","cliBot/$chat_id/plugins/mutehammer.php");
	copy("Source/zed/plugins/other.php","cliBot/$chat_id/plugins/other.php");
	mkdir("cliBot/$chat_id/data");		
	copy("Source/zed/data/data.json","cliBot/$chat_id/data/data.json");
    copy("Source/zed/data/modration.json","cliBot/$chat_id/data/modration.json");
	copy("Source/zed/data/plugins.json","cliBot/$chat_id/data/plugins.json");
	copy("Source/index.html","cliBot/$chat_id/index.html");
	 $sho = file_get_contents("data/$chat_id/shoklat.txt");
            $getshoo = $sho - 15;
            file_put_contents("data/$chat_id/shoklat.txt", $getshoo);
//------------------------------------------------------------------------------------------
	file_put_contents("cliBot/$chat_id/index.php",$index);
			
//---------------------------------------------------------------------------------------------
@$robot = file_get_contents("data/$chat_id/robot.txt");
            $getbot = $robot + 1;
            file_put_contents("data/$chat_id/robot.txt", $getbot);
//------------------------------------------------------------------------------------------
bot('sendMessage',[
 'chat_id'=>$chat_id,  
 'text'=>'☑️درحال ساخت...'
 ]);
 sleep(0.5);
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'3️⃣'
 ]);
 sleep(0.5);
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'2️⃣'
 ]);
 sleep(0.5);
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'1️⃣'
 ]);
 sleep(0.5);
 
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'ربات شما تقریبا آماده است حالا از طریق پست بعدی ساخت رباتتو تکمیل کن✅'
 ]);
					bot('sendmessage', [
'chat_id' => $chat_id,
'text' => "ربات آنلاین #🚨ضدلینک نوع1️⃣
لینک مخصوص شما برای ساخت ربات ساخته شد🔅
❇️برای ساخت ربات انلاین خود روی دکمه شیشه ای یا لینک زیر ضربه بزنید و در صفحه باز شده اطلاعات خود را مرحله به مرحله وارد کنید تا ربات شما اماده شود.
 ✅توجه! ربات شما ویژه نیست و هر چند دقیقه یکبار اف میشود برای انلاین نگه داشتن ربات میتوانید با ارتباط با پشتیبان و یا دکمه روشن کردن که در صفحه اصلی وجود دارد کمک بگیرید.
 ❄️لینک شما :
 ادرس هاست/$chat_id/index.php",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                ['text' => "📌ورود به لینک ادامه ساخت ربات📍️", 'url' => "ادرس هاست/$chat_id/index.php"]
                    ]
                ]
            ])
        ]);
		  }	else {
            bot('sendmessage', [
                'chat_id'=>$chat_id,
                'text' => "⚠️در حال حاضر شما در سرور ما یک ربات دارید.
♻️برای ساخت ربات بیشتر به پشتیبانی ربات مراجعه کنید و یا ربات فعلی را از بخش حذف ربات پاک کنید و مجددا امتحان کنید.",
            ]);
        }
    }
	
//=============================================================//
	elseif($text == "👤سلف بات🗣"){
@$robot = file_get_contents("data/$chat_id/robot.txt");
          if ( 1 > $robot) {
//-----------------------------------------------------------------------------
			$index = file_get_contents("Source/self/index.php");
			$index = str_replace("**ADMIN**", $from_id, $index);
			$plugin = file_get_contents("Source/self/plugin.php");
			$plugin = str_replace("**ADMIN**", $from_id, $plugin);
//---------------------------------------------------------------------------------
	mkdir("cliBot/$chat_id");
	copy("Source/self/index.php","cliBot/$chat_id/index.php");
	copy("Source/self/plugin.php","cliBot/$chat_id/plugin.php");
	mkdir("cliBot/$chat_id/plugins");
	copy("Source/self/plugins/help.php","cliBot/$chat_id/plugins/help.php");
	copy("Source/self/plugins/option.php","cliBot/$chat_id/plugins/option.php");
    copy("Source/self/plugins/ping.php","cliBot/$chat_id/plugins/ping.php");
	copy("Source/index.html","cliBot/$chat_id/index.html");
//------------------------------------------------------------------------------------------
	file_put_contents("cliBot/$chat_id/index.php",$index);
			file_put_contents("cliBot/$chat_id/plugin.php",$plugin);
//---------------------------------------------------------------------------------------------
@$robot = file_get_contents("data/$chat_id/robot.txt");
            $getbot = $robot + 1;
            file_put_contents("data/$chat_id/robot.txt", $getbot);
//------------------------------------------------------------------------------------------
bot('sendMessage',[
 'chat_id'=>$chat_id,  
 'text'=>'☑️درحال ساخت...'
 ]);
 sleep(0.5);
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'3️⃣'
 ]);
 sleep(0.5);
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'2️⃣'
 ]);
 sleep(0.5);
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'1️⃣'
 ]);
 sleep(0.5);
 
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'ربات شما تقریبا آماده است حالا از طریق پست بعدی ساخت رباتتو تکمیل کن✅'
 ]);
					bot('sendmessage', [
'chat_id' => $chat_id,
'text' => "ربات آنلاین #👤سلف بات🗣
لینک مخصوص شما برای ساخت ربات ساخته شد🔅
❇️برای ساخت ربات انلاین خود روی دکمه شیشه ای یا لینک زیر ضربه بزنید و در صفحه باز شده اطلاعات خود را مرحله به مرحله وارد کنید تا ربات شما اماده شود.
 ✅توجه! ربات شما ویژه نیست و هر چند دقیقه یکبار اف میشود برای انلاین نگه داشتن ربات میتوانید با ارتباط با پشتیبان و یا دکمه روشن کردن که در صفحه اصلی وجود دارد کمک بگیرید.
 ❄️لینک شما :
 ادرس هاست/$chat_id/index.php",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                ['text' => "📌ورود به لینک ادامه ساخت ربات📍️", 'url' => "ادرس هاست/$chat_id/index.php"]
                    ]
                ]
            ])
        ]);
		  }	else {
            bot('sendmessage', [
                'chat_id'=>$chat_id,
                'text' => "⚠️در حال حاضر شما در سرور ما یک ربات دارید.
♻️برای ساخت ربات بیشتر به پشتیبانی ربات مراجعه کنید و یا ربات فعلی را از بخش حذف ربات پاک کنید و مجددا امتحان کنید.",
            ]);
        }
    }
	
//=============================================================//
	elseif($text == "🛡آیدی دزد(تگ گیر)"){
@$robot = file_get_contents("data/$chat_id/robot.txt");
          if ( 1 > $robot) {
//-----------------------------------------------------------------------------
			$index = file_get_contents("Source/tag/index.php");
			$index = str_replace("**ADMIN**", $from_id, $index);
				$plugin = file_get_contents("Source/tag/plugin.php");
			$plugin = str_replace("**ADMIN**", $from_id, $plugin);
				$set = file_get_contents("Source/tag/plugins/set.php");
			$set = str_replace("**ADMIN**", $from_id, $set);
//---------------------------------------------------------------------------------
	mkdir("cliBot/$chat_id");
	copy("Source/tag/index.php","cliBot/$chat_id/index.php");
	copy("Source/tag/plugin.php","cliBot/$chat_id/plugin.php");
	copy("Source/tag/ch.php","cliBot/$chat_id/ch.php");
	mkdir("cliBot/$chat_id/plugins");
	copy("Source/tag/plugins/del.php","cliBot/$chat_id/plugins/del.php");
	copy("Source/tag/plugins/id.php","cliBot/$chat_id/plugins/id.php");
	copy("Source/tag/plugins/list.php","cliBot/$chat_id/plugins/list.php");
    copy("Source/tag/plugins/ping.php","cliBot/$chat_id/plugins/ping.php");
	copy("Source/tag/plugins/set.php","cliBot/$chat_id/plugins/set.php");
	copy("Source/index.html","cliBot/$chat_id/index.html");
//------------------------------------------------------------------------------------------
	file_put_contents("cliBot/$chat_id/index.php",$index);
	file_put_contents("cliBot/$chat_id/plugin.php",$plugin);
	file_put_contents("cliBot/$chat_id/plugins/set.php",$set);
			
//---------------------------------------------------------------------------------------------
@$robot = file_get_contents("data/$chat_id/robot.txt");
            $getbot = $robot + 1;
            file_put_contents("data/$chat_id/robot.txt", $getbot);
//------------------------------------------------------------------------------------------
bot('sendMessage',[
 'chat_id'=>$chat_id,  
 'text'=>'☑️درحال ساخت...'
 ]);
 sleep(0.5);
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'3️⃣'
 ]);
 sleep(0.5);
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'2️⃣'
 ]);
 sleep(0.5);
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'1️⃣'
 ]);
 sleep(0.5);
 
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'ربات شما تقریبا آماده است حالا از طریق پست بعدی ساخت رباتتو تکمیل کن✅'
 ]);
					bot('sendmessage', [
'chat_id' => $chat_id,
'text' => "ربات آنلاین #🛡آیدی دزد(تگ گیر)🛡
لینک مخصوص شما برای ساخت ربات ساخته شد🔅
❇️برای ساخت ربات انلاین خود روی دکمه شیشه ای یا لینک زیر ضربه بزنید و در صفحه باز شده اطلاعات خود را مرحله به مرحله وارد کنید تا ربات شما اماده شود.
 ✅توجه! ربات شما ویژه نیست و هر چند دقیقه یکبار اف میشود برای انلاین نگه داشتن ربات میتوانید با ارتباط با پشتیبان و یا دکمه روشن کردن که در صفحه اصلی وجود دارد کمک بگیرید.
 ❄️لینک شما :
 ادرس هاست/$chat_id/index.php",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                ['text' => "📌ورود به لینک ادامه ساخت ربات📍️", 'url' => "ادرس هاست/$chat_id/index.php"]
                    ]
                ]
            ])
        ]);
		  }	else {
            bot('sendmessage', [
                'chat_id'=>$chat_id,
                'text' => "⚠️در حال حاضر شما در سرور ما یک ربات دارید.
♻️برای ساخت ربات بیشتر به پشتیبانی ربات مراجعه کنید و یا ربات فعلی را از بخش حذف ربات پاک کنید و مجددا امتحان کنید.",
            ]);
        }
    }
//=============================================================//
	elseif($text == "💣اسپمر💣"){
@$robot = file_get_contents("data/$chat_id/robot.txt");
          if ( 1 > $robot) {
//-----------------------------------------------------------------------------
			$index = file_get_contents("Source/spam/index.php");
			$index = str_replace("**ADMIN**", $from_id, $index);
			
//------------------------------------------------------------------------------
			$plugin = file_get_contents("Source/spam/plugin.php");
			$plugin = str_replace("**ADMIN**", $from_id, $plugin);
			
//---------------------------------------------------------------------------------
	mkdir("cliBot/$chat_id");
	copy("Source/spam/index.php","cliBot/$chat_id/index.php");
	copy("Source/spam/plugin.php","cliBot/$chat_id/plugin.php");
	copy("Source/index.html","cliBot/$chat_id/index.html");
//------------------------------------------------------------------------------------------
	file_put_contents("cliBot/$chat_id/index.php",$index);
			file_put_contents("cliBot/$chat_id/plugin.php",$plugin);
//---------------------------------------------------------------------------------------------
@$robot = file_get_contents("data/$chat_id/robot.txt");
            $getbot = $robot + 1;
            file_put_contents("data/$chat_id/robot.txt", $getbot);
//------------------------------------------------------------------------------------------
bot('sendMessage',[
 'chat_id'=>$chat_id,  
 'text'=>'☑️درحال ساخت...'
 ]);
 sleep(0.5);
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'3️⃣'
 ]);
 sleep(0.5);
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'2️⃣'
 ]);
 sleep(0.5);
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'1️⃣'
 ]);
 sleep(0.5);
 
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'ربات شما تقریبا آماده است حالا از طریق پست بعدی ساخت رباتتو تکمیل کن✅'
 ]);
					bot('sendmessage', [
'chat_id' => $chat_id,
'text' => "ربات آنلاین #اسپمر
لینک مخصوص شما برای ساخت ربات ساخته شد🔅
❇️برای ساخت ربات انلاین خود روی دکمه شیشه ای یا لینک زیر ضربه بزنید و در صفحه باز شده اطلاعات خود را مرحله به مرحله وارد کنید تا ربات شما اماده شود.
 ✅توجه! ربات شما ویژه نیست و هر چند دقیقه یکبار اف میشود برای انلاین نگه داشتن ربات میتوانید با ارتباط با پشتیبان و یا دکمه روشن کردن که در صفحه اصلی وجود دارد کمک بگیرید.
 ❄️لینک شما :
 ادرس هاست/$chat_id/index.php",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                ['text' => "📌ورود به لینک ادامه ساخت ربات📍️", 'url' => "ادرس هاست/$chat_id/index.php"]
                    ]
                ]
            ])
        ]);
		  }	else {
            bot('sendmessage', [
                'chat_id'=>$chat_id,
                'text' => "⚠️در حال حاضر شما در سرور ما یک ربات دارید.
♻️برای ساخت ربات بیشتر به پشتیبانی ربات مراجعه کنید و یا ربات فعلی را از بخش حذف ربات پاک کنید و مجددا امتحان کنید.",
            ]);
        }
    }
//===================================================================//
elseif($text == "⏳کلیکر⏳"){
	  $shoklt = file_get_contents("data/$chat_id/shoklat.txt");
        if ($shoklt >= 5 ) {
	  unlink("cod/$chat_id.txt");
        file_put_contents("data/$chat_id/ali.txt", "no");
        bot('SendMessage', [
            'chat_id'=>$chat_id,
            'text'=>"🍃خب نوع ربات تونو انتخاب کنید:",
            'parse_mode' => "MarkDown",
            'reply_to_message_id'=>$message_id,
            'reply_markup' => $button_name
]);
}else {
            bot('sendmessage', [
                'chat_id'=>$chat_id,
                'text' => "متاسفانه شما 5 امتیاز ندارید❌
🔘امتیازات شما: $shoklt
 با آوردن زیر مجموعه به ربات امتیاز خود را افزایش بدید.",
            ]);
        }
    }
//=============================================================//
	elseif($text == "👁‍🗨آی بازید🗨"){
@$robot = file_get_contents("data/$chat_id/robot.txt");
          if ( 1 > $robot) {
//-----------------------------------------------------------------------------
			$index = file_get_contents("Source/klick/index.php");
			$index = str_replace("**ADMIN**", $from_id, $index);
			
//------------------------------------------------------------------------------
			$plugin = file_get_contents("Source/klick/plugin.php");
			$plugin = str_replace("**ADMIN**", $from_id, $plugin);
			
//------------------------------------------------------------------------------------
			$clickbutton = file_get_contents("Source/klick/plugins/clickbutton.php");
			$clickbutton = str_replace("**ADMIN**", $from_id, $clickbutton);
			
//---------------------------------------------------------------------------------
	mkdir("cliBot/$chat_id");
	copy("Source/klick/index.php","cliBot/$chat_id/index.php");
	copy("Source/klick/plugin.php","cliBot/$chat_id/plugin.php");
	mkdir("cliBot/$chat_id/plugins");
	copy("Source/klick/plugins/clickbutton.php","cliBot/$chat_id/plugins/clickbutton.php");
	copy("Source/klick/plugins/help.php","cliBot/$chat_id/plugins/help.php");
	copy("Source/klick/plugins/ping.php","cliBot/$chat_id/plugins/ping.php");
	copy("Source/index.html","cliBot/$chat_id/index.html");
//------------------------------------------------------------------------------------------
	file_put_contents("cliBot/$chat_id/index.php",$index);
			file_put_contents("cliBot/$chat_id/plugin.php",$plugin);
			file_put_contents("cliBot/$chat_id/plugins/clickbutton.php",$clickbutton);
//---------------------------------------------------------------------------------------------
@$robot = file_get_contents("data/$chat_id/robot.txt");
            $getbot = $robot + 1;
            file_put_contents("data/$chat_id/robot.txt", $getbot);
			 $sho = file_get_contents("data/$chat_id/shoklat.txt");
            $getshoo = $sho - 5;
            file_put_contents("data/$chat_id/shoklat.txt", $getshoo);
//------------------------------------------------------------------------------------------
bot('sendMessage',[
 'chat_id'=>$chat_id,  
 'text'=>'☑️درحال ساخت...'
 ]);
 sleep(0.5);
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'3️⃣'
 ]);
 sleep(0.5);
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'2️⃣'
 ]);
 sleep(0.5);
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'1️⃣'
 ]);
 sleep(0.5);
 
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'ربات شما تقریبا آماده است حالا از طریق پست بعدی ساخت رباتتو تکمیل کن✅'
 ]);
					bot('sendmessage', [
'chat_id' => $chat_id,
'text' => "ربات آنلاین #کلیکر آی بازدید
لینک مخصوص شما برای ساخت ربات ساخته شد🔅
❇️برای ساخت ربات انلاین خود روی دکمه شیشه ای یا لینک زیر ضربه بزنید و در صفحه باز شده اطلاعات خود را مرحله به مرحله وارد کنید تا ربات شما اماده شود.
 ✅توجه! ربات شما ویژه نیست و هر چند دقیقه یکبار اف میشود برای انلاین نگه داشتن ربات میتوانید با ارتباط با پشتیبان و یا دکمه روشن کردن که در صفحه اصلی وجود دارد کمک بگیرید.
 ❄️لینک شما :
 ادرس هاست/$chat_id/index.php",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                ['text' => "📌ورود به لینک ادامه ساخت ربات📍️", 'url' => "ادرس هاست/$chat_id/index.php"]
                    ]
                ]
            ])
        ]);
		  }	else {
            bot('sendmessage', [
                'chat_id'=>$chat_id,
                'text' => "⚠️در حال حاضر شما در سرور ما یک ربات دارید.
♻️برای ساخت ربات بیشتر به پشتیبانی ربات مراجعه کنید و یا ربات فعلی را از بخش حذف ربات پاک کنید و مجددا امتحان کنید.",
            ]);
        }
    }
	//=============================================================//
	elseif($text == "👁‍🗨دورباته🗯"){
@$robot = file_get_contents("data/$chat_id/robot.txt");
        if ( 1 > $robot) {
         file_put_contents("data/$chat_id/ali.txt", "idadd");
							  bot('sendmessage', [
                'chat_id'=>$chat_id,
                'text' => "📌حالا آیدی عددی ربات خودتونو بفرستید:",
            ]);
					  }	else {
            bot('sendmessage', [
                'chat_id'=>$chat_id,
                'text' => "⚠️در حال حاضر شما در سرور ما یک ربات دارید.
♻️برای ساخت ربات بیشتر به پشتیبانی ربات مراجعه کنید و یا ربات فعلی را از بخش حذف ربات پاک کنید و مجددا امتحان کنید.",
            ]);
        }
 } elseif ($ali == "idadd") {
	         file_put_contents("data/$chat_id/idadd.txt", "$text");
	        file_put_contents("data/$chat_id/ali.txt", "token");
			@$robot = file_get_contents("data/$chat_id/robot.txt");
            $getbot = $robot + 1;
            file_put_contents("data/$chat_id/robot.txt", $getbot);
			 $sho = file_get_contents("data/$chat_id/shoklat.txt");
            $getshoo = $sho - 5;
            file_put_contents("data/$chat_id/shoklat.txt", $getshoo);
 var_dump(bot('sendMessage',[
     'chat_id'=>$update->message->chat->id,
                'text' => "✅ توکن ربات مورد نظر رو ارسال کنید.
اگر نمیدونید توکن چیست به صفحه اصلی برگشته و مطالب دکمه (راهنمای استفاده 🔖) را مطالعه کنید. ",
  'parse_mode'=>'MarkDown',
     'reply_markup'=>json_encode([
         'keyboard'=>[
             [
                 ['text'=>"🔙 برگشت به منوی اصلی"]
             ]
         ],
         'resize_keyboard'=>true
     ])
 ]));
    } elseif($ali == 'token'){
  if($update->message->forward_from != null){
  $rep = strchr($text,"Use this token to access the http API:");
  $rep = str_replace("Use this token to access the http API:",'',$rep);
  $rep = str_replace("For a description of the Bot API, see this page: https://core.telegram.org/bots/api",'',$rep);
  $rep = str_replace("\n",'',$rep);
  $token = $rep;
  }else{
  $token = $text;
  }
  $userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
  $resultb = objectToArrays($userbot);
  $username_bot = $resultb["result"]["username"];
  $id_bot = $resultb["result"]["id"];
  $first_bot = $resultb["result"]["first_name"];
  $ok = $resultb["ok"];
  if($ok != 1) {
  SendMessage($chat_id,"دوست عزیز توکن ربات شما نامعتبر است❌
لطفا یک توکن معتبر بفرستید✔️","html","true",$button_back);
  }else{
	  
	 if($username == null){
  $username = $first;
  }else{
  $username = "@".$username;
  }
	  
	mkdir("cliBot/$chat_id");
	mkdir("cliBot/$chat_id/plugins");
	
	copy("Source/klick2/index.php","cliBot/$chat_id/index.php");
	copy("Source/klick2/plugin.php","cliBot/$chat_id/plugin.php");
    copy("Source/klick2/data.json","cliBot/$chat_id/data.json");
    copy("Source/klick2/config.php","cliBot/$chat_id/config.php");
	copy("Source/klick2/plugins/helper.php","cliBot/$chat_id/plugins/helper.php");
	copy("Source/klick2/plugins/help.php","cliBot/$chat_id/plugins/help.php");
	copy("Source/klick2/plugins/coins.php","cliBot/$chat_id/plugins/coins.php");
	copy("Source/klick2/plugins/ping.php","cliBot/$chat_id/plugins/ping.php");
	copy("Source/klick2/plugins/k.php","cliBot/$chat_id/plugins/k.php");
	copy("Source/klick2/plugins/option.php","cliBot/$chat_id/plugins/option.php");
	copy("Source/klick2/plugins/clickbutton.php","cliBot/$chat_id/plugins/clickbutton.php");
	copy("Source/klick2/plugins/stats.txt","cliBot/$chat_id/plugins/stats.txt");
	copy("Source/klick2/plugins/bot.php","cliBot/$chat_id/plugins/bot.php");
	copy("Source/index.html","cliBot/$chat_id/index.html");
  $idadd  = file_get_contents("data/$chat_id/idadd.txt");
  $config = file_get_contents("Source/klick2/config.php");
  $config = str_replace("**token**",$token,$config);
  $config = str_replace("**idadd**",$idadd,$config);
  $config = str_replace("**ADMIN**",$from_id,$config);
  file_put_contents("cliBot/$chat_id/config.php",$config);
  
  $send = file_get_contents("Source/klick2/plugins/send.php");
  $send = str_replace("**ADMIN**", $from_id, $send);
  file_put_contents("cliBot/$chat_id/plugins/send.php",$send);
  
  
			$index = file_get_contents("Source/klick2/index.php");
			$index = str_replace("**ADMIN**", $from_id, $index);
			 file_put_contents("cliBot/$chat_id/index.php",$index);
			 
			$coins = file_get_contents("Source/klick2/plugins/coins.php");
			$coins = str_replace("**ADMIN**", $from_id, $coins);
			file_put_contents("cliBot/$chat_id/plugins/coins.php",$coins);
			
			$plugin = file_get_contents("Source/klick2/plugin.php");
			$plugin = str_replace("**ADMIN**", $from_id, $plugin);
			$plugin = str_replace("**username_bot**", $username_bot, $plugin);
			file_put_contents("cliBot/$chat_id/plugin.php",$plugin);
			
			$k = file_get_contents("Source/klick2/plugins/k.php");
			$k = str_replace("**ADMIN**", $from_id, $k);
	 	   file_put_contents("cliBot/$chat_id/plugins/k.php",$k);	
			  
bot('sendMessage',[
 'chat_id'=>$chat_id,  
 'text'=>'☑️درحال ساخت...'
 ]);
 sleep(0.5);
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'3️⃣'
 ]);
 sleep(0.5);
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'2️⃣'
 ]);
 sleep(0.5);
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'1️⃣'
 ]);
 sleep(0.5);
 
 bot('EditMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$message_id + 1,
 'text'=>'ربات شما تقریبا آماده است حالا از طریق پست بعدی ساخت رباتتو تکمیل کن✅'
 ]);
     file_put_contents("data/$chat_id/ali.txt","none");
	      file_put_contents("data/$chat_id/token.txt","none");
					bot('sendmessage', [
'chat_id' => $chat_id,
'text' => "ربات آنلاین #کلیکر آی بازدید
لینک مخصوص شما برای ساخت ربات ساخته شد🔅
❇️برای ساخت ربات انلاین خود روی دکمه شیشه ای یا لینک زیر ضربه بزنید و در صفحه باز شده اطلاعات خود را مرحله به مرحله وارد کنید تا ربات شما اماده شود.
 ✅توجه! ربات شما ویژه نیست و هر چند دقیقه یکبار اف میشود برای انلاین نگه داشتن ربات میتوانید با ارتباط با پشتیبان و یا دکمه روشن کردن که در صفحه اصلی وجود دارد کمک بگیرید.
 ❄️لینک شما :
 ادرس هاست/$chat_id/index.php",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                ['text' => "📌ورود به لینک ادامه ساخت ربات📍️", 'url' => "ادرس هاست/$chat_id/index.php"]
                    ]
                ]
            ])
        ]);
  }
  }
  
//===============================radin===============//
   if ($chatid == $ADMIN or $chat_id == $ADMIN) {
if(preg_match('/^\/([Pp][Aa][Nn][Ee][Ll])/',$text)){
        file_put_contents("data/$chat_id/ali.txt", "no");
        sendAction($chat_id, 'typing');
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "پنل باز شد",
            'parse_mode' => "MarkDown",
            'reply_to_message_id'=>$message_id,
            'reply_markup' => json_encode([
			'resize_keyboard'=>true,
             'keyboard' => [
                                     [
                        ['text' => "📊 آمار کلی ربات 📊"]
                    ],
				  [
					
                        ['text' => "🕹امتیاز ربات دوم🕹"],['text'=>"🖲امتیاز ویژه کردن🖲"]
                    ],
					  [
                    ['text' => "تنظیم امتیاز زیرمجموعه 🎗"], ['text' => "💥حذف ربات💥"]
                    ],
                   [
                        ['text' => "📌تنظیم چنل🔐"], ['text' => "✨ساخت کد امتیاز✨"]
                    ],
[
['text' => "💸 امتیاز به کاربر"],['text' => "هدیه همگانی 🎉"]
],
                    [
                        ['text' => "🗳 ارسال"], ['text' => "🗂 فروارد"]
                    ],
                    [
                        ['text' => "❌ بلاک"], ['text' => "♻️ انبلاک"]
                    ], 
                    
                  
                       [
                        ['text'=>"برگشت به منو اصلی"]
                    ]
                ]
            ])
        ]);
    } 
   //===============@$kanal================//

    elseif($text == "/admin" && $chat_id == $ADMIN){
    file_put_contents("data/$chat_id/ali.txt","none");
    sendAction($chat_id, 'typing');
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "مدیر گرامی به پنل مدیریت ربات ‌امتیاز ای خوش امدید 🙂",
            'parse_mode' => "MarkDown",
            'reply_to_message_id'=>$message_id,
            'reply_markup' => $admin_keyboard
            ]);
    }
	   
			//===============@$kanal================//
					elseif ($text == "📊 آمار کلی ربات 📊" && $chat_id == $ADMIN){
        $user = file_get_contents("users.txt");
        $member_id = explode("\n", $user);
        $member_count = count($member_id) - 1;
        $don = file_get_contents("data/done.txt");
        $enf = file_get_contents("data/enf.txt");
        bot('sendmessage', [
            'chat_id'=>$chat_id,
            'text' => "وضعیت ربات : 
 تعداد کاربران : $member_count
",
'reply_to_message_id'=>$message_id,
        ]);
    } elseif ($text == "🗳 ارسال" && $chat_id == $ADMIN ){
        file_put_contents("data/$chat_id/ali.txt", "send");
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "خوب پیام خودتون را برام بفرستید تا بفرستم برا  کاربرا  . بدو وقت ندارم 😑",
            'reply_to_message_id'=>$message_id,
            'reply_markup'=>$back_keyboard
        ]);
    } elseif ($ali == "send") {
        file_put_contents("data/$chat_id/ali.txt", "no");
        $fp = fopen("users.txt", 'r');
        while (!feof($fp)) {
            $ckar = fgets($fp);
            sendmessage($ckar, $text);
        }
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "با موفقیت برای همه کاربران ارسال شد",
            'reply_to_message_id'=>$message_id,
            'reply_markup' => $admin_keyboard
        ]);
    } elseif ($text == "🗂 فروارد" && $chat_id == $ADMIN){
        file_put_contents("data/$chat_id/ali.txt", "fwd");
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "خوب پیام خودتون را فروارد کنید فقط زود که حوصله ندارم 😤",
            'reply_to_message_id'=>$message_id,
            'reply_markup'=>$back_keyboard
        ]);
    } elseif ($ali == 'fwd') {
        file_put_contents("data/$chat_id/ali.txt", "no");
        $forp = fopen("users.txt", 'r');
        while (!feof($forp)) {
            $fakar = fgets($forp);
            Forward($fakar, $chat_id, $message_id);
        }
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "با موفقیت فروارد شد.",
            'reply_to_message_id'=>$message_id,
            'reply_markup' => $admin_keyboard
        ]);
    } elseif ($text == "❌ بلاک" && $chat_id == $ADMIN ){
       
        file_put_contents("data/$chat_id/ali.txt", "pen");
       bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "فقط ایدی عددیشو بفرست تا بلاک بشه از ربات 😡",
            'reply_to_message_id'=>$message_id,
            'reply_markup'=>$back_keyboard
        ]);
    } elseif ($ali == 'pen') {
        $myfile2 = fopen("data/pen.txt", 'a') or die("Unable to open file!");
        fwrite($myfile2, "$text\n");
        fclose($myfile2);
        file_put_contents("data/$chat_id/ali.txt", "No");
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => " با موفقیت بلاکش کردم 😤
 ایدیش هم 
 $text ",
 'reply_to_message_id'=>$message_id,
            'parse_mode' => "MarkDown",
            'reply_markup' => $admin_keyboard
        ]);
    } elseif ($text == "♻️ انبلاک" && $chat_id == $ADMIN){
        
        file_put_contents("data/$chat_id/ali.txt", "unpen");
       bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "خوب ی بخشیدی حالا . ایدی عددیشو بدع تا انبلاکش کنم 😕",
            'reply_to_message_id'=>$message_id,
'reply_markup'=>$back_keyboard
        ]);
    } elseif ($ali == 'unpen') {
        $newlist = str_replace($text, "", $penlist);
        file_put_contents("data/pen.txt", $newlist);
        file_put_contents("data/$chat_id/ali.txt", "No");
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "حله انبلاک کردمش
 ایدیش هم 
 $text ",
 'reply_to_message_id'=>$message_id,
 'reply_markup' => $admin_keyboard
        ]);
    } 
	///////////////////////////////////////
 elseif (($text == "💥حذف ربات💥") && $chat_id == $ADMIN) {

            file_put_contents("data/$chat_id/ali.txt", "addil");
    bot('sendmessage', [
            'chat_id' => $chat_id,
                'text' => "
📛ایدی ربات طرفو  بدون @ بفرست تا بگا بدمش😎
 ",
  'reply_to_message_id'=>$message_id,
            'reply_markup'=>$back_keyboard
        ]);
    }
    elseif ($ali == "addil") {
			DeleteFolder("Bots/$text");
		rmdir("Bots/$text");
	  unlink("Bots/$text/index.php");
  unlink("Bots/$text/Class.php");
  unlink("radin/user/$chat_id/create.txt");  
$file="index";
$folder="Bots/$text";
$open= opendir($folder);
while($read=readdir($open)){
if(is_file($del=$folder."/".$file))
{
unlink($del);
}
}
closedir($open);
rmdir($folder);
  file_put_contents("data/$chat_id/ali.txt", "no");
            bot('sendMessage', [
                'chat_id' => $chat_id,
                'text' => "ربات طرف با موفقیت بگا رفت و حذف شد👍
 ",
'reply_to_message_id'=>$message_id,
       'reply_markup' => $admin_keyboard
]);
}
		
    //===============@$kanal================//
    elseif ($text == "✨ساخت کد امتیاز✨" && $chat_id == $ADMIN){
        
        file_put_contents("data/$chat_id/ali.txt", "crl");
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "خوب یه عدد بگو سرورم🙏🏻",
            'reply_to_message_id'=>$message_id,
            'reply_markup'=>$back_keyboard
        ]);
    } elseif ($ali == 'crl') {
        file_put_contents("data/code.txt", $text);
        file_put_contents("data/$chat_id/ali.txt", "crl2");
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "خوب تعدادبازدید ها چقدر باشه",
            'reply_to_message_id'=>$message_id,
            'reply_markup'=>$back_keyboard
        ]);
    } elseif ($ali == 'crl2') {
        $code = file_get_contents("data/code.txt");
        $code2 = file_get_contents("data/code2.txt");
        file_put_contents("data/code2.txt", $text);
        file_put_contents("data/$chat_id/ali.txt", "");
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "حله کد شما ساخته شد  ",
 'reply_to_message_id'=>$message_id,
 'reply_markup' => $admin_keyboard
        ]);
    } 
  elseif ($text == "/radin" && $chat_id == $ADMIN) {
        
       deletefolder("flood");
DeleteFolder("flood");
rmdir("flood");
  unlink("flood/***.txt");  
        bot('sendMessage', [
            'chat_id' => $chat_id,
           'text' => "کش هاستينگ پاکسازي شد",
 'reply_to_message_id'=>$message_id,
 'reply_markup' => $admin_keyboard
        ]);
    }
elseif ($text == "تنظیم امتیاز زیرمجموعه 🎗" && $chat_id == $ADMIN) {
        
        file_put_contents("data/$chat_id/ali.txt", "setzm");
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "عددی وارد کنید",
            'reply_to_message_id'=>$message_id,
            'reply_markup'=>$back_keyboard
        ]);
    } elseif ($ali == 'setzm') {
        file_put_contents("data/zm.txt", $text);
        file_put_contents("data/$chat_id/ali.txt", "No");
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "تنظیم شد",
 'reply_to_message_id'=>$message_id,
 'reply_markup' => $admin_keyboard
        ]);
    }
	elseif ($text == "تنظیم درصد زیرمجموعه 🤹‍♀️" && $chat_id == $ADMIN) {
        
        file_put_contents("data/$chat_id/ali.txt", "setms");
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "عددی وارد کنید",
            'reply_to_message_id'=>$message_id,
            'reply_markup'=>$back_keyboard
        ]);
    } elseif ($ali == 'setms') {
        file_put_contents("data/ms.txt", $text);
        file_put_contents("data/$chat_id/ali.txt", "No");
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "تنظیم شد",
 'reply_to_message_id'=>$message_id,
 'reply_markup' => $admin_keyboard
        ]);
    }
    elseif($text == "هدیه همگانی 🎉" && $chat_id == $ADMIN){
    file_put_contents("data/$chat_id/ali.txt", "hadi");
       sendAction($chat_id, 'typing');
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "💰 مقدار امتیاز مورد نظر رو وارد کنید:",
            'reply_to_message_id'=>$message_id,
            'reply_markup'=>$back_keyboard
        ]);
    } elseif ($ali == 'hadi') {
    if(preg_match('/^([0-9])/',$text)){
    file_put_contents("data/$chat_id/ali.txt","none");
    SendMessage($chat_id,"💰 مقدار امتیاز به زودی به همه اضافه میشود.","html","true",$button_manage);
    $all_member = fopen("users.txt", 'r');
        while (!feof($all_member)) {
             $user = fgets( $all_member);
            $user = str_replace(" ",'',$user);
            $user = str_replace("\n",'',$user);
            $cn = file_get_contents("data/$user/shoklat.txt");
            file_put_contents("data/$user/shoklat.txt",($cn+$text) );
        }
        SendMessage($chat_id,"💰 تعداد $text امتیاز به همه اعضا اضافه شد.","html","true");
    }else{
    SendMessage($chat_id,"💰 لطفا به عدد وارد کنید در غیر اینصورت مشکل بزرگی پیش خواهد آمد.","html","true",$button_back);
    }
    }
    //===============@$kanal================//
    elseif ($text == "افزودن ادمین 👤" && $chat_id == $ADMIN) {
        
        file_put_contents("data/$chat_id/ali.txt", "setadmin");
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "ایدی عددیشو بده",
            'reply_to_message_id'=>$message_id,
            'reply_markup'=>$back_keyboard
        ]);
    } elseif ($ali == 'setadmin') {
        file_put_contents("data/admin2.txt", $text);
        file_put_contents("data/$chat_id/ali.txt", "No");
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "تنظیم شد",
 'reply_to_message_id'=>$message_id,
 'reply_markup' => $admin_keyboard
        ]);
    }
  elseif ($text == "🖲امتیاز ویژه کردن🖲" && $chat_id == $ADMIN) {
        
        file_put_contents("data/$chat_id/ali.txt", "setvij");
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "🖲مقدار امتیاز برای ویژه کردن ربات  رو بفرست:",
            'reply_to_message_id'=>$message_id,
            'reply_markup'=>$back_keyboard
        ]);
    } elseif ($ali == 'setvij') {
        file_put_contents("data/vije.txt", $text);
        file_put_contents("data/$chat_id/ali.txt", "No");
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "⚜️تنظیم شد⚜️",
 'reply_to_message_id'=>$message_id,
 'reply_markup' => $admin_keyboard
        ]);
    }
	    elseif ($text == "📌تنظیم چنل🔐" && $chat_id == $ADMIN) {
        
        file_put_contents("data/$chat_id/ali.txt", "setkan");
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "آیدی کانالی که میخوای ربات روش قفل بشه رو بدون @ بفرست
⚠️ حتما ربات باید مدیر اون کانال باشه",
            'reply_to_message_id'=>$message_id,
            'reply_markup'=>$back_keyboard
        ]);
    } elseif ($ali == 'setkan') {
        file_put_contents("data/kanal.txt", $text);
        file_put_contents("data/$chat_id/ali.txt", "No");
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "⚜️تنظیم شد⚜️",
 'reply_to_message_id'=>$message_id,
 'reply_markup' => $admin_keyboard
        ]);
    }
	   elseif ($text == "🕹امتیاز ربات دوم🕹" && $chat_id == $ADMIN) {
        
        file_put_contents("data/$chat_id/ali.txt", "setdo");
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "🖲مقدار امتیاز یرای ساختن ربات دوم رو بفرست:",
            'reply_to_message_id'=>$message_id,
            'reply_markup'=>$back_keyboard
        ]);
    } elseif ($ali == 'setdo') {
        file_put_contents("data/botdo.txt", $text);
        file_put_contents("data/$chat_id/ali.txt", "No");
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "⚜️تنظیم شد⚜️",
 'reply_to_message_id'=>$message_id,
 'reply_markup' => $admin_keyboard
        ]);
    }
     elseif ($text == "💸 امتیاز به کاربر" && $chat_id == $ADMIN) {
        
        file_put_contents("data/$chat_id/ali.txt", "buy");
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "خوب ایدی عددی کاربر را بفرست️",
            'reply_to_message_id'=>$message_id,
            'reply_markup'=>$back_keyboard
        ]);
    } elseif ($ali == 'buy') {
        file_put_contents("data/buy.txt", $text);
        file_put_contents("data/$chat_id/ali.txt", "buy2");
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "خوب تعداد امتیاز ها چقدر باشه",
            'reply_to_message_id'=>$message_id,
            'parse_mode' => "MarkDown",
            'reply_markup'=>$back_keyboard
        ]);
    } elseif ($ali == 'buy2') {
    $buy = file_get_contents("data/buy.txt");
          $fle = file_get_contents("data/$buy/shoklat.txt");
               $getshe = $fle + $text;
                file_put_contents("data/$buy/shoklat.txt", $getshe);
        file_put_contents("data/$chat_id/ali.txt", "");
        bot('sendMessage', [
            'chat_id' => $buy,
            'text' => "کاربر عزیز ...
مقدار $text امتیاز از طرف مدیریت به شما ارسال شد !!"
        ]);
        bot('sendMessage', [
                    'chat_id' => $chat_id,
            'text' => "با موفقیت فرستاده شد",
            'reply_to_message_id'=>$message_id,
            'reply_markup' => $admin_keyboard
        ]);
    }
    

}
 if ($chatid == $ADMIN or $chat_id == $ADMI) {
if(preg_match('/^\/([Pp][Aa][Nn][Ee][Ll])/',$text)){
        file_put_contents("data/$chat_id/ali.txt", "no");
        sendAction($chat_id, 'typing');
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "پنل باز شد",
            'parse_mode' => "MarkDown",
            'reply_to_message_id'=>$message_id,
            'reply_markup' => json_encode([
			'resize_keyboard'=>true,
             'keyboard' => [
                                     [
                        ['text' => "📊 آمار کلی ربات 📊"]
                    ],
			
				
                   [
                 ['text' => "💸 امتیاز به کاربر"], ['text' => "✨ساخت کد امتیاز✨"]
                    ],               [
                        ['text' => "🗳 ارسال"], ['text' => "🗂 فروارد"]
                    ],
                    [
                        ['text' => "❌ بلاک"], ['text' => "♻️ انبلاک"]
                    ], 
                    
                  
                       [
                        ['text'=>"برگشت به منو اصلی"]
                    ]
                ]
            ])
        ]);
    } 

			//===============@$kanal================//
					elseif ($text == "📊 آمار کلی ربات 📊" && $chat_id == $ADMI){
        $user = file_get_contents("users.txt");
        $member_id = explode("\n", $user);
        $member_count = count($member_id) - 1;
        $don = file_get_contents("data/done.txt");
        $enf = file_get_contents("data/enf.txt");
        bot('sendmessage', [
            'chat_id'=>$chat_id,
            'text' => "وضعیت ربات : 
 تعداد کاربران : $member_count
",
'reply_to_message_id'=>$message_id,
        ]);
    } elseif ($text == "🗳 ارسال" && $chat_id == $ADMI ){
        file_put_contents("data/$chat_id/ali.txt", "send");
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "خوب پیام خودتون را برام بفرستید تا بفرستم برا  کاربرا  . بدو وقت ندارم 😑",
            'reply_to_message_id'=>$message_id,
            'reply_markup'=>$back_keyboard
        ]);
    } elseif ($ali == "send") {
        file_put_contents("data/$chat_id/ali.txt", "no");
        $fp = fopen("users.txt", 'r');
        while (!feof($fp)) {
            $ckar = fgets($fp);
            sendmessage($ckar, $text);
        }
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "با موفقیت برای همه کاربران ارسال شد",
            'reply_to_message_id'=>$message_id,
            'reply_markup' => $admin_keyboard
        ]);
    } elseif ($text == "🗂 فروارد" && $chat_id == $ADMI){
        file_put_contents("data/$chat_id/ali.txt", "fwd");
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "خوب پیام خودتون را فروارد کنید فقط زود که حوصله ندارم 😤",
            'reply_to_message_id'=>$message_id,
            'reply_markup'=>$back_keyboard
        ]);
    } elseif ($ali == 'fwd') {
        file_put_contents("data/$chat_id/ali.txt", "no");
        $forp = fopen("users.txt", 'r');
        while (!feof($forp)) {
            $fakar = fgets($forp);
            Forward($fakar, $chat_id, $message_id);
        }
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "با موفقیت فروارد شد.",
            'reply_to_message_id'=>$message_id,
            'reply_markup' => $admin_keyboard
        ]);
    } elseif ($text == "❌ بلاک" && $chat_id == $ADMI ){
       
        file_put_contents("data/$chat_id/ali.txt", "pen");
       bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "فقط ایدی عددیشو بفرست تا بلاک بشه از ربات 😡",
            'reply_to_message_id'=>$message_id,
            'reply_markup'=>$back_keyboard
        ]);
    } elseif ($ali == 'pen') {
        $myfile2 = fopen("data/pen.txt", 'a') or die("Unable to open file!");
        fwrite($myfile2, "$text\n");
        fclose($myfile2);
        file_put_contents("data/$chat_id/ali.txt", "No");
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => " با موفقیت بلاکش کردم 😤
 ایدیش هم 
 $text ",
 'reply_to_message_id'=>$message_id,
            'parse_mode' => "MarkDown",
            'reply_markup' => $admin_keyboard
        ]);
    } elseif ($text == "♻️ انبلاک" && $chat_id == $ADMI){
        
        file_put_contents("data/$chat_id/ali.txt", "unpen");
       bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "خوب ی بخشیدی حالا . ایدی عددیشو بدع تا انبلاکش کنم 😕",
            'reply_to_message_id'=>$message_id,
'reply_markup'=>$back_keyboard
        ]);
    } elseif ($ali == 'unpen') {
        $newlist = str_replace($text, "", $penlist);
        file_put_contents("data/pen.txt", $newlist);
        file_put_contents("data/$chat_id/ali.txt", "No");
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "حله انبلاک کردمش
 ایدیش هم 
 $text ",
 'reply_to_message_id'=>$message_id,
 'reply_markup' => $admin_keyboard
        ]);
    } 
	     elseif ($text == "💸 امتیاز به کاربر" && $chat_id == $ADMI) {
        
        file_put_contents("data/$chat_id/ali.txt", "buy");
        bot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "خوب ایدی عددی کاربر را بفرست️",
            'reply_to_message_id'=>$message_id,
            'reply_markup'=>$back_keyboard
        ]);
    } elseif ($ali == 'buy') {
        file_put_contents("data/buy.txt", $text);
        file_put_contents("data/$chat_id/ali.txt", "buy2");
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "خوب تعداد امتیاز ها چقدر باشه",
            'reply_to_message_id'=>$message_id,
            'parse_mode' => "MarkDown",
            'reply_markup'=>$back_keyboard
        ]);
    } elseif ($ali == 'buy2') {
    $buy = file_get_contents("data/buy.txt");
          $fle = file_get_contents("data/$buy/shoklat.txt");
               $getshe = $fle + $text;
                file_put_contents("data/$buy/shoklat.txt", $getshe);
        file_put_contents("data/$chat_id/ali.txt", "");
        bot('sendMessage', [
            'chat_id' => $buy,
            'text' => "کاربر عزیز ...
مقدار $text امتیاز از طرف مدیریت به شما ارسال شد !!"
        ]);
        bot('sendMessage', [
                    'chat_id' => $chat_id,
            'text' => "با موفقیت فرستاده شد",
            'reply_to_message_id'=>$message_id,
            'reply_markup' => $admin_keyboard
        ]);
    }
    

}
unlink('error_log');
//-----------@Nic_Source-------------//
?>
