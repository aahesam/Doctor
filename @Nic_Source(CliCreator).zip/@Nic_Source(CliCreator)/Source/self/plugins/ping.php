<?php
if (in_array($userID, $admins)){
if($msg == 'ping' || $msg == 'Ping' || $msg == 'ربات' || $msg == 'آنلاینی' || $msg == 'انلاینی'){
$MadelineProto->messages->sendMessage(['peer' => $chatID, 'reply_to_msg_id' => $msg_id ,'message' => "🔜بیست چهارساعت اماده به خدمت😎
🔜﻿ **I'm twenty four hours old** 😎
",'parse_mode' => 'html']);
}
}
 // @EliyaTeaM