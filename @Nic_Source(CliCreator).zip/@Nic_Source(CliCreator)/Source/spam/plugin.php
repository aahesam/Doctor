<?php
if(preg_match("/^[\/\#\!]?(spam) ([0-9]+) (.*)$/i", $msg)){
preg_match("/^[\/\#\!]?(spam) ([0-9]+) (.*)$/i", $msg, $text);
$count = $text[2];
$id = $text[3];
for($i=1; $i <= $count; $i++){
$MadelineProto->messages->sendMessage(['peer' => $id, 'message' => '😂😂😂😂😂😂']);
}
}
if($msg == 'ping'){
    $MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' => "I AM Online :)"]);
}
if($msg == 'help'){
    $MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' => "💠 راهنمای اسپمر ایلیاتیم👇

💢 ping 👉 جهت اطلاع از وضعیت ربات
💢 spam [ tedad , id ] اسپم به ایدی عددی 

💠 مثال 👇👇 
spam 20 513461818

🆔 👉 @EliyaTM"]);
}