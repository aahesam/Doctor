<?php
/*
✖️کانال نیک سورس✖️
مرجع تخصصی سورس ربات های تلگرامی:

🔸کانال ما:
➰ T.me/Nic_Source ➰

💥خرید هاست:
NicMizban.tk
*/
if (!file_exists('madeline.php')) {
    copy('https://phar.madelineproto.xyz/madeline.php', 'madeline.php');
}
include ('jdf.php');
include 'madeline.php';


$MadelineProto = new \danog\MadelineProto\API('session.madeline');
$MadelineProto->start();

$day_number = jdate('j');
$month_number = jdate('n');
$year_number = jdate('y');
$day_name = jdate('l');
$time = date("h:i");

$MadelineProto->account->updateProfile(['about' => "امروز $day_name 😄 $year_number/$month_number/$day_number 🕘 $time"]);

