#!/bin/bash
composer update || composer.phar update
. start.sh
