#cd MadelineProto
#git am -3 < ../patches/0001-Remove-log-spam.patch
echo "You no longer need this! Daniil finally came to his senses and removed his logging spam"
