<?php
if(isset($from_id)){
if($from_id == $admin){
if(isset($update['update']['message']['reply_to_msg_id'])){
$msgid = $update['update']['message']['reply_to_msg_id'];
try{
$mah = $MadelineProto->channels->getMessages(['channel' => $peer, 'id' => [$msgid]]);
$file_name = explode(".",$mah['messages'][0]['media']['document']['attributes'][0]['file_name']);

}catch(Exception $e){

    }
   
if(preg_match("/^(پلاگین) (.*)$/i", $message)){
								preg_match("/^(پلاگین) (.*)$/i", $message, $m);
if (preg_match("/[0-9a-zA-Z]+/", $m[2])) {
if($file_name[1]=="php"){
if(!file_exists("plugins/".$m[2]."php")){
               $MadelineProto->download_to_file($mah['messages'][0]['media'], 'plugins/'.$m[2].".php");
$insert = json_decode(file_get_contents("data/plugins.json"),true);
$insert[$m[2]] = "+";
$u = json_encode($insert,true);
file_put_contents("data/plugins.json",$u);
                        $MadelineProto->messages->sendMessage(['peer' => $peer, 'reply_to_msg_id'=>$mid,'message' =>"پلاگین ".$m[2]." با موفقیت به لیست پلاگین افزوده شد"]);
}else{
$MadelineProto->messages->sendMessage(['peer' => $peer, 'reply_to_msg_id'=>$mid,'message' =>"پلاگین ".$m[2]." در لیست پلاگین قرار دارد"]);
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $peer, 'reply_to_msg_id'=>$mid,'message' =>"فرمت فایل اشتباه است لطفا فایل مورد نظر را برسی کنید"]);
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $peer, 'reply_to_msg_id'=>$mid,'message' =>"لطفا از کارکتر های انگلیسی برای ذخیره فایل استفاده کنید"]);
}
}}
/////-/-/-/-/-/-/-/-/
$q = explode(" ",$message);
if($q[0] == "پلاگ" && isset($q[1]) && isset($q[2])){						
if($q[2] != ""){
if (preg_match("/[0-9a-zA-Z]+/", $q[2])) {
if(file_exists("plugins/".$q[2].".php")){
if($q[1] == "+"){$on = "فعال";}else{$on = "غیرفعال";}
$insert = json_decode(file_get_contents("data/plugins.json"),true);
$insert[$q[2]] = "$q[1]";
$u = json_encode($insert,true);
file_put_contents("data/plugins.json",$u);
$MadelineProto->messages->sendMessage(['peer'=>$peer,'reply_to_msg_id'=>$mid,'message'=>"پلاگین ".$q[2]." با موفقیت ".$on." شد"]);
}else{
$MadelineProto->messages->sendMessage(['peer'=>$peer,'reply_to_msg_id'=>$mid,'message'=>"پلاگین ".$q[2]." درلیست پلاگین ها قرار ندارد"]);
}
}else{
$MadelineProto->messages->sendMessage(['peer'=>$peer,'reply_to_msg_id'=>$mid,'message'=>"برای فعال یا غیرفعال سازی لطفا نام پلاگین را انگلیسی وارد کنید"]);
}
}else{
$MadelineProto->messages->sendMessage(['peer'=>$peer,'reply_to_msg_id'=>$mid,'message'=>"پلاگین مورد نظر وجود ندارد لطفا مقدار سوم را چک کنید"]);
}
}///end+-
///-/-/-/-/-/-/-/-/-/
if(preg_match("/^(لیست پلاگین)$/i", $message)){
$info = json_decode(file_get_contents("data/plugins.json"),true);
$list = $info;
$lists = "";
foreach($list as $key=>$value){


$value = str_replace("+","✔️",$value);
$value = str_replace("-","✖️️",$value);

$lists .= "🔹`".$key."` : `".$value."`\n〰➰〰➰〰➰〰➰〰\n";
}//endforeach
$MadelineProto->messages->sendMessage(['peer'=>$peer,'reply_to_msg_id'=>$mid,'message'=>"لیست پلاگین\n".$lists,'parse_mode'=>"MarkDown"]);
}//endlist
}///endadmin
}

$p = json_decode(file_get_contents("data/plugins.json"),true);
//$plist = $p['plist'];

foreach($p as $key=>$value){
if($value == "+"){
if(isset($chat_id)){
$plists = $key.".php";
include("plugins/".$plists);
}}
}

?>
