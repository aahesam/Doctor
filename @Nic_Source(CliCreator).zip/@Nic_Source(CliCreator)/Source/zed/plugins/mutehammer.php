﻿<?php
if(in_array($chat_id,$mange['grouplist'])){
if(isset($update['update']['_']) && ($update['update']['_'] == "updateNewChannelMessage")){
$data = json_decode(file_get_contents("data/$chat_id.json"),true);
if($data[$chat_id]['add']=="✅"){
if($from_id == $admin or in_array($from_id,$data[$chat_id]['ownerlist']) or in_array($from_id,$data[$chat_id]['modlist'])){
if(preg_match("/^(سکوت)$/i", $message)){
if(isset($update['update']['message']['reply_to_msg_id'])){
$msgid = $update['update']['message']['reply_to_msg_id'];
try{
$mah = $MadelineProto->channels->getMessages(['channel' => $chat_id, 'id' => [$msgid]]);
$ID = $mah['users'][0]['id'];
$FIRST = $mah['users'][0]['first_name'];

$key = array_search($ID,$data[$chat_id]['silentlist']);
}catch(Exception $e){

}
if($ID != $admin && !in_array($ID,$data[$chat_id]['ownerlist']) && !in_array($ID,$data[$chat_id]['modlist'])){
if($key !== false){
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》کاربر [$FIRST](tg://user?id=$ID) در لیست #سایلنت(بیصدا) قرار داشت و توانایی چت کردن در گروه را نداشت",'parse_mode'=>"MarkDown"]);
}else{
$data[$chat_id]['silentlist'][]=$ID;
$in = json_encode($data,true);
file_put_contents("data/$chat_id.json",$in);
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》کاربر [$FIRST](tg://user?id=$ID) به لیست #سایلنت(بیصداها) اضافه شد و دیگر توانایی چت کردن در گروه را ندارد",'parse_mode'=>"MarkDown"]);
}
}else{
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》شما نمیتوانید مدیران ربات ، مالک گروه ، و مدیر ربات را به لیست #بیصداها اضافه کنید"]);
}
}
}

if(preg_match("/^(رفع سکوت)$/i", $message)){
if(isset($update['update']['message']['reply_to_msg_id'])){
$msgid = $update['update']['message']['reply_to_msg_id'];
try{
$mah = $MadelineProto->channels->getMessages(['channel' => $chat_id, 'id' => [$msgid]]);
$ID = $mah['users'][0]['id'];
$FIRST = $mah['users'][0]['first_name'];
}catch(Exception $e){

}

if(in_array($ID,$data[$chat_id]["silentlist"])){
$key = array_search($ID,$data[$chat_id]["silentlist"]);
unset($data[$chat_id]["silentlist"][$key]);
$data[$chat_id]["silentlist"] = array_values($data[$chat_id]["silentlist"]);
$js = json_encode($data,true);
file_put_contents("data/$chat_id.json",$js);
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》کاربر [$FIRST](tg://user?id=$ID) از لیست #سایلنت(بیصدا) حذف شد و توانایی چت کردن در گروه را به دست اورد",'parse_mode'=>"MarkDown"]);
}else{
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》کاربر [$FIRST](tg://user?id=$ID) در لیست افراد #سایلنت(بیصدا) قرار ندارد",'parse_mode'=>"MarkDown"]);
}
}
}
if(preg_match("/^(لیست بیصداها)$/i", $message)){
$sl = $data[$chat_id]['silentlist'];
$ct = count($sl) - 1;
$tet = "";
if($sl[0] != ""){
for($i = 0;$i <= $ct; $i++){
$chi = $data[$chat_id]['silentlist'][$i];
$tet .= "User : [$chi](tg://user?id=$chi)\n➖➖➖➖➖➖➖\n";
}
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》لیست #بیصداها گروه\n".$tet,'parse_mode'=>"MarkDown"]);
}else{

$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》لیست #بیصداها گروه خالی میباشد"]);
}
}

if(preg_match("/^(پاک کردن لیست بیصداها)$/i", $message)){
unset($data[$chat_id]['silentlist']);
$data[$chat_id]['silentlist'] = [];
$Json = json_encode($data,true);
file_put_contents("data/$chat_id.json",$Json);
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》لیست #سایلنت(بیصداها) به صورت کامل پاکسازی شد"]);
}
////banlist
if(preg_match("/^(مسدود)$/i", $message)){
if(isset($update['update']['message']['reply_to_msg_id'])){
$msgid = $update['update']['message']['reply_to_msg_id'];
try{
$mah = $MadelineProto->channels->getMessages(['channel' => $chat_id, 'id' => [$msgid]]);
$ID = $mah['users'][0]['id'];
$FIRST = $mah['users'][0]['first_name'];

$key = array_search($ID,$data[$chat_id]['banlist']);
}catch(Exception $e){

}
if($ID != $admin && !in_array($ID,$data[$chat_id]['ownerlist']) && !in_array($ID,$data[$chat_id]['modlist'])){
if($key !== false){
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》کاربر [$FIRST](tg://user?id=$ID) در لیست #مسدود قرار داشت و از گروه محروم بود!",'parse_mode'=>"MarkDown"]);
}else{
$data[$chat_id]['banlist'][]=$ID;
$in = json_encode($data,true);
file_put_contents("data/$chat_id.json",$in);
BanUser($chat_id,$ID);
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》کاربر [$FIRST](tg://user?id=$ID) به لیست #مسدود اضافه شد و از گروه اخراج شد و دیگر توانایی عضو شدن در گروه را ندارد",'parse_mode'=>"MarkDown"]);
}
}else{
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》شما نمیتوانید مدیران ربات ، مالک گروه ، و مدیر ربات را به لیست #مسدود اضافه کنید"]);
}
}
}

if(preg_match("/^(رفع مسدود)$/i", $message)){
if(isset($update['update']['message']['reply_to_msg_id'])){
$msgid = $update['update']['message']['reply_to_msg_id'];
try{
$mah = $MadelineProto->channels->getMessages(['channel' => $chat_id, 'id' => [$msgid]]);
$ID = $mah['users'][0]['id'];
$FIRST = $mah['users'][0]['first_name'];
}catch(Exception $e){

}

if(in_array($ID,$data[$chat_id]["banlist"])){
$key = array_search($ID,$data[$chat_id]["banlist"]);
unset($data[$chat_id]["banlist"][$key]);
$data[$chat_id]["banlist"] = array_values($data[$chat_id]["banlist"]);
$js = json_encode($data,true);
file_put_contents("data/$chat_id.json",$js);
UnBanUser($chat_id,$ID);
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》کاربر [$FIRST](tg://user?id=$ID) از لیست #مسدود حذف شد و توانایی عضو شدن در گروه را دارد",'parse_mode'=>"MarkDown"]);
}else{
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》کاربر [$FIRST](tg://user?id=$ID) در لیست افراد #مسدود قرار ندارد",'parse_mode'=>"MarkDown"]);
}
}
}


if(preg_match("/^(لیست مسدود)$/i", $message)){
$sl = $data[$chat_id]['banlist'];
$ct = count($sl) - 1;
$tet = "";
if($sl[0] != ""){
for($i = 0;$i <= $ct; $i++){
$chi = $data[$chat_id]['banlist'][$i];
$tet .= "User : [$chi](tg://user?id=$chi)\n➖➖➖➖➖➖➖\n";
}
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》لیست #مسدود گروه\n".$tet,'parse_mode'=>"MarkDown"]);
}else{

$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》لیست #مسدود گروه خالی میباشد"]);
}
}

if(preg_match("/^(پاک کردن لیست مسدود)$/i", $message)){
unset($data[$chat_id]['banlist']);
$data[$chat_id]['banlist'] = [];
$Json = json_encode($data,true);
file_put_contents("data/$chat_id.json",$Json);
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》لیست #مسدود به صورت کامل پاکسازی شد"]);
}
}
}
}
}
?>
