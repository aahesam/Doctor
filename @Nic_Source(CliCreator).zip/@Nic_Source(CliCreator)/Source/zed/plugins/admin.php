﻿<?php
if(in_array($chat_id,$mange['grouplist']) && file_exists("data/$chat_id.json")){
$data = json_decode(file_get_contents("data/$chat_id.json"),true);
if(isset($update['update']['_']) && ($update['update']['_'] == "updateNewChannelMessage")){
if($data[$chat_id]['add'] == "✅"){
if(strpos($message,"ترفیع")!==false){
if($from_id == $admin or in_array($from_id,$data[$chat_id]['ownerlist'])){
if(isset($update['update']['message']['reply_to_msg_id'])){
try{
$msgid = $update['update']['message']['reply_to_msg_id'];
$mah = $MadelineProto->channels->getMessages(['channel' => $chat_id, 'id' => [$msgid]]);
$ID = $mah['users'][0]['id'];
$FIRST = $mah['users'][0]['first_name'];
$key = array_search($ID,$data[$chat_id]['modlist']);
if(in_array($ID,$data[$chat_id]['modlist'])){
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》کاربر $FIRST در لیست مدیران قرار داشت"]);
}else{
$data[$chat_id]['modlist'][]=$ID;
$in = json_encode($data,true);
file_put_contents("data/$chat_id.json",$in);
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》کاربر [$FIRST](tg://user?id=$ID) به لیست #مدیران ربات افزوده شد",'parse_mode'=>"MarkDown"]);
}
}catch(Exception $e){

}
}
}
}
if(preg_match("/^(پیکربندی)$/i", $message)){
$gpw = $MadelineProto->get_pwr_chat($chat_id);
$getpw = $gpw['participants'];
$administrator = "";
foreach($getpw as $key=>$value){
$found = $getpw[$key]['role'];
if($found == "admin"){
if(!in_array(trim($getpw[$key]['user']['id']),$data[$chat_id]['modlist'])){
$data[$chat_id]['modlist'][] = trim($getpw[$key]['user']['id']);
$quer = json_encode($data,true);
file_put_contents("data/".$chat_id.".json",$quer);
}
}
}
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"تمامیه ادمین های گروه به لیست مدیران ربات افزوده شدند\nتوسط ☆> [$from_id](tg://user?id=$from_id)",'parse_mode'=>"MarkDown"]);
}
if(strpos($message,"تنزل")!==false){
if($from_id == $admin or in_array($from_id,$data[$chat_id]['ownerlist'])){
if(isset($update['update']['message']['reply_to_msg_id'])){
try{
$msgid = $update['update']['message']['reply_to_msg_id'];
$mah = $MadelineProto->channels->getMessages(['channel' => $chat_id, 'id' => [$msgid]]);
$ID = $mah['users'][0]['id'];
$FIRST = $mah['users'][0]['first_name'];
$key = array_search($ID,$data[$chat_id]["modlist"]);
if($key !== false){
unset($data[$chat_id]["modlist"][$key]);
$data[$chat_id]["modlist"] = array_values($data[$chat_id]["modlist"]);
$js = json_encode($data,true);
file_put_contents("data/$chat_id.json",$js);
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》کاربر [$FIRST](tg://user?id=$ID) از لیست #مدیران ربات حذف شد",'parse_mode'=>"MarkDown"]);
}else{
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》کاربر [$FIRST](tg://user?id=$ID) در لیست #مدیران ربات قرار نداشت",'parse_mode'=>"MarkDown"]);
}
}catch(Exception $e){

}
}
}
}

if($message == "لیست مدیران"){
if($from_id == $admin or in_array($from_id,$data[$chat_id]['modlist']) or in_array($from_id,$data[$chat_id]['ownerlist'])){
$sl = $data[$chat_id]['modlist'];
$ct = count($sl) - 1;
$tet = "";
if($sl[0] != ""){
for($i = 0;$i <= $ct; $i++){
$chi = $data[$chat_id]['modlist'][$i];
$tet .= "User : [$chi](tg://user?id=$chi)\n➖➖➖➖➖➖➖\n";
}
$MadelineProto->messages->sendMessage(['peer'=>$peer,'reply_to_msg_id'=>$mid,'message'=>"☆》لیست #مدیران ربات\n".$tet,'parse_mode'=>"MarkDown"]);
}else{
$MadelineProto->messages->sendMessage(['peer'=>$peer,'reply_to_msg_id'=>$mid,'message'=>"☆》لیست #مدیران ربات خالی میباشد"]);
}
}
}

if(preg_match("/^(پاک کردن لیست مدیران)$/i", $message)){
if($from_id == $admin or in_array($from_id,$data[$chat_id]['modlist']) or in_array($from_id,$data[$chat_id]['ownerlist'])){
unset($data[$chat_id]["modlist"]);
$data[$chat_id]["modlist"] = [];
@$Json = json_encode($data,true);
file_put_contents("data/$chat_id.json",$Json);
$MadelineProto->messages->sendMessage(['peer'=>$peer,'reply_to_msg_id'=>$mid,'message'=>"☆》لیست #مدیران ربات پاک شد"]);
}
}
}
}
}
?>
