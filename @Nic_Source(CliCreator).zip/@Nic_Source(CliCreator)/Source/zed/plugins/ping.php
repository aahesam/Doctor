<?php
if(isset($update['update']['_']) && ($update['update']['_'] == "updateNewChannelMessage")){
if(isset($chat_id)){
if(in_array($chat_id,$mange['grouplist'])){
if($message == "ربات"){
if($data[$chat_id]['add'] == "✅"){
if($from_id == $admin){
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"جونز"]);
}
}}
////---
}
}
}






