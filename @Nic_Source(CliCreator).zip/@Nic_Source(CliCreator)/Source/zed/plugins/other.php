<?php
if(in_array($chat_id,$mange['grouplist'])){
if(isset($update['update']['_']) && ($update['update']['_'] == "updateNewChannelMessage")){if(isset($chat_id)){
if($data[$chat_id]['add']=="✅"){
if($from_id == $admin or in_array($from_id,$data[$chat_id]['ownerlist']) or in_array($from_id,$data[$chat_id]['modlist'])){
if(preg_match("/^(حذف دیلیت اکانت ها)$/i", $message)){
$channelParticipantsRecent = ['_' => 'channelParticipantsRecent'];
$channels_ChannelParticipants = $MadelineProto->channels->getParticipants(['channel' => $chat_id, 'filter' => $channelParticipantsRecent, 'offset' => 0, 'limit' => 200, 'hash' => 0, ]);
$kl = $channels_ChannelParticipants['users'];
$list = "";
foreach($kl as $key=>$val){
$fon = $kl[$key]['deleted'];
if($fon == true){
$list .= $kl[$key]['id'];
}
}

if($list == ""){
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"هیچ دیلیت اکانت در گروه وجود ندارد"]);
}else{
$channelBannedRights = ['_' => 'channelBannedRights', 'view_messages' => true, 'send_messages' => false, 'send_media' => false, 'send_stickers' => false, 'send_gifs' => false, 'send_games' => false, 'send_inline' => false, 'embed_links' => false, 'until_date' => 0];
try{
$kickback = $MadelineProto->channels->editBanned(
['channel'=> $chat_id,
'user_id'=> $list,                          'banned_rights' => $channelBannedRights ]);
}catch(Exception $e){

}
}
}

///clean bot
if($message == "حذف ربات ها"){
$channelParticipantsRecent = ['_' => 'channelParticipantsRecent'];
$channels_ChannelParticipants = $MadelineProto->channels->getParticipants(['channel' => $chat_id, 'filter' => $channelParticipantsRecent, 'offset' => 0, 'limit' => 200, 'hash' => 0, ]);
$kl = $channels_ChannelParticipants['users'];
$list = "";
foreach($kl as $key=>$val){
$fon = $kl[$key]['bot'];
if($fon == true){
$list .= $kl[$key]['id'];
}
}

if($list == ""){
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"هیچ رباتی در گروه وجود ندارد"]);
}else{
$channelBannedRights = ['_' => 'channelBannedRights', 'view_messages' => true, 'send_messages' => false, 'send_media' => false, 'send_stickers' => false, 'send_gifs' => false, 'send_games' => false, 'send_inline' => false, 'embed_links' => false, 'until_date' => 0];
try{
$kickback = $MadelineProto->channels->editBanned([
'channel'=> $chat_id,
'user_id'=> $list,                          'banned_rights' => $channelBannedRights]);
}catch(Exception $e){
}
}
}
///---

if(preg_match("/^(سنجاق)$/i", $message)){
if(isset($update['update']['message']['reply_to_msg_id'])){
$msgid = $update['update']['message']['reply_to_msg_id'];
try{
$Updates = $MadelineProto->channels->updatePinnedMessage(['channel' => $chat_id, 'id' => $msgid, ]);
}catch(Exception $e){

}
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"پیام مورد نظر سنجاق شد\nتوسط ☆> [$from_id](tg://user?id=$from_id)",'parse_mode'=>"MarkDown"]);
}}
if(preg_match("/^(تنظیمات)$/i", $message)){
$in = json_decode(file_get_contents("data/".$chat_id.".json"),true);
$Lock = $in[$chat_id]['lock'];
$txt ="◾️》`قفل لینک` : `".$Lock['link']."`\n  ◾️》`قفل تصویر` : `".$Lock['photo']."`\n   ◾️》`قفل ویدیو` : `".$Lock['video']."`\n    ◾️》`قفل سرویس تلگرام` : `".$Lock['tgservice']."`\n     ◾️》`قفل اینلاین` : `".$Lock['inline']."`\n      ◾️》`قفل منشن` : `".$Lock['mention']."`\n       ◾️》`قفل صدا` : `".$Lock['voice']."`\n       ◾️》`قفل فارسی` : `".$Lock['arabic']."`\n        ◾️》`قفل انگلیسی` : `".$Lock['english']."`\n         ◾️》`قفل بازی` : `".$Lock['game']."`\n          ◾️》`قفل ربات` : `".$Lock['bot']."`\n         ◾️》`قفل فوروارد` : `".$Lock['forward']."`\n        ◾️》`قفل مخاطب` : `".$Lock['contact']."`\n       ◾️》`قفل شیشه ای` : `".$Lock['inline']."`\n      ◾️》`قفل گیف` : `".$Lock['gif']."`\n     ◾️》`قفل همه` : `".$Lock['all']."`\n    ◾️》`وضعیت` : `".$in[$chat_id]['add']."`\n   ◾️》`تعداد مدیران` : `".count($in[$chat_id]['modlist'])."`\n  ◾️》کانال : @EliyaTM\n توسط : [$from_id](tg://user?id=$from_id)";
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'message'=>"تنظیمات گروه \n`".$chat_id."`\n".$txt,'parse_mode'=>'MarkDown']);
}
if(preg_match("/^(راهنما)$/i", $message)){
$txt = "راهنمای ربات

⬛راهنمای قفل ها

▪قفل لینک
بازکردن لینک

▪قفل صدا
▫ بازکردن صدا

▪قفل عکس
▫ بازکردن عکس

▪قفل ویدیو
▫ بازکردن ویدیو

▪قفل بازی
▫ بازکردن بازی

▪قفل سرویس تلگرام
▫ بازکردن سرویس تلگرام

▪قفل فوروارد
▫ بازکردن فوروارد

▪قفل مخاطب
▫ بازکردن مخاطب

▪قفل اینلاین
▫ بازکردن اینلاین

▪قفل منشن
▫ بازکردن منشن

▪قفل فراخوانی
▫ بازکردن فراخوانی

▪قفل ربات
▫ بازکردن ربات

▪قفل فارسی
▫ بازکردن انگلیسی

▪قفل انگلیسی
▫ بازکردن انگلیسی

▪قفل گیف
▫ بازکردن گیف
~~~~~~~~~~~~
▪سکوت
بیصدا کردن کاربر در گروه

▪رفع سکوت
باصدا کردن کاربر در گروه

▪لیست بیصداها
مشاهده لیست افراد بیصدا 

▪پاک کردن لیست بیصدا
پاکسازی لیست افراد بیصدا در گروه به طور کامل

▪مسدود
محروم کردن کاربر از گروه و اخراج ان

▪رفع مسدود
خارج کردن کاربر از محدودیت در گروه

▪لیست مسدود
مشاهده لیست افراد محروم از گروه

▪پاکسازی لیست مسدود
پاک کردن کامل لیست محروم از گروه

▪ تنظیمات
مشاهده تنظیمات گروه

▪ترفیع
ارتقا دادن کاربر به مدیر ربات
اضافه کردن کاربر به لیست مدیران ربات
توجه : فقط ادمین اصلی یا مدیر ربات توانایی ارتقا دادن یک کاربر را دارند

▪تنزل
حذف کردن کاربر از لیست مدیران ربات

▪ایدی
مشاهده مشخصات خود

▪ایدی + ریپلی
مشاهده مشخصات شخصی که بر روی پیام او ریپلی کرده اید

▪حذف ربات ها
اخراج کردن ربات های داخل گروه

▪حذف دیلیت اکانت ها
پاک کردن اکانت های حذف شده

▪ادفیلتر + کلمه
اضافه کردن کلمه به لیست فیلتر

▪حذف فیلتر + کلمه
حذف کردن کلمه مورد نظر از لیست فیلتر

▪لیست فیلتر
مشاهده لیست کلمات فیلتر شده

▪پاکسازی لیست فیلتر
پاک کردن کامل لیست کلمات فیلتر شده

▪پیکربندی
اضافه کردن همه ادمین های گروه به لیست مدیران ربات
توجه : این دستور فقط برای مدیر ریات و مدیر اصلی گروه است!

▪پاکسازی + عدد
پاک کردن پیام های گروه با مقدار دلخواه

▪پاکسازی + ریپلی
پاک کردن تمامیه پیام های فردی که روی پیام ان ریپلی کرده اید.

▪انلاینی
مشاهده فعال بودن ربات در گروه

▪کانال : @EliyaTM";
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'message'=>$txt]);

}
}}}}}
?>
