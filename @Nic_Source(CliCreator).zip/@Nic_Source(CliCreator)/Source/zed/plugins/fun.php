﻿<?php
if(isset($update['update']['_']) && $update['update']['_'] =="updateNewChannelMessage"){
if($from_id == $admin or in_array($from_id,$data[$chat_id]['ownerlist']) or in_array($from_id,$data[$chat_id]['modlist'])){
if(preg_match("/^(زمان)$/i", $message)){
$js = json_decode(file_get_contents("http://probot.000webhostapp.com/api/time.php"),true);
$tx = "ساعت : ".$js['FAtime']."\n\nتاریخ : ".$js['FAtime']."\n\nتعداد روزهای جاری ماه : ".$js['t']."\n\nتعداد روز در هفته : ".$js['w']."\n\nشماره این هفته در سال : ".$js['W']."\n\nنام بستانی ماه : ".$js['p']."\n\nشماره ماه از سال : ".$js['b']."\n\nنام فصل : ".$js['f']."\n\nشماره فصل از سال : ".$js['n']."\n\nتعداد روز های گذشته از سال : ".$js['z']."\n\nدرصد گذشته از سال : ".$js['K']."\n\nتعداد روز های باقی مانده از سال : ".$js['Q']."\n\nدرصد باقی مانده از سال : ".$js['k']."\n\nنام حیوانی سال : ".$js['q']."\n\nشماره ی قرن هجری شمسی : ".$js['C']."\n➖➖➖➖➖➖➖\n✨@skyTEAM";
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'message'=>$tx]);
}



}
}


?>
