﻿<?php

if(in_array($chat_id,$mange['grouplist']) && file_exists("data/$chat_id.json")){
if(isset($update['update']['_']) && ($update['update']['_'] == "updateNewChannelMessage")){
if($data[$chat_id]['add']=="✅"){
if(isset($update['update']['message']['id']) or ($mid != null)){
if($from_id != $admin && !in_array($from_id,$data[$chat_id]['ownerlist']) && !in_array($from_id,$data[$chat_id]['modlist'])){
if(isset($update['update']['message']['id'])){
$locK = $data[$chat_id]['lock'];
if(strpos($message,"t.me")!==false or strpos($message,"telegram.me" or strstr($message,"T.me")!==false or strstr($message,"Telegram.me")!==false )!==false){
if($locK['link'] == "🔐"){
$MadelineProto->channels->deleteMessages(['channel' => $chat_id, 'id' => [$mid]]);
}
}
if(isset($update['update']['message']['media']) && ($update['update']['message']['media']['_'] == "messageMediaPhoto")){
if($locK['photo'] == "🔐"){
$MadelineProto->channels->deleteMessages(['channel' => $chat_id, 'id' => [$mid]]);
}
}
if(isset($update['update']['message']['media']) && ($update['update']['message']['media']['_'] == "messageMediaDocument")){
if($update['update']['message']['media']['document']['mime_type'] == "audio/ogg"){
if($locK['voice'] == "🔐"){
$MadelineProto->channels->deleteMessages(['channel' => $chat_id, 'id' => [$mid]]);
}
}
}
if(isset($update['update']['message']['_']) && ($update['update']['message']['_'] == "messageService")){
if($locK['tgservice'] == "🔐"){
$MadelineProto->channels->deleteMessages(['channel' => $chat_id, 'id' => [$update['update']['message']['id']]]);
}
}
if(isset($update['update']['message']['media']) && ($update['update']['message']['media']['_'] == "messageMediaDocument")){
if($locK['gif'] == "🔐"){
$MadelineProto->channels->deleteMessages(['channel' => $chat_id, 'id' => [$mid]]);

}}
if(isset($update['update']['message']['media']) && ($update['update']['message']['media']['_'] == "messageMediaDocument")){
try{
if($update['update']['message']['media']['document']['mime_type'] == "video/mp4" or $update['update']['message']['media']['document']['mime_type'] == "video/mkv"){
if($locK['video'] == "🔐"){
$MadelineProto->channels->deleteMessages(['channel' => $chat_id, 'id' => [$mid]]);
}
}
}catch(Exception $e){

}
}
if(isset($update['update']['message'])){
if($locK['all'] == "🔐"){
$MadelineProto->channels->deleteMessages(['channel' => $chat_id, 'id' => [$mid]]);
}
}
if(isset($update['update']['message']['media']) && ($update['update']['message']['media']['_'] == "messageMediaContact")){
if($locK['contact'] == "🔐"){
$MadelineProto->channels->deleteMessages(['channel' => $chat_id, 'id' => [$mid]]);
}
}
if(isset($update['update']['message']['fwd_from']) && ($update['update']['message']['fwd_from']['_'] == "messageFwdHeader")){
if($locK['forward'] == "🔐"){
$MadelineProto->channels->deleteMessages(['channel' => $chat_id, 'id' => [$mid]]);
}
}
if(isset($update['update']['message']['entities']) && ($update['update']['message']['entities'][0]['_']=="messageEntityMention"))
{
if($locK['mention'] == "🔐"){
$MadelineProto->channels->deleteMessages(['channel' => $chat_id, 'id' => [$mid]]);
}
}
if(isset($update['update']['message']['via_bot_id'])){
if($locK['inline'] == "🔐"){
$MadelineProto->channels->deleteMessages(['channel' => $chat_id, 'id' => [$mid]]);
}
}
if(isset($update['update']['message']['via_bot_id'])){
if($locK['game'] == "🔐"){
$MadelineProto->channels->deleteMessages(['channel' => $chat_id, 'id' => [$mid]]);
}
}
if(isset($update['update']['message']['message'])){
if(isset($update['update']['message']['action'])){
if($update['update']['message']['action']['_'] == "messageActionChatJoinedByLink"){
try{
$result = $MadelineProto->channels->getMessages(['channel' => $chat_id, 'id' => [$mid]]);
foreach($result as $key){

$IsBot = $result['users'][$key]['bot'];
if(isset($result['users'][$key]['bot'])){
if($IsBot == true){
if($locK['bot'] == "🔐"){
$MadelineProto->channels->deleteMessages(['channel' => $chat_id, 'id' => [$mid]]);
$channelBannedRights = ['_' => 'channelBannedRights', 'view_messages' => true, 'send_messages' => false, 'send_media' => false, 'send_stickers' => false, 'send_gifs' => false, 'send_games' => false, 'send_inline' => false, 'embed_links' => false, 'until_date' => 0];
$kickback = $MadelineProto->channels->editBanned(
['channel'=> $chat_id,
'user_id'=> $from_id,                          'banned_rights' => $channelBannedRights ]);
}}
}}
}catch(Exception $e){

}
}}}
if(isset($update['update']['message']['message'])){
if (preg_match("/[0-9a-zA-Z]+/", $message)) {
if($locK['english'] == "🔐"){
$MadelineProto->channels->deleteMessages(['channel' => $chat_id, 'id' => [$mid]]);
}
}else{
if($locK['arabic'] == "🔐"){
$MadelineProto->channels->deleteMessages(['channel' => $chat_id, 'id' => [$mid]]);
}
}
}
if(isset($update['update']['message']['message'])){
$getfilter = $data[$chat_id]['filterlist'];
if($getfilter != ""){
foreach($getfilter as $key){
try{
		if(strpos($message,$key)!==false) {
$MadelineProto->channels->deleteMessages(['channel' => $chat_id, 'id' => [$mid]]);	
		}
		}catch(Exception $e){
		
		}
	}
}}
if(in_array($from_id,$data[$chat_id]['silentlist'])){
if($mid != null){
$MadelineProto->channels->deleteMessages(['channel' => $chat_id, 'id' => [$mid]]);	
}
}
if(isset($update['update']['message']['action'])){
if($update['update']['message']['action']['_'] == "messageActionChatJoinedByLink"){
if(in_array($from_id,$data[$chat_id]['banlist'])){
BanUser($chat_id,$from_id);
}
}
}



///---

}}

}
}
}}




?>
