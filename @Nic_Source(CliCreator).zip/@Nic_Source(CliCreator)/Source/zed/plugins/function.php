<?php

function BanUser($chat_id,$from_id){

global $update;

global $MadelineProto;

if(!isset($chat_id) && !isset($from_id)){
return;
}
if(isset($chat_id) && isset($from_id)){
try{
$channelBannedRights = ['_' => 'channelBannedRights', 'view_messages' => true, 'send_messages' => false, 'send_media' => false, 
'send_stickers' => false, 
'send_gifs' => false,
 'send_games' => false, 
'send_inline' => false,
 'embed_links' => false,
 'until_date' => 0
];
$kickback = $MadelineProto->channels->editBanned(
[
'channel'=> $chat_id,
'user_id'=> $from_id,                          'banned_rights' => $channelBannedRights 
]
);

}catch(Exception $e){

}
}

}//Function BanUser

function UnBanUser($chat_id,$from_id){

global $update;

global $MadelineProto;

if(!isset($chat_id) && !isset($from_id)){
return;
}
if(isset($chat_id) && isset($from_id)){
try{
$channelBannedRights = ['_' => 'channelBannedRights',
'view_messages' => true,
'send_messages' => true,
'send_media' => true, 
'send_stickers' => true, 
'send_gifs' => true,
'send_games' => true, 
'send_inline' => true,
'embed_links' => true,
'until_date' => 0
];
$kickback = $MadelineProto->channels->editBanned(
[
'channel'=> $chat_id,
'user_id'=> $from_id,                          'banned_rights' => $channelBannedRights 
]
);

}catch(Exception $e){

}
}

}//Function UnBanUser
