﻿<?php
if(isset($update['update']['_']) && ($update['update']['_'] == "updateNewChannelMessage")){
try{
if($message == "نصب" && $from_id == $admin){
$gpw = $MadelineProto->get_pwr_chat($chat_id);
$getpw = $gpw['participants'];
$owner = "";
$administrator = "";
foreach($getpw as $key=>$value){
$found = $getpw[$key]['role'];
if($found == "creator"){
$owner = trim($owner." ".$getpw[$key]['user']['id']);
}
if($found == "admin"){
$administrator = $administrator."\n".$getpw[$key]['user']['id'];
}
}
if(!file_exists("data/".$chat_id.".json")){
touch("data/".$chat_id.".json");
file_put_contents("data/".$chat_id.".json","{}");
$data[$chat_id]['lock']['link'] = "🔐";
$data[$chat_id]['lock']['photo'] = "🔓";
$data[$chat_id]['lock']['video'] = "🔓";
$data[$chat_id]['lock']['voice'] = "🔓";
$data[$chat_id]['lock']['bot'] = "🔐";
$data[$chat_id]['lock']['tgservice'] = "🔐";
$data[$chat_id]['lock']['mention'] = "🔐";
$data[$chat_id]['lock']['inline'] = "🔐";
$data[$chat_id]['lock']['contact'] = "🔐";
$data[$chat_id]['lock']['game'] = "🔓";
$data[$chat_id]['lock']['all'] = "🔓";
$data[$chat_id]['lock']['forward'] = "🔓";
$data[$chat_id]['lock']['gif'] = "🔓";
$data[$chat_id]['lock']['english'] = "🔓";
$data[$chat_id]['lock']['arabic'] = "🔓";
$data[$chat_id]['add'] = "✅";
$data[$chat_id]['charge'] = "2 day";
$data[$chat_id]['markread'] = "";
$data[$chat_id]['rules'] = "";
$data[$chat_id]['welcome'] = "";
$data[$chat_id]['mutetime'] = "";
$data[$chat_id]['timeadd'] = "";
$data[$chat_id]['filterlist'][] = "¢";
$data[$chat_id]['modlist'][] = $owner;
$data[$chat_id]['banlist'] = [];
$data[$chat_id]['ownerlist'][] = $owner;
$data[$chat_id]['silentlist'] = [];
$inse = json_encode($data,true);
file_put_contents("data/$chat_id.json",$inse);
$mange['grouplist'][] = $chat_id;
$quer = json_encode($mange,true);
file_put_contents("data/data.json",$quer);
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"↫گروه ".$gpname." به لیست مدیریتی ربات اضافه شد✔️\n↫و کاربر [$owner](tg://user?id=$owner) به عنوان مدیر ربات انتخاب شد\nبرای ادامه کار دستور `راهنما` را ارسال کنید\n@EliyaTM",'parse_mode'=>"MarkDown"]);
}else{
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"↫گروه از قبل در لیست مدیریتی ربات قرار داشت"]);
}
}

if(preg_match("/^(حذف)$/i", $message)){

if($from_id == $admin){

if(file_exists("data/".$chat_id.".json")){

unlink("data/".$chat_id.".json");

unset($mange["grouplist"][$chat_id]);

$mange["grouplist"] = array_values($mange["grouplist"]);

$js = json_encode($mange,true);

file_put_contents("data/data.json",$js);

$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"↫گروه ".$gpname." از لیست مدیریتی ربات حذف شد"]);
}else{
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"↫گروه ".$gpname." در لیست مدیریتی ربات قرار نداشت"]);
}
}
}
}catch(Exception $e){

}
}//end
?>
