﻿<?php

if(in_array($chat_id,$mange['grouplist'])){
if(isset($update['update']['_']) && ($update['update']['_'] == "updateNewChannelMessage")){if(isset($chat_id) && file_exists("data/$chat_id.json")){
if($data[$chat_id]['add']=="✅"){
if($from_id == $admin or in_array($from_id,$data[$chat_id]['ownerlist']) or in_array($from_id,$data[$chat_id]['modlist'])){
//$result = $MadelineProto->channels->getMessages(['channel' => $chat_id, 'id' => [$mid]]);
$From_id = $from_id;
if(preg_match("/^(قفل لینک)$/i", $message)){
if($data[$chat_id]['lock']['link'] == "🔐"){
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》ارسال #لینک در گروه ممنوع بود🔒\n➖➖➖➖➖➖➖\n❗️️قفل لینک فعال بود و تمام پیام های حاوی لینک پاک میشدند\nتوسط ☆> [$From_id](tg://user?id=$From_id)",'parse_mode'=>"MarkDown"]);
}else{
$data[$chat_id]['lock']['link']="🔐";
$Json = json_encode($data,true);
file_put_contents("data/$chat_id.json",$Json);
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》ارسال #لینک در گروه ممنوع شد🔒\n➖➖➖➖➖➖➖\n❗️️قفل لینک فعال شد از این پس تمام پیام های حاوی لینک پاک خواهند شد\nتوسط ☆> [$From_id](tg://user?id=$From_id)",'parse_mode'=>"MarkDown"]);
}
}
if(preg_match("/^(بازکردن لینک)$/i", $message)){
if($data[$chat_id]['lock']['link'] == "🔐"){
$data[$chat_id]['lock']['link']="🔓";
$Json = json_encode($data,true);
file_put_contents("data/$chat_id.json",$Json);
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》قفل ارسال #لینک در گروه غیرفعال شد🔒\n➖➖➖➖➖➖➖\n❗️️قفل لینک غیرفعال شد از این پس تمام پیام های حاوی لینک پاک نخواهند شد\nتوسط ☆> [$From_id](tg://user?id=$From_id)",'parse_mode'=>"MarkDown"]);
}else{
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》ارسال #لینک در گروه غیرفعال بود🔒\n➖➖➖➖➖➖➖\n❗️️قفل لینک غیرفعال بود و پیام های حاوی لینک پاک نمیشدند\nتوسط ☆> [$From_id](tg://user?id=$From_id)",'parse_mode'=>"MarkDown"]);
}
}
if(preg_match("/^(قفل عکس)$/i", $message)){
if($data[$chat_id]['lock']['photo'] == "🔐"){
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》ارسال #تصویر در گروه ممنوع بود🔒\n➖➖➖➖➖➖➖\n❗️️قفل ارسال تصویر فعال بود و تمام پیام های حاوی تصویر پاک میشدند\nتوسط ☆> [$From_id](tg://user?id=$From_id)",'parse_mode'=>"MarkDown"]);
}else{
$data[$chat_id]['lock']['photo']="🔐";
$Json = json_encode($data,true);
file_put_contents("data/$chat_id.json",$Json);
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》ارسال #تصویر در گروه ممنوع شد🔒\n➖➖➖➖➖➖➖\n❗️️قفل ارسال تصویر فعال شد از این پس تمام پیام های حاوی تصویر پاک خواهند شد\nتوسط ☆> [$From_id](tg://user?id=$From_id)",'parse_mode'=>"MarkDown"]);
}
}
if(preg_match("/^(بازکردن عکس)$/i", $message)){
if($data[$chat_id]['lock']['photo'] == "🔐"){
$data[$chat_id]['lock']['photo']="🔓";
$Json = json_encode($data,true);
file_put_contents("data/$chat_id.json",$Json);
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》قفل ارسال #تصویر در گروه غیرفعال شد🔒\n➖➖➖➖➖➖➖\n❗️️قفل ارسال تصویر غیرفعال شد از این پس تمام پیام های حاوی تصویر پاک نخواهند شد\nتوسط ☆> [$From_id](tg://user?id=$From_id)",'parse_mode'=>"MarkDown"]);
}else{
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》قفل ارسال #تصویر در گروه غیرفعال بود🔒\n➖➖➖➖➖➖➖\n❗️️قفل ارسال تصویر غیرفعال بود و پیام های حاوی تصویر پاک نمیشدند\nتوسط ☆> [$From_id](tg://user?id=$From_id)",'parse_mode'=>"MarkDown"]);
}
}


if(preg_match("/^(قفل سرویس تلگرام)$/i", $message)){
if($data[$chat_id]['lock']['tgservice'] == "🔐"){
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》قفل #سرویس_تلگرام فعال بود🔒\n➖➖➖➖➖➖➖\n❗️️قفل سرویس تلگرام فعال بود و سرویس های تلگرام اعم از پیام ورود و خروج پاک میشدند\nتوسط ☆> [$From_id](tg://user?id=$From_id)",'parse_mode'=>"MarkDown"]);
}else{
$data[$chat_id]['lock']['tgservice']="🔐";
$Json = json_encode($data,true);
file_put_contents("data/$chat_id.json",$Json);
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》قفل #سرویس_تلگرام فعال شد🔒\n➖➖➖➖➖➖➖\n❗️️قفل سرویس تلگرام فعال شد و سرویس های تلگرام اعم از پیام ورود و خروج پاک خواهد شد\nتوسط ☆> [$From_id](tg://user?id=$From_id)",'parse_mode'=>"MarkDown"]);
}
}
if(preg_match("/^(بازکردن سرویس تلگرام)$/i", $message)){
if($data[$chat_id]['lock']['tgservice'] == "🔐"){
$data[$chat_id]['lock']['tgservice']="🔓";
$Json = json_encode($data,true);
file_put_contents("data/$chat_id.json",$Json);
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》قفل #سرویس_تلگرام غیرفعال شد 🔒\n➖➖➖➖➖➖➖\n❗️️قفل سرویس تلگرام غیرفعال شد و سرویس های تلگرام اعم از پیام ورود و خروج پاک نمیشوند\nتوسط ☆> [$From_id](tg://user?id=$From_id)",'parse_mode'=>"MarkDown"]);
}else{
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》قفل #سرویس_تلگرام غیرفعال بود 🔒\n➖➖➖➖➖➖➖\n❗️️قفل سرویس تلگرام غیرفعال بود و سرویس های تلگرام اعم از پیام ورود و خروج پاک نمیشدند\nتوسط ☆> [$From_id](tg://user?id=$From_id)",'parse_mode'=>"MarkDown"]);
}
}

if(preg_match("/^(قفل ربات)$/i", $message)){
if($data[$chat_id]['lock']['bot'] == "🔐"){
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》قفل #ورود_ربات فعال بود\n➖➖➖➖➖➖➖\n❗️️قفل ورود ربات به گروه فعال بود و با ورود ربات انها اخراج میشدند\nتوسط ☆> [$From_id](tg://user?id=$From_id)",'parse_mode'=>"MarkDown"]);
}else{
$data[$chat_id]['lock']['bot']="🔐";
$Json = json_encode($data,true);
file_put_contents("data/$chat_id.json",$Json);
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》قفل #ورود_ربات فعال شد\n➖➖➖➖➖➖➖\n❗️️قفل ورود ربات به گروه فعال شد و با ورود ربات انها اخراج میشوند\nتوسط ☆> [$From_id](tg://user?id=$From_id)",'parse_mode'=>"MarkDown"]);
}
}

if(preg_match("/^(بازکردن ربات)$/i", $message)){
if($data[$chat_id]['lock']['bot'] == "🔐"){
$data[$chat_id]['lock']['bot']="🔓";
$Json = json_encode($data,true);
file_put_contents("data/$chat_id.json",$Json);
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》قفل #ورود_ربات  غیرفعال شد\n➖➖➖➖➖➖➖\n❗️️قفل ورود ربات به گروه غیرفعال شد و با ورود ربات انها اخراج نمیشوند\nتوسط ☆> [$From_id](tg://user?id=$From_id)",'parse_mode'=>"MarkDown"]);
}else{
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》قفل #ورود_ربات  غیرفعال بود\n➖➖➖➖➖➖➖\n❗️️قفل ورود ربات به گروه غیرفعال بود و با ورود ربات انها اخراج نمیشدند\nتوسط ☆> [$From_id](tg://user?id=$From_id)",'parse_mode'=>"MarkDown"]);
}
}
if(preg_match("/^(قفل صدا)$/i", $message)){
if($data[$chat_id]['lock']['voice'] == "🔐"){
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》ارسال #صدا در گروه ممنوع بود🔒\n➖➖➖➖➖➖➖\n❗️️قفل ارسال صدا فعال بود و تمام پیام های حاوی صدا پاک میشدند\nتوسط ☆> [$From_id](tg://user?id=$From_id)",'parse_mode'=>"MarkDown"]);
}else{
$data[$chat_id]['lock']['voice']="🔐";
$Json = json_encode($data,true);
file_put_contents("data/$chat_id.json",$Json);
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》ارسال #صدا در گروه ممنوع شد🔒\n➖➖➖➖➖➖➖\n❗️️قفل ارسال صدا فعال شد و تمام پیام های حاوی صدا پاک میشوند\nتوسط ☆> [$From_id](tg://user?id=$From_id)",'parse_mode'=>"MarkDown"]);
}
}
if(preg_match("/^(بازکردن صدا)$/i", $message)){
if($data[$chat_id]['lock']['voice'] == "🔐"){
$data[$chat_id]['lock']['voice']="🔓";
$Json = json_encode($data,true);
file_put_contents("data/$chat_id.json",$Json);
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》قفل ارسال #صدا در گروه غیرفعال شد🔒\n➖➖➖➖➖➖➖\n❗️️قفل ارسال صدا غیرفعال شد و دیگر پیام های حاوی صدا پاک نمیشوند\nتوسط ☆> [$From_id](tg://user?id=$From_id)",'parse_mode'=>"MarkDown"]);
}else{
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》قفل ارسال #صدا در گروه غیرفعال بود🔒\n➖➖➖➖➖➖➖\n❗️️قفل ارسال صدا غیرفعال بود و پیام های حاوی صدا پاک نمیشدند\nتوسط ☆> [$From_id](tg://user?id=$From_id)",'parse_mode'=>"MarkDown"]);
}
}
if(preg_match("/^(قفل ویدیو)$/i", $message)){
if($data[$chat_id]['lock']['video'] == "🔐"){
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》ارسال #ویدیو در گروه ممنوع بود🔒\n➖➖➖➖➖➖➖\n❗️️قفل ارسال ویدیو فعال بود و تمام پیام های حاوی ویدیو پاک میشدند\nتوسط ☆> [$From_id](tg://user?id=$From_id)",'parse_mode'=>"MarkDown"]);
}else{
$data[$chat_id]['lock']['video']="🔐";
$Json = json_encode($data,true);
file_put_contents("data/$chat_id.json",$Json);
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》ارسال #ویدیو در گروه ممنوع شد🔒\n➖➖➖➖➖➖➖\n❗️️قفل ارسال ویدیو فعال شد و تمام پیام های حاوی ویدیو پاک میشوند\nتوسط ☆> [$From_id](tg://user?id=$From_id)",'parse_mode'=>"MarkDown"]);
}
}
if(preg_match("/^(بازکردن ویدیو)$/i", $message)){
if($data[$chat_id]['lock']['video'] == "🔐"){
$data[$chat_id]['lock']['video']="🔓";
$Json = json_encode($data,true);
file_put_contents("data/$chat_id.json",$Json);
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》قفل ارسال #ویدیو در گروه غیرفعال شد🔒\n➖➖➖➖➖➖➖\n❗️️قفل ارسال ویدیو غیرفعال شد و دیگر پیام های حاوی صدا پاک نمیشوند\nتوسط ☆> [$From_id](tg://user?id=$From_id)",'parse_mode'=>"MarkDown"]);
}else{
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》قفل ارسال #ویدیو در گروه غیرفعال بود🔒\n➖➖➖➖➖➖➖\n❗️️قفل ارسال ویدیو غیرفعال بود و پیام های حاوی ویدیو پاک نمیشدند\nتوسط ☆> [$From_id](tg://user?id=$From_id)",'parse_mode'=>"MarkDown"]);
}
}
if(preg_match("/^(قفل بازی)$/i", $message)){
if($data[$chat_id]['lock']['game'] == "🔐"){
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》ارسال #بازی در گروه ممنوع بود🔒\n➖➖➖➖➖➖➖\n❗️️قفل ارسال بازی فعال بود و تمام پیام های حاوی بازی پاک میشدند\nتوسط ☆> [$From_id](tg://user?id=$From_id)",'parse_mode'=>"MarkDown"]);
}else {
$data[$chat_id]['lock']['game']="🔐";
$Json = json_encode($data,true);
file_put_contents("data/$chat_id.json",$Json);
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》ارسال #بازی در گروه ممنوع شد🔒\n➖➖➖➖➖➖➖\n❗️️قفل ارسال بازی فعال شد و تمام پیام های حاوی بازی پاک میشوند\nتوسط ☆> [$From_id](tg://user?id=$From_id)",'parse_mode'=>"MarkDown"]);
}
}
if(preg_match("/^(بازکردن بازی)$/i", $message)){
if($data[$chat_id]['lock']['game'] == "🔐"){
$data[$chat_id]['lock']['game']="🔓";
$Json = json_encode($data,true);
file_put_contents("data/$chat_id.json",$Json);
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》قفل ارسال #بازی در گروه غیرفعال شد🔒\n➖➖➖➖➖➖➖\n❗️️قفل ارسال بازی غیرفعال شد و دیگر پیام های حاوی بازی پاک نمیشوند\nتوسط ☆> [$From_id](tg://user?id=$From_id)",'parse_mode'=>"MarkDown"]);
}else{
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》قفل ارسال #بازی در گروه غیرفعال بود🔒\n➖➖➖➖➖➖➖\n❗️️قفل ارسال بازی غیرفعال بود و پیام های حاوی بازی پاک نمیشدند\nتوسط ☆> [$From_id](tg://user?id=$From_id)",'parse_mode'=>"MarkDown"]);
}
}
if(preg_match("/^(قفل فوروارد)$/i", $message)){
if($data[$chat_id]['lock']['forward'] == "🔐"){
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》ارسال پیام #فوروارد شده در گروه ممنوع بود🔒\n➖➖➖➖➖➖➖\n❗️️قفل ارسال پیام فورواردی فعال بود و پیام های فوروارد شده پاک میشدند\nتوسط ☆> [$From_id](tg://user?id=$From_id)",'parse_mode'=>"MarkDown"]);
}else {
$data[$chat_id]['lock']['forward']="🔐";
$Json = json_encode($data,true);
file_put_contents("data/$chat_id.json",$Json);
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》ارسال پیام #فوروارد شده در گروه ممنوع شد🔒\n➖➖➖➖➖➖➖\n❗️️قفل ارسال پیام فورواردی فعال شد و از این به بعد پیام های فوروارد شده پاک میشوند\nتوسط ☆> [$From_id](tg://user?id=$From_id)",'parse_mode'=>"MarkDown"]);
}
}
if(preg_match("/^(بازکردن فوروارد)$/i", $message)){
if($data[$chat_id]['lock']['forward'] == "🔐"){
$data[$chat_id]['lock']['forward']="🔓";
$Json = json_encode($data,true);
file_put_contents("data/$chat_id.json",$Json);
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》قفل ارسال پیام #فوروارد شده در گروه غیرفعال شد 🔒\n➖➖➖➖➖➖➖\n❗️️قفل ارسال پیام فورواردی غیرفعال شد و پیام های فوروارد شده پاک نمیشوند\nتوسط ☆> [$From_id](tg://user?id=$From_id)",'parse_mode'=>"MarkDown"]);
}else {
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》 قفل ارسال پیام #فوروارد شده در گروه غیرفعال بود 🔒\n➖➖➖➖➖➖➖\n❗️️قفل ارسال پیام فورواردی غیرفعال بود و پیام های فوروارد شده پاک نمیشدند\nتوسط ☆> [$From_id](tg://user?id=$From_id)",'parse_mode'=>"MarkDown"]);
}
}

if(preg_match("/^(قفل انگلیسی)$/i", $message)){
if($data[$chat_id]['lock']['english'] == "🔐"){
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》ارسال پیام #انگلیسی در گروه ممنوع بود\n➖➖➖➖➖➖➖\n❗️️قفل ارسال فرستان پیام انگلیسی فعال بود و پیام های انگلیسی پاک میشدند\nتوسط ☆> [$From_id](tg://user?id=$From_id)",'parse_mode'=>"MarkDown"]);
}else{
$data[$chat_id]['lock']['english']="🔐";
$Json = json_encode($data,true);
file_put_contents("data/$chat_id.json",$Json);
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》ارسال پیام #انگلیسی در گروه ممنوع شد\n➖➖➖➖➖➖➖\n❗️️قفل ارسال فرستان پیام انگلیسی فعال شد و از این پس  پیام های انگلیسی پاک میشوند\nتوسط ☆> [$From_id](tg://user?id=$From_id)",'parse_mode'=>"MarkDown"]);
}
}
if(preg_match("/^(بازکردن انگلیسی)$/i", $message)){
if($data[$chat_id]['lock']['english'] == "🔐"){
$data[$chat_id]['lock']['english']="🔓";
$Json = json_encode($data,true);
file_put_contents("data/$chat_id.json",$Json);
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》قفل ارسال پیام #انگلیسی در گروه ممنوع غیرفعال شد\n➖➖➖➖➖➖➖\n❗️️قفل ارسال فرستان پیام انگلیسی غیرفعال شد و از این پس پیام های انگلیسی پاک نمیشوند\nتوسط ☆> [$From_id](tg://user?id=$From_id)",'parse_mode'=>"MarkDown"]);
}else{
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》قفل ارسال پیام #انگلیسی در گروه غیرفعال بود\n➖➖➖➖➖➖➖\n❗️️قفل ارسال فرستان پیام انگلیسی غیرفعال بود و پیام های انگلیسی پاک نمیشدند\nتوسط ☆> [$From_id](tg://user?id=$From_id)",'parse_mode'=>"MarkDown"]);
}
}
if(preg_match("/^(قفل فارسی)$/i", $message)){
if($data[$chat_id]['lock']['arabic'] == "🔐"){
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》ارسال پیام #فارسی در گروه ممنوع بود\n➖➖➖➖➖➖➖\n❗️️قفل ارسال فرستان پیام فارسی فعال بود و پیام های فارسی پاک میشدند\nتوسط ☆> [$From_id](tg://user?id=$From_id)",'parse_mode'=>"MarkDown"]);
}else{
$data[$chat_id]['lock']['arabic']="🔐";
$Json = json_encode($data,true);
file_put_contents("data/$chat_id.json",$Json);
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》ارسال پیام #فارسی در گروه ممنوع شد\n➖➖➖➖➖➖➖\n❗️️قفل ارسال فرستان پیام فارسی فعال شد و از این پس  پیام های فارسی پاک میشوند\nتوسط ☆> [$From_id](tg://user?id=$From_id)",'parse_mode'=>"MarkDown"]);
}
}
if(preg_match("/^(بازکردن فارسی)$/i", $message)){
if($data[$chat_id]['lock']['arabic'] == "🔐"){
$data[$chat_id]['lock']['arabic']="🔓";
$Json = json_encode($data,true);
file_put_contents("data/$chat_id.json",$Json);
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》قفل ارسال پیام #فارسی در گروه ممنوع غیرفعال شد\n➖➖➖➖➖➖➖\n❗️️قفل ارسال فرستان پیام فارسی غیرفعال شد و از این پس پیام های فارسی پاک نمیشوند\nتوسط ☆> [$From_id](tg://user?id=$From_id)",'parse_mode'=>"MarkDown"]);
}else{
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》قفل ارسال پیام #فارسی در گروه غیرفعال بود\n➖➖➖➖➖➖➖\n❗️️قفل ارسال فرستان پیام فارسی غیرفعال بود و پیام های فارسی پاک نمیشدند\nتوسط ☆> [$From_id](tg://user?id=$From_id)",'parse_mode'=>"MarkDown"]);
}
}

if(preg_match("/^(قفل گیف)$/i", $message)){
if($data[$chat_id]['lock']['gif'] == "🔐"){
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》ارسال #تصاویر_متحرک در گروه ممنوع بود🔒\n➖➖➖➖➖➖➖\n❗️️قفل ارسال تصاویر_متحرک فعال بود و تمام پیام های حاوی تصاویر_متحرک پاک میشدند\nتوسط ☆> [$From_id](tg://user?id=$From_id)",'parse_mode'=>"MarkDown"]);
}else{
$data[$chat_id]['lock']['gif']="🔐";
$Json = json_encode($data,true);
file_put_contents("data/$chat_id.json",$Json);
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》ارسال #تصاویر_متحرک در گروه ممنوع شد🔒\n➖➖➖➖➖➖➖\n❗️️قفل ارسال تصاویر_متحرک فعال شد و تمام پیام های حاوی تصاویر_متحرک پاک میشوند\nتوسط ☆> [$From_id](tg://user?id=$From_id)",'parse_mode'=>"MarkDown"]);
}
}
if(preg_match("/^(بازکردن گیف)$/i", $message)){
if($data[$chat_id]['lock']['gif'] == "🔐"){
$data[$chat_id]['lock']['gif']="🔓";
$Json = json_encode($data,true);
file_put_contents("data/$chat_id.json",$Json);
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》قفل ارسال #تصاویر_متحرک در گروه غیرفعال شد🔒\n➖➖➖➖➖➖➖\n❗️️قفل ارسال تصاویر_متحرک غیرفعال شد و دیگر پیام های حاوی تصاویر_متحرک پاک نمیشوند\nتوسط ☆> [$From_id](tg://user?id=$From_id)",'parse_mode'=>"MarkDown"]);
}else{
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》قفل ارسال #تصاویر_متحرک در گروه غیرفعال بود🔒\n➖➖➖➖➖➖➖\n❗️️قفل ارسال تصاویر_متحرک غیرفعال بود و پیام های حاوی تصاویر_متحرک پاک نمیشدند\nتوسط ☆> [$From_id](tg://user?id=$From_id)",'parse_mode'=>"MarkDown"]);
}
}
if(preg_match("/^(قفل همه)$/i", $message)){
if($data[$chat_id]['lock']['all'] == "🔐"){
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》قفل #همه فعال بود\n➖➖➖➖➖➖➖\n❗️️قفل همه فعال بود و همه پیام های ارسالی در گروه پاک میشدند\nتوسط ☆> [$From_id](tg://user?id=$From_id)",'parse_mode'=>"MarkDown"]);
}else{
$data[$chat_id]['lock']['all']="🔐";
$Json = json_encode($data,true);
file_put_contents("data/$chat_id.json",$Json);
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》قفل #همه فعال شد\n➖➖➖➖➖➖➖\n❗️️قفل همه فعال شد و از این پس همه پیام های ارسالی در گروه پاک میشوند\nتوسط ☆> [$From_id](tg://user?id=$From_id)",'parse_mode'=>"MarkDown"]);
}
}
if(preg_match("/^(بازکردن همه)$/i", $message)){
if($data[$chat_id]['lock']['all'] == "🔐"){
$data[$chat_id]['lock']['all']="🔓";
$Json = json_encode($data,true);
file_put_contents("data/$chat_id.json",$Json);
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》قفل #همه غیرفعال شد \n➖➖➖➖➖➖➖\n❗️️قفل همه غیرفعال شد و همه اجازه چت در گروه را دارند\nتوسط ☆> [$From_id](tg://user?id=$From_id)",'parse_mode'=>"MarkDown"]);
}else{
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》قفل #همه غیرفعال بود \n➖➖➖➖➖➖➖\n❗️️قفل همه غیرفعال بود و همه اجازه چت در گروه را داشتند\nتوسط ☆> [$From_id](tg://user?id=$From_id)",'parse_mode'=>"MarkDown"]);
}
}








if(preg_match("/^(قفل مخاطب)$/i", $message)){
if($data[$chat_id]['lock']['contact'] == "🔐"){
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》ارسال #مخاطب در گروه ممنوع بود🔒\n➖➖➖➖➖➖➖\n❗️️قفل ارسال مخاطب فعال بود و تمام پیام های حاوی مخاطب پاک میشدند\nتوسط ☆> [$From_id](tg://user?id=$From_id)",'parse_mode'=>"MarkDown"]);
}else{
$data[$chat_id]['lock']['contact']="🔐";
$Json = json_encode($data,true);
file_put_contents("data/$chat_id.json",$Json);
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》ارسال #مخاطب در گروه ممنوع شد🔒\n➖➖➖➖➖➖➖\n❗️️قفل ارسال مخاطب فعال شد از این پس تمام پیام های حاوی مخاطب پاک خواهند شد\nتوسط ☆> [$From_id](tg://user?id=$From_id)",'parse_mode'=>"MarkDown"]);
}
}
if(preg_match("/^(بازکردن مخاطب)$/i", $message)){
if($data[$chat_id]['lock']['contact'] == "🔐"){
$data[$chat_id]['lock']['contact']="🔓";
$Json = json_encode($data,true);
file_put_contents("data/$chat_id.json",$Json);
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》قفل ارسال #مخاطب در گروه غیرفعال شد🔒\n➖➖➖➖➖➖➖\n❗️️قفل ارسال مخاطب غیرفعال شد از این پس تمام پیام های حاوی مخاطب پاک نخواهند شد\nتوسط ☆> [$From_id](tg://user?id=$From_id)",'parse_mode'=>"MarkDown"]);
}else{
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》قفل ارسال #مخاطب در گروه غیرفعال بود🔒\n➖➖➖➖➖➖➖\n❗️️قفل ارسال مخاطب غیرفعال بود و پیام های حاوی مخاطب پاک نمیشدند\nتوسط ☆> [$From_id](tg://user?id=$From_id)",'parse_mode'=>"MarkDown"]);
}
}

if(preg_match("/^(قفل اینلاین)$/i", $message)){
if($data[$chat_id]['lock']['inline'] == "🔐"){
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》ارسال #اینلاین در گروه ممنوع بود🔒\n➖➖➖➖➖➖➖\n❗️️قفل ارسال اینلاین فعال بود و تمام پیام های حاوی اینلاین پاک میشدند\nتوسط ☆> [$From_id](tg://user?id=$From_id)",'parse_mode'=>"MarkDown"]);
}else{
$data[$chat_id]['lock']['inline']="🔐";
$Json = json_encode($data,true);
file_put_contents("data/$chat_id.json",$Json);
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》ارسال #اینلاین در گروه ممنوع شد🔒\n➖➖➖➖➖➖➖\n❗️️قفل ارسال اینلاین فعال شد از این پس تمام پیام های حاوی اینلاین پاک خواهند شد\nتوسط ☆> [$From_id](tg://user?id=$From_id)",'parse_mode'=>"MarkDown"]);
}
}
if(preg_match("/^(بازکردن اینلاین)$/i", $message)){
if($data[$chat_id]['lock']['inline'] == "🔐"){
$data[$chat_id]['lock']['inline']="🔓";
$Json = json_encode($data,true);
file_put_contents("data/$chat_id.json",$Json);
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》قفل ارسال #اینلاین در گروه غیرفعال شد🔒\n➖➖➖➖➖➖➖\n❗️️قفل ارسال اینلاین غیرفعال شد از این پس تمام پیام های حاوی اینلاین پاک نخواهند شد\nتوسط ☆> [$From_id](tg://user?id=$From_id)",'parse_mode'=>"MarkDown"]);
}else{
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》قفل ارسال #اینلاین در گروه غیرفعال بود🔒\n➖➖➖➖➖➖➖\n❗️️قفل ارسال اینلاین غیرفعال بود و پیام های حاوی اینلاین پاک نمیشدند\nتوسط ☆> [$From_id](tg://user?id=$From_id)",'parse_mode'=>"MarkDown"]);
}
}









}

}}
}//end mod
}//end
?>
