﻿<?php

if(in_array($chat_id,$mange['grouplist']) && file_exists("data/$chat_id.json")){
if(isset($update['update']['_']) && ($update['update']['_'] == "updateNewChannelMessage")){
if($data[$chat_id]['add']=="✅"){
if($from_id == $admin or in_array($from_id,$data[$chat_id]['ownerlist']) or in_array($from_id,$data[$chat_id]['modlist'])){
//$result = $MadelineProto->channels->getMessages(['channel' => $chat_id, 'id' => [$mid]]);
//foreach($result as $key=>$val){
$From_id = $from_id;
if(strpos($message,"ادفیلتر ")!==false){
$fil = str_replace("ادفیلتر ","",$message);
$fil = trim($fil);
//$filter = array_search($fil,$data[$chat_id]['filterlist']);
if(in_array($fil,$data[$chat_id]['filterlist'])){
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》کلمه #".$fil." در لیست فیلتر قرار داشت📄\n➖➖➖➖➖➖➖\nتوسط ☆> [$From_id](tg://user?id=$From_id)",'parse_mode'=>"MarkDown"]);
}else{
$data[$chat_id]['filterlist'][]="$fil";
$Json = json_encode($data,true);
file_put_contents("data/$chat_id.json",$Json);
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》کلمه #".$fil." به لیست فیلتر اضافه شد📄\n➖➖➖➖➖➖➖\nتوسط ☆> [$From_id](tg://user?id=$From_id)",'parse_mode'=>"MarkDown"]);
}
}
if(strpos($message,'حذف فیلتر ')!==false){
$unfil = str_replace('حذف فیلتر ','',$message);
$unfilte = trim($unfil);
if(in_array($unfilte,$data[$chat_id]["filterlist"])){
$key =array_search($unfilte,$data[$chat_id]["filterlist"]);
unset($data[$chat_id]["filterlist"][$key]);
$data[$chat_id]["filterlist"] = array_values($data[$chat_id]["filterlist"]);
$js = json_encode($data,true);
file_put_contents("data/$chat_id.json",$js);
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》کلمه #".$unfilte." از لیست فیلتر حذف شد📄\n➖➖➖➖➖➖➖\nتوسط ☆> [$From_id](tg://user?id=$From_id)",'parse_mode'=>"MarkDown"]);
}else{
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》کلمه #".$unfilte." در لیست فیلتر قرار نداشت📄\n➖➖➖➖➖➖➖\nتوسط ☆> [$From_id](tg://user?id=$From_id)",'parse_mode'=>"MarkDown"]);
}
}
if(preg_match("/^(لیست فیلتر)$/i", $message)){
$listfilte = $data[$chat_id]['filterlist'];
$listfilter = "";
if($listfilte[0] != ""){
foreach($listfilte as $key=>$fils){
$k = $key+1;
$listfilter .= $k." : ".$listfilte[$key]."\n➖➖➖➖➖➖➖\n";
}
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》📃لیست کلمات #فیلتر\n".$listfilter]);
}else{
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》📃لیست کلمات #فیلتر شده خالی میباشد"]);
}
}
if(preg_match("/^(پاکسازی لیست فیلتر)$/i", $message)){
unset($data[$chat_id]['filterlist']);
$data[$chat_id]['filterlist'] = [];
$Json = json_encode($data,true);
file_put_contents("data/$chat_id.json",$Json);
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》📃لیست کلمات #فیلتر به طور کامل پاک شد"]);
}
}
}}
 }
?>
