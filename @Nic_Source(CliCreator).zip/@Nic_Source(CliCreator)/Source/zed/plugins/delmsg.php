﻿<?php
if(in_array($chat_id,$mange['grouplist']) && file_exists("data/$chat_id.json")){
if(isset($update['update']['_']) && ($update['update']['_'] == "updateNewChannelMessage")){
if($data[$chat_id]['add']=="✅"){
if($from_id == $admin or in_array($from_id,$data[$chat_id]['ownerlist']) or in_array($from_id,$data[$chat_id]['modlist'])){
//$result = $MadelineProto->channels->getMessages(['channel' => $chat_id, 'id' => [$mid]]);
$From_id = $from_id;
if(strpos($message,"پاکسازی ")!==false){
if(!isset($update['update']['message']['reply_to_msg_id'])){
$del = str_replace("پاکسازی","",$message);
if(is_numeric($del)){
for($i = $mid; $i>=$mid-$del;$i--){
$MadelineProto->channels->deleteMessages(['channel' => $chat_id, 'id' => [$i]]);
}
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'message'=>"☆》تعداد #".$del." از پیام های گروه پاک شد\n➖➖➖➖➖➖➖\nتوسط ☆> [$From_id](tg://user?id=$From_id)",'parse_mode'=>"MarkDown"]);
}else{
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'reply_to_msg_id'=>$mid,'message'=>"☆》لطفا مقدار مورد نظر را به صورت #عدد وارد نمایید"]);
}
}
}

if(preg_match("/^(پاکسازی)$/i", $message)){
if(isset($update['update']['message']['reply_to_msg_id'])){
try{
$msgid = $update['update']['message']['reply_to_msg_id'];
$mahd = $MadelineProto->channels->getMessages(['channel' => $chat_id, 'id' => [$msgid]]);
$rtid = $mahd['users'][0]['id'];
$MadelineProto->channels->deleteUserHistory(['channel' => $chat_id, 'user_id' => $rtid ]);
$MadelineProto->messages->sendMessage(['peer'=>$chat_id,'message'=>"☆》تمامی پیام های کاربر #".$rtid." حذف شد\n➖➖➖➖➖➖➖\nتوسط ☆> [$From_id](tg://user?id=$From_id)",'parse_mode'=>"MarkDown"]);
}catch(Exception $e){

}
}
}
}
}}
}

?>
