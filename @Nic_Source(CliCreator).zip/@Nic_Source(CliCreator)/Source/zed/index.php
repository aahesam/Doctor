<?php
/*
✖️کانال نیک سورس✖️
مرجع تخصصی سورس ربات های تلگرامی:

🔸کانال ما:
➰ T.me/Nic_Source ➰

💥خرید هاست:
NicMizban.tk
*/
if (!file_exists('madeline.php')) {
    copy('https://phar.madelineproto.xyz/madeline.php', 'madeline.php');
}
include 'madeline.php';
include 'func.php';

$MadelineProto = new \danog\MadelineProto\API('session.madeline');

$MadelineProto->start();
register_shutdown_function('shutdown_function', $lock);
closeConnection();

$admin = **ADMIN**;

function leggimsg($chat_id, $mid) {
  global $update;
  global $MadelineProto;
  if (isset($chat_id) and isset($mid)) var_export($MadelineProto->messages->readHistory(['peer' => $chat_id, 'max_id' => $mid]));
}

$offset = 0;

function BanUser($chat_id,$from_id){

global $update;

global $MadelineProto;

if(!isset($chat_id) && !isset($from_id)){
return;
}
if(isset($chat_id) && isset($from_id)){
try{
$channelBannedRights = ['_' => 'channelBannedRights', 'view_messages' => true, 'send_messages' => false, 'send_media' => false, 
'send_stickers' => false, 
'send_gifs' => false,
 'send_games' => false, 
'send_inline' => false,
 'embed_links' => false,
 'until_date' => 0
];
$kickback = $MadelineProto->channels->editBanned(
[
'channel'=> $chat_id,
'user_id'=> $from_id,                          'banned_rights' => $channelBannedRights 
]
);

}catch(Exception $e){

}
}

}//Function BanUser

function UnBanUser($chat_id,$from_id){

global $update;

global $MadelineProto;

if(!isset($chat_id) && !isset($from_id)){
return;
}
if(isset($chat_id) && isset($from_id)){
try{
$channelBannedRights = ['_' => 'channelBannedRights',
'view_messages' => true,
'send_messages' => true,
'send_media' => true, 
'send_stickers' => true, 
'send_gifs' => true,
'send_games' => true, 
'send_inline' => true,
'embed_links' => true,
'until_date' => 0
];
$kickback = $MadelineProto->channels->editBanned(
[
'channel'=> $chat_id,
'user_id'=> $from_id,                          'banned_rights' => $channelBannedRights 
]
);

}catch(Exception $e){

}
}

}//Function UnBanUser



while (true) {

  $updates = $MadelineProto->get_updates(['offset' => $offset, 'limit' => 50, 'timeout' => 0]);

  foreach ($updates as $update) {

    $offset = $update['update_id'] + 1;

	 $pplist = json_decode(file_get_contents("data/plugins.json"),true);

$mange = json_decode(file_get_contents("data/data.json"),true);

                if (isset($update['update']['message']['out']) && $update['update']['message']['out']) {
                    continue;
                }
    $message='';
    if(isset($update['update']['message']['message'])){
     $message = $update['update']['message']['message'];
$mid = $update['update']['message']['id'];
    }

if(isset($update['update']['message']['to_id']['user_id'])){
$rtid = $update['update']['message']['to_id']['user_id'];
}

if(!file_exists("file.error")){
touch("file.error");
}

if(isset($update['update']['message']['from_id'])){
       $from_id = $update['update']['message']['from_id'];
       $peer = $from_id;
      }

      if(isset($update['update']['message']['to_id']['channel_id'])){
       $channel_id = $update['update']['message']['to_id']['channel_id'];
       $peer = "-100".$channel_id;
 
 }
   //  
////--
if(isset($update['update']['message']['action'])){
$action = $update['update']['message']['action'];
}
if(isset($update['update']['message']['to_id']) && ($update['update']['message']['to_id']['_'] == "peerChannel")){
$eg = "-100".$update['update']['message']['to_id']['channel_id'];
try{
      $getinformation = $MadelineProto->get_full_info($eg);

     $tc = $getinformation['type'];     
if($tc == "supergroup"){
   $information = $getinformation['Chat'];
$gpname = $information['title'];
     $chat_i = $information['id'];
$chat_id = "-100".$chat_i; 
$membergp = $getinformation['full']['participants_count'];
    $aboutgp = $getinformation['full']['about'];
}
}catch(Exception $e){

}
}





if(isset($update['update']['message']['date']))
{
 $minutiv = date("i", time());
 $minutit = date("i", $update['update']['message']['date']);
if($minutiv == $minutit)
{

try{
if(in_array($chat_id,$mange['grouplist']) && file_exists("data/$chat_id.json")){
$data = json_decode(file_get_contents("data/$chat_id.json"),true);
}
require 'plugin.php';
 } catch (\danog\MadelineProto\RPCErrorException $e) {
    file_put_contents("file.error",$e->getMessage());
                }                       
}}      
 }   
}

