<?php
//ايدي عددي شما
$myid = **ADMIN**;
//ايدي عددي ربات cli
$idbotcli =**idadd**;
//توكن هلپر
define("API_KEY","**token**");
// آیدی بات هلپرم تو plugin.php ست کن😐
?>
