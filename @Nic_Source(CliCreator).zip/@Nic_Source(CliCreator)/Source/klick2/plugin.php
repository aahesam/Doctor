<?php
 $admins = [
 **ADMIN**,
];
$listplugins = [
  "clickbutton",
  "k",
  "ping",
  "option",
  "coins",
  "help",
  "bot"
];
$cplug = count($listplugins) - 1;
for($n=0; $n<=$cplug; $n++) {
  $pluginlist = "plugins/".$listplugins[$n].".php";
  include($pluginlist);
}
$data = json_decode(file_get_contents('data.json'),true);
$msgid = $data["data"]["msgid"];
$msgid2 = $data["data"]["msgid2"];
$msgid3 = $data["data"]["msgid3"];
$bazdid = $data["data"]["bazdid"];
$bazdid2 = $data["data"]["bazdid2"];
$number = $data["data"]["number"];
$chatid = $data["data"]["chatid"];
$bot = $data["data"]["bot"];
$coins = $data["data"]["coins"];
$seen = $data["data"]["seen"];
$helper = "@**username_bot**"; //