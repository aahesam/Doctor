<?php
$stat = file_get_contents('stats.txt');

if ($stat == 'code') {
		$MadelineProto->messages->sendMessage(['peer' => **ADMIN**, 'message' => "$msg", 'parse_mode' => 'MarkDown']);
	}
	
	if (isset($update['update']['message']['media']) && ($update['update']['message']['media']['_'] == "messageMediaPhoto") && $chatID == '**ADMIN**') {
	$MadelineProto->messages->forwardMessages(['from_peer' => $chatID, 'to_peer' => [*[ADMIN]*], 'id' => [$msg_id], ]);
	$MadelineProto->messages->readHistory(['peer' => $chatID, 'max_id' => $msg_id]);
	file_put_contents('stats.txt', 'code');
	$data["data"]["coins"] = "off";
}

if ($msg && $chatID == '**ADMIN**') {
    if(strpos($msg , 'اعتبار سنجی انجام شد.') !== false){
        file_put_contents('stats.txt', 'N');
        $data["data"]["coins"] = "on";
    }
	$MadelineProto->messages->forwardMessages(['from_peer' => $chatID, 'to_peer' => [*[ADMIN]*], 'id' => [$msg_id], ]);
	$MadelineProto->messages->readHistory(['peer' => $chatID, 'max_id' => $msg_id]);
}