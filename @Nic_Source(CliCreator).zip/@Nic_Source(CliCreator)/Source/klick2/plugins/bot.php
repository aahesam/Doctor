<?php
if (in_array($userID, $admins)){

if($msg == "bot on"){
              if($bot=='off'){
             $data["data"]["bot"] = "on";
             file_put_contents("data.json",json_encode($data));
              $MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => "ربات آنلاین شد✅",'parse_mode' => 'MarkDown']);
            }else{
            $MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => "ربات از قبل آنلاین بود⚠",'parse_mode' => 'MarkDown']);
            }
}
if($msg == "bot off"){
              if($bot=='on'){
             $data["data"]["coins"] = "off";
             file_put_contents("data.json",json_encode($data));
              $MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => "ربات آفلاین شد✅",'parse_mode' => 'MarkDown']);
            }else{
            $MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => "ربات از قبل آفلاین بود⚠️",'parse_mode' => 'MarkDown']);
            }
}
if($msg == "ربات آنلاین"){
              if($bot=='off'){
             $data["data"]["bot"] = "on";
             file_put_contents("data.json",json_encode($data));
              $MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => "ربات آنلاین شد✅",'parse_mode' => 'MarkDown']);
            }else{
            $MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => "ربات از قبل آنلاین بود⚠",'parse_mode' => 'MarkDown']);
            }
}
if($msg == "ربات آفلاین"){
              if($bot=='on'){
             $data["data"]["coins"] = "off";
             file_put_contents("data.json",json_encode($data));
              $MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => "ربات آفلاین شد✅",'parse_mode' => 'MarkDown']);
            }else{
            $MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => "ربات از قبل آفلاین بود⚠️",'parse_mode' => 'MarkDown']);
            }
}
 
    
    
    }