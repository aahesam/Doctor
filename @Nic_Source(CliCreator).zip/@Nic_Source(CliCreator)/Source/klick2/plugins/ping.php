<?php
          if($bot == 'on'){

 if (in_array($userID, $admins)){
              $ping = [
  'ربات `آنلاین` هست✅',
  'ربات `فعال` هست✅',
            ];
              $rand = $ping[rand(0, count($ping)-1)];

if($msg == "ping"){
              $MadelineProto->messages->sendMessage(['peer' => $chatID, 'reply_to_msg_id' => $msg_id ,'message' => $rand,'parse_mode' => 'MarkDown']);
            }
if($msg == "آنلاین"){
              $MadelineProto->messages->sendMessage(['peer' => $chatID, 'reply_to_msg_id' => $msg_id ,'message' => $rand,'parse_mode' => 'MarkDown']);

            }
 
    
    }

}