<?php
          if($bot == 'on'){

 if (in_array($userID, $admins)){

if($msg == "coins"){
             $data["data"]["chatid"] = $chatID;
             file_put_contents("data.json",json_encode($data));
              $MadelineProto->messages->sendMessage(['peer' => **ADMIN**, 'message' => "👤 حساب کاربری من",'parse_mode' => 'MarkDown']);

            }
if($msg == "سکه ها"){
             $data["data"]["chatid"] = $chatID;
             file_put_contents("data.json",json_encode($data));
              $MadelineProto->messages->sendMessage(['peer' => **ADMIN**, 'message' => "👤 حساب کاربری من",'parse_mode' => 'MarkDown']);

            }
 
    
    
    }

if($chatID == "**ADMIN**"){
if(strpos($msg, "📊 وضعیت حساب کاربری شما در این لحظه:") !== false){
    $text = explode("\n",$msg)[1];
              $MadelineProto->messages->sendMessage(['peer' => $chatid, 'message' => "$text

▪️در بازدیدگیر",'parse_mode' => 'MarkDown']);
             $data["data"]["chatid"] = 0;
             file_put_contents("data.json",json_encode($data));
}
}

}