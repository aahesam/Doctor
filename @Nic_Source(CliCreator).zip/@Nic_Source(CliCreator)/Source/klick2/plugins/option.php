<?php
          if($bot == 'on'){

if (in_array($userID, $admins)){

if($msg == "analyz"){
              $mgid = $msgid-1;
              $mgid2 = $msgid2-1;
              $MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => "🐲 ️آخرین پست بازدید شده بازدیدگیر:👇[‌](https://t.me/BazdidGirPosts/$mgid)",'parse_mode' => 'MarkDown']);
            }
if($msg == "آنالیز"){
              $mgid = $msgid-1;
              $mgid2 = $msgid2-1;
              $MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => "🐲 ️آخرین پست بازدید شده بازدیدگیر:👇[‌](https://t.me/BazdidGirPosts/$mgid)",'parse_mode' => 'MarkDown']);
            }
if($msg == "coins on"){
              if($coins=='off'){
             $data["data"]["coins"] = "on";
             file_put_contents("data.json",json_encode($data));
              $MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => "دریافت سکه آنلاین شد✅",'parse_mode' => 'MarkDown']);
            }else{
            $MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => "دریافت سکه از قبل آنلاین بود⚠",'parse_mode' => 'MarkDown']);
            }
}
if($msg == "دریافت سکه آنلاین"){
              if($coins=='off'){
             $data["data"]["coins"] = "on";
             file_put_contents("data.json",json_encode($data));
              $MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => "دریافت سکه آنلاین شد✅",'parse_mode' => 'MarkDown']);
            }else{
            $MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => "دریافت سکه از قبل آنلاین بود⚠",'parse_mode' => 'MarkDown']);
            }
}
if($msg == "coins off"){
              if($coins=='on'){
             $data["data"]["coins"] = "off";
             file_put_contents("data.json",json_encode($data));
              $MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => "دریافت سکه آفلاین شد✅",'parse_mode' => 'MarkDown']);
            }else{
            $MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => "دریافت سکه از قبل آفلاین بود⚠️",'parse_mode' => 'MarkDown']);
            }
}
if($msg == "دریافت سکه آفلاین"){
              if($coins=='on'){
             $data["data"]["coins"] = "off";
             file_put_contents("data.json",json_encode($data));
              $MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => "دریافت سکه آفلاین شد✅",'parse_mode' => 'MarkDown']);
            }else{
            $MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => "دریافت سکه از قبل آفلاین بود⚠️",'parse_mode' => 'MarkDown']);
            }
}
 
    
    }

}