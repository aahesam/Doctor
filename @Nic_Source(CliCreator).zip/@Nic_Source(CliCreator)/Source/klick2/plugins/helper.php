<?php
include('../config.php');
function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}
function reload($id){
	$database = json_decode(file_get_contents("../data.json"), true);
    $bot = $database["data"]["bot"];
    $coins = $database["data"]["coins"];
    $seen = $database["data"]["seen"];
    $number = $database["data"]["number"];
	bot("editmessagetext", [
			"text"=>"پنل تنظیمات کلیکر | ورژن 4.1🤖",
		"inline_message_id"=>$id,
		"parse_mode"=>"MarkDown",
		"reply_markup"=>json_encode([
				"inline_keyboard"=>[
						[
								["text" => "🤖وضعیت ربات🤖", "callback_data" => "none"],["text" => "👾 $bot 👾", "callback_data" => "bot"]
						],
						[
							["text" => "👀دریافت سکه💰", "callback_data" => "none"],["text" => "👾 $coins 👾", "callback_data" => "coins"]
						],
						[
							["text" => "👁سین کردن پیام👀", "callback_data" => "none"],["text" => "👾 $seen 👾", "callback_data" => "seen"]
						],
						[
							["text" => "🔙back | برگشت🔙", "callback_data" => "back"]
						]
				]
		])
		]);
}
function bazdid($id){
	$database = json_decode(file_get_contents("../data.json"), true);
	$msgid = $database['data']['msgid']-1;
	bot("editmessagetext", [
			"text"=>"آخرین پست های بازدید شده👀",
		"inline_message_id"=>$id,
		"parse_mode"=>"MarkDown",
		"reply_markup"=>json_encode([
				"inline_keyboard"=>[
						[
								["text" => "👀بازدیدگیر👁", "callback_data" => "none"],["text" => $msgid, "url" => "https://t.me/BazdidGirPosts/$msgid"]
						],
						[
							["text" => "🔄بروزرسانی🔄", "callback_data" => "broz"],["text" => "🔙back | برگشت🔙", "callback_data" => "back"]
						]
				]
		])
		]);
}
function broz($id){
	$database = json_decode(file_get_contents("../data.json"), true);
	$msgid = $database['data']['msgid']-1;
	bot("editmessagetext", [
			"text"=>"بروزرسانی شد👽🔄",
		"inline_message_id"=>$id,
		"parse_mode"=>"MarkDown",
		"reply_markup"=>json_encode([
				"inline_keyboard"=>[
						[
								["text" => "👀بازدیدگیر👁", "callback_data" => "none"],["text" => $msgid, "url" => "https://t.me/BazdidGirPosts/$msgid"]
						],
						[
							["text" => "🔄بروزرسانی🔄", "callback_data" => "broz"],["text" => "🔙back | برگشت🔙", "callback_data" => "back"]
						]
				]
		])
		]);
}
//
$update = json_decode(file_get_contents("php://input"));
$message = $update->message;
$chat_id = $message->chat->id;
$from_id= $message->from->id;
$text = $message->text;
$message_id = $message->message_id;
$data = $update->callback_query->data;
$inid = $update->callback_query->from->id;
$in_msg = $update->inline_query->query;
$iid = $update->inline_query->from->id;
$msg_id = $update->callback_query->message->message_id;
$inmsgid = $update->callback_query->inline_message_id;
@$database = json_decode(file_get_contents("../data.json"), true);
if($text == "/start"){
	bot("sendMessage",[
	"chat_id"=>$chat_id,
	"text"=>"هِلُ جیگر",
	"parse_mode"=>"MarkDown"
	]);
}
if(preg_match("/^data@(.*)$/", $data)){
	preg_match("/^data@(.*)$/", $data, $q);
	bot("answerCallbackQuery",[
		"callback_query_id"=>$update->callback_query->id,
		"text"=>$q[1]
			]);
}
if($in_msg == "panel"){
	bot("answerInlineQuery",[
		"inline_query_id"=>$update->inline_query->id,
		"results"=>json_encode([[
			"type"=>"article",
			"id"=>base64_encode(rand(5,555)),
			"title"=>"panel",
			"input_message_content"=>["parse_mode"=>"MarkDown","message_text"=>"پنل مدیریت ربات کلیکر | ورژن 4.1🤖"],
			"reply_markup"=>["inline_keyboard"=>[
				[
					["text"=>"🤖تنظیمات ربات🤖","callback_data"=>"pnl"],["text"=>"🤔راهنما⁉️","callback_data"=>"hlp"]
				],
				[
					["text"=>"👁آخرین پست بازدید شده👀","callback_data"=>"bazdid"]
				],
				[
					["text"=>"","callback_data"=>"test"]
				]
				]]
		]])
	]);
}
if($data == "pnl" && $inid == $myid){
	bot("answerCallbackQuery",[
		"callback_query_id"=>$update->callback_query->id,
		"text"=>"پنل تنظیمات کلیکر⚙"
			]);
		reload($inmsgid);
}
if($data == "bazdid" && $inid == $myid){
	bot("answerCallbackQuery",[
		"callback_query_id"=>$update->callback_query->id,
		"text"=>"آخرین پست های بازدید شده👀"
			]);
		bazdid($inmsgid);
}
if($data == "broz" && $inid == $myid){
	bot("answerCallbackQuery",[
		"callback_query_id"=>$update->callback_query->id,
		"text"=>"درحال بروزرسانی🔄"
			]);
		broz($inmsgid);
}
if($data == "bot" && $inid == $myid){
	$s = $database["data"]["bot"];
	if($s == "on"){
        $database["data"]["bot"] = "off";
        file_put_contents("../data.json",json_encode($database));
		reload($inmsgid);
	}elseif($s == "off"){
        $database["data"]["bot"] = "on";
        file_put_contents("../data.json",json_encode($database));
		reload($inmsgid);
	}
}
if($data == "coins" && $inid == $myid){
	$s = $database["data"]["coins"];
	if($s == "on"){
        $database["data"]["coins"] = "on";
        file_put_contents("../data.json",json_encode($database));
		reload($inmsgid);
	}elseif($s == "off"){
        $database["data"]["coins"] = "on";
        file_put_contents("../data.json",json_encode($database));
		reload($inmsgid);
	}
}
if($data == "seen" && $inid == $myid){
	$s = $database["data"]["seen"];
	if($s == "on"){
        $database["data"]["seen"] = "off";
        file_put_contents("../data.json",json_encode($database));
		reload($inmsgid);
	}elseif($s == "off"){
        $database["data"]["seen"] = "on";
        file_put_contents("../data.json",json_encode($database));
		reload($inmsgid);
	}
}
if($data == "back" && $inid == $myid){
	bot("editmessagetext", [
			"text"=>"پنل مدیریت کلیکر | ورژن 4.1🤖",
		"inline_message_id"=>$inmsgid,
		"parse_mode"=>"MarkDown",
		"reply_markup"=>json_encode([
			"inline_keyboard"=>[
				[
					["text"=>"🤖تنظیمات ربات🤖","callback_data"=>"pnl"],["text"=>"🤔راهنما⁉️","callback_data"=>"hlp"]
				],
				[
					["text"=>"👁آخرین پست بازدید شده👀","callback_data"=>"bazdid"]
				]
				]
		])
		]);
}
if($data == "/help" && $inid == $myid){
	bot("editmessagetext", [
			"text"=>"👈 راهنما ربات کلیکر 👉

🤖 Created By : @Cli_Creator_Bot ⤵️

🐲️ روشن/خاموش کردن ربات
bot (on/off)
🐲️ اطلاع از آنلاین بودن ربات
ping
🐲️ روشن/خاموش کردن حالت جمع کردن سکه
coins (on/off)
🐲 دریافت آخرین پیام بازدید شده
analyz
🐲 نمایش تنظیمات ربات
panel
🐲️ دریافت تعداد سکه ها
coins
🐲️ راهنمای ربات
help
@EliyaTM
⚠️توجه: اگر بخواهید پنل شیشه ای کلیکرتان کار کند، حتما باید در ربات هلپر شما قابلیت اینلاین فعال باشد!

❗️نکته: درحال حاظر کلیکر شما از سه تبلیغ که دریافت کند فقط یکی از آن سه تبلیغ را مشاهده کرده و سکه آن را جمع آوری خواهد کرد .",
		"inline_message_id"=>$inmsgid,
		"reply_markup"=>json_encode([
			"inline_keyboard"=>[
				[
					["text" => "🔙back | برگشت🔙", "callback_data" => "back"]
				]
				]
		])
		]);
}
?>