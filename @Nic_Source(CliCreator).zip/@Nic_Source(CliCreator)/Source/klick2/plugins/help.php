<?php
          if($bot == 'on'){

 if (in_array($userID, $admins)){

if($msg == "help"){
              $MadelineProto->messages->sendMessage(['peer' => $chatID, 'reply_to_msg_id' => $msg_id ,'message' => "👈 راهنما ربات کلیکر 👉

🤖 Created By : @Cli_Creator_Bot ⤵️

🐲️ روشن/خاموش کردن ربات
bot (on/off)
🐲️ اطلاع از آنلاین بودن ربات
ping
🐲️ روشن/خاموش کردن حالت جمع کردن سکه
coins (on/off)
🐲 دریافت آخرین پیام بازدید شده
analyz
🐲 نمایش تنظیمات ربات
panel
🐲️ دریافت تعداد سکه ها
coins
🐲️ راهنمای ربات
help

⚠️توجه: اگر بخواهید پنل شیشه ای کلیکرتان کار کند، حتما باید در ربات هلپر شما قابلیت اینلاین فعال باشد!

❗️نکته: درحال حاظر کلیکر شما از سه تبلیغ که دریافت کند فقط یکی از آن سه تبلیغ را مشاهده کرده و سکه آن را جمع آوری خواهد کرد .",'parse_mode' => 'MarkDown']);

            }
            if($msg == "/help"){
              $MadelineProto->messages->sendMessage(['peer' => $chatID, 'reply_to_msg_id' => $msg_id ,'message' => "👈 راهنما ربات کلیکر 👉

🤖 Created By : @Cli_Creator_Bot ⤵️

🐲️ روشن/خاموش کردن ربات
bot (on/off)
🐲️ اطلاع از آنلاین بودن ربات
ping
🐲️ روشن/خاموش کردن حالت جمع کردن سکه
coins (on/off)
🐲 دریافت آخرین پیام بازدید شده
analyz
🐲 نمایش تنظیمات ربات
panel
🐲️ دریافت تعداد سکه ها
coins
🐲️ راهنمای ربات
help

⚠️توجه: اگر بخواهید پنل شیشه ای کلیکرتان کار کند، حتما باید در ربات هلپر شما قابلیت اینلاین فعال باشد!

❗️نکته: درحال حاظر کلیکر شما از سه تبلیغ که دریافت کند فقط یکی از آن سه تبلیغ را مشاهده کرده و سکه آن را جمع آوری خواهد کرد .",'parse_mode' => 'MarkDown']);

            }
if($msg == "راهنما"){
              $MadelineProto->messages->sendMessage(['peer' => $chatID, 'reply_to_msg_id' => $msg_id ,'message' => "👈 راهنما ربات کلیکر 👉

🤖 Created By : @Cli_Creator_Bot ⤵️

🐲️ روشن/خاموش کردن ربات
bot (on/off)
🐲️ اطلاع از آنلاین بودن ربات
ping
🐲️ روشن/خاموش کردن حالت جمع کردن سکه
coins (on/off)
🐲 دریافت آخرین پیام بازدید شده
analyz
🐲 نمایش تنظیمات ربات
panel
🐲️ دریافت تعداد سکه ها
coins
🐲️ راهنمای ربات
help

⚠️توجه: اگر بخواهید پنل شیشه ای کلیکرتان کار کند، حتما باید در ربات هلپر شما قابلیت اینلاین فعال باشد!

❗️نکته: درحال حاظر کلیکر شما از سه تبلیغ که دریافت کند فقط یکی از آن سه تبلیغ را مشاهده کرده و سکه آن را جمع آوری خواهد کرد .",'parse_mode' => 'MarkDown']);

            }
if($msg == "panel"){
$messages_BotResults = $MadelineProto->messages->getInlineBotResults(['bot' => "@[*[BOTID]*]", 'peer' => $chatID, 'query' => "panel", 'offset' => '0', ]);
$query_id = $messages_BotResults['query_id'];
$query_res_id = $messages_BotResults['results'][0]['id'];
$MadelineProto->messages->sendInlineBotResult(['silent' => true, 'background' => false, 'clear_draft' => true, 'peer' => $chatID, 'reply_to_msg_id' => $msg_id, 'query_id' => $query_id, 'id' => "$query_res_id", ]);
}
if($msg == "پنل"){
$messages_BotResults = $MadelineProto->messages->getInlineBotResults(['bot' => "@[*[BOTID]*]", 'peer' => $chatID, 'query' => "panel", 'offset' => '0', ]);
$query_id = $messages_BotResults['query_id'];
$query_res_id = $messages_BotResults['results'][0]['id'];
$MadelineProto->messages->sendInlineBotResult(['silent' => true, 'background' => false, 'clear_draft' => true, 'peer' => $chatID, 'reply_to_msg_id' => $msg_id, 'query_id' => $query_id, 'id' => "$query_res_id", ]);
}
 
    
    }

}