<?php
$v = rand(1,3);
$t = rand(2,4);
          if($bot == 'on'){
     if (isset($update['update']['message']['reply_markup']['rows'])) {
          if($coins == 'on'){
          if($chatID == -1001101208999){
          $msgid = $msg_id-1;
          $MadelineProto->channels->readMessageContents(['channel' => "-1001101208999", 'id' => [$msgid] ]);
         $MadelineProto->messages->getMessagesViews(['peer' => -1001101208999, 'id' => [$msgid], 'increment' => true, ]);
         file_get_contents("https://t.me/ibazdidads/$msgid");
         $bazdidd = $bazdid+1;
         $data["data"]["bazdid"] = $bazdidd;
         file_put_contents("data.json",json_encode($data));
          if($v == '2'){
         $data["data"]["bazdid"] = 0;
         $data["data"]["msgid"] = $msg_id;
         file_put_contents("data.json",json_encode($data));
            foreach ($update['update']['message']['reply_markup']['rows'] as $row) {
                foreach ($row['buttons'] as $button) {
                    if($button['text'] == 'ثبت بازدید 👁‍🗨'){
                    sleep($t);
                    $button->click();
               }
            }
        }
     }
}
}
}

}
?>
    