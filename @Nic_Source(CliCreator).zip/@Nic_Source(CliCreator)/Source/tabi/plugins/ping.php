<?php
      if (in_array($userID, $admins)){

	if($msg == '/ping' ||$msg=="انلاینی" ||$msg=="آنلاینی"){
              $MadelineProto->messages->sendMessage(['peer' => $chatID, 'reply_to_msg_id' => $msg_id ,'message' => 'آنلاینم داداچ😎
🤠
👕
👖','parse_mode' => 'MarkDown']);
            }
      }