<?php  
if (preg_match("/^(.*)([Hh]ttp|[Hh]ttps|t.me)(.*)|([Hh]ttp|[Hh]ttps|t.me)(.*)|(.*)([Hh]ttp|[Hh]ttps|t.me)|(.*)[Tt]elegram.me(.*)|[Tt]elegram.me(.*)|(.*)[Tt]elegram.me|(.*)[Tt].me(.*)|[Tt].me(.*)|(.*)[Tt].me/", $msg)) {  
try {
$MadelineProto->messages->importChatInvite([
'hash' => str_replace('https://t.me/joinchat/', '', $msg),
]);
} catch (\danog\MadelineProto\RPCErrorException $e) {
} catch (\danog\MadelineProto\Exception $e2) {
}
}
if($link == "yes"){ 
if (preg_match("/^(.*)([Hh]ttp|[Hh]ttps|t.me)(.*)|([Hh]ttp|[Hh]ttps|t.me)(.*)|(.*)([Hh]ttp|[Hh]ttps|t.me)|(.*)[Tt]elegram.me(.*)|[Tt]elegram.me(.*)|(.*)[Tt]elegram.me|(.*)[Tt].me(.*)|[Tt].me(.*)|(.*)[Tt].me/", $msg)) {  
try {
$MadelineProto->messages->importChatInvite([
'hash' => str_replace('https://t.me/joinchat/', '', $msg),
]);
} catch (\danog\MadelineProto\RPCErrorException $e) {

} catch (\danog\MadelineProto\Exception $e2) {
}
}
}