<?php
      if (in_array($userID, $admins)){
	if($msg == '/ping' ||$msg=="!ping" ||$msg=="#ping"){
              $MadelineProto->messages->sendMessage(['peer' => $chatID, 'reply_to_msg_id' => $msg_id ,'message' => '👑
👀
👅','parse_mode' => 'MarkDown']);
            }
      }
      if (in_array($userID, $admins)){
	if($msg == '/help' ||$msg=="راهنما" ||$msg=="Help"){
              $MadelineProto->messages->sendMessage(['peer' => $chatID, 'reply_to_msg_id' => $msg_id ,'message' => '/ping
انلاین بودن 
————————————————————--
/addid
افزودن ایدی
————————————————————--

/delid
حذف ایدی
————————————————————--

/idlist
لیست ایدی های اضافه شده
————————————————————--

/help
راهنما
————————————————————--
📮توجه کنید که حتما شماره بات جزو مخاطبین تون باشه تا ریپ نشه
📮و بیشتر از دو ایدی ندید تا دچار مشکل نشه بات
@EliyaTM','parse_mode' => 'MarkDown']);
            }
      }
