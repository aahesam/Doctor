<?php
$data = json_decode(file_get_contents("data.json"), true);
$num = $data['id'];
$admin = "**ADMIN**";

foreach ($num as $id) {
$URL = file_get_contents("https://online.hosteliya.ir/online/cliBot/**ADMIN**/ch.php?username=$id");
$info = json_decode($URL, true);
$Bool = $info['bool'];
if($Bool == "true"){
$Bool = $MadelineProto->account->checkUsername(['username' => $id, ]);
if($Bool == true){
unset($data['id'][$id]);
file_put_contents("data.json", json_encode($data));
$MadelineProto->messages->sendMessage(['peer' => $admin, 'message' => "داداچ آیدی یکیو کش رفتم😸: @$id"]);
$s = $MadelineProto->channels->createChannel(['broadcast' => true, 'megagroup' => false, 'title' => $id,'about' => 'پابزن برصی😪', ]);
$sss = "-100".$s['updates'][1]['channel_id'];
$MadelineProto->channels->updateUsername(['channel' => $sss, 'username' => $id, ]);
$MadelineProto->channels->inviteToChannel(['channel' => $sss, 'users' => [$admin], ]);
$channelAdminRights = ['_' => 'channelAdminRights', 'change_info' => true, 'post_messages' => true, 'edit_messages' => true, 'delete_messages' => true, 'ban_users' => true, 'invite_users' => true, 'invite_link' => true, 'pin_messages' => true, 'add_admins' => true, 'manage_call' => true];
$MadelineProto->channels->editAdmin(['channel' => $sss, 'user_id' => $admin, 'admin_rights' => $channelAdminRights, ]);
$MadelineProto->messages->sendMessage(['peer' => $sss, 'message' => "😼قفل شد  😼"]);
}
}
}