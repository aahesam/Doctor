<?php
      if (in_array($userID, $admins)){
if(preg_match("/^[\/\#\!]?(delid) (.*)$/i", $msg)){
preg_match("/^[\/\#\!]?(delid) (.*)$/i", $msg, $d);
								$id = $d[2];
								if(isset($data['id'][$id])){
									unset($data['id'][$id]);
									file_put_contents("data.json", json_encode($data));
$MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' => "با موفقیت حذف شد✔️"]);
								} else{
$MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' => "✖️ایدی وجود نداشت"]);
								}
							}
}
