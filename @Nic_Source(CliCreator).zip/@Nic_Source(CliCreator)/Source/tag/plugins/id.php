<?php  
      if (in_array($userID, $admins)){
          if(preg_match("/^[\/\#\!]?(addid) (.*)$/i", $msg)){
		    preg_match("/^[\/\#\!]?(addid) (.*)$/i", $msg, $d);
		    $i = $d[2];
          if(!isset($data['id'][$i])){
					                $data['id'][$i] = $i;
									file_put_contents("data.json", json_encode($data));
									$MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' => "حله داش قاپیدن آیدیش بامن😎"]);
								} else{
									$MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' => "آیدی قبلا زدی هنو پیگیرشم😬 خبری شد بهت میگم🤠"]);
								}
          
    
}
      }
