<?php
      if (in_array($userID, $admins)){
if(preg_match("/^[\/\#\!]?(idlist)$/i", $msg)){
if(count($data['id']) > 0){
									$txxxt = "idList: 
									";
									$counter = 1;
									foreach ($data['id'] as $id) {
										$txxxt .= "$counter: 🆔 $id \n";
										$counter++;
									}
$MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' => $txxxt]);
								} else{
$MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' => "����� ����"]);
								}
							}			

            }
