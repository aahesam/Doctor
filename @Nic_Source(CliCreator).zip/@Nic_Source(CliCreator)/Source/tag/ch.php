<?php
header("content-type:application/json");
$username = $_GET["username"];
function getbio($username){
$url = file_get_contents("https://t.me/$username");
$url=str_replace("\n","",$url);
preg_match('/<div class="tgme_page_description">(.*?)<\/div>/',$url,$match);
if($match[1]!=""){$bio=$match[1];}else{$bio="این کاربر / کانال بیو ندارد";}
preg_match('/<img class="tgme_page_photo_image" src="(.*?)"><\/a>/',$url,$img);
preg_match('/<div class="tgme_page_title">(.*?)<\/div><div class="tgme_page_extra">\s*(.*?)<\/div>/',$url,$match2);
if($match2[1] != "" && $match2[2] != ""){
echo json_encode(["bool"=> "false"]);
}else{
echo json_encode(["bool"=> "true"]);
}
}
$username = str_replace("@","",$username);
if($username != ""){
Echo getbio($username);
}
?>
