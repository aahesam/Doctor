<?php
/*
✖️کانال نیک سورس✖️
مرجع تخصصی سورس ربات های تلگرامی:

🔸کانال ما:
➰ T.me/Nic_Source ➰

💥خرید هاست:
NicMizban.tk
*/
//در لاین 7 ایدی عددی خود را جای گذاری کنید
 $admins = [
  **ADMIN**,
];
$listplugins = [
  "clickbutton",
  "ping",
  "help"
];
$cplug = count($listplugins) - 1;
for($n=0; $n<=$cplug; $n++) {
  $pluginlist = "plugins/".$listplugins[$n].".php";
  include($pluginlist);
}
$data=json_decode(file_get_contents('data.json'),true);
$msgid= $data["data"]["msgid"];
unlink("MadelineProto.log");







