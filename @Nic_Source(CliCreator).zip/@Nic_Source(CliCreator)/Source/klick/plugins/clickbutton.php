<?php
//اگه خواستید ایدی عددی چنل را در لاین 7 عوض کنید.ربات روی چنل ای بازدید است
// ایدی عددی خود را در لاین18 وارد کنید
$IdChannel = -1001141221687;
$MadelineProto->messages->getMessagesViews(['peer' => $IdChannel, 'id' => [$msg_id], 'increment' => true, ]);

     if (isset($update['update']['message']['reply_markup']['rows'])) {
          if($chatID == -1001141221687){
         $data["data"]["msgid"] = $msg_id;
         file_put_contents("data.json",json_encode($data));
            foreach ($update['update']['message']['reply_markup']['rows'] as $row) {
                foreach ($row['buttons'] as $button) {
                    if($button['text']=='ثبت 👁‍🗨'){
                    $button->click();
               }
               }
            }
             $MadelineProto->messages->sendMessage(['peer' => **ADMIN**, 'reply_to_msg_id' => $msg_d ,'message' =>'یه سکه گرفتم!','parse_mode' => 'MarkDown']);
}
         
}