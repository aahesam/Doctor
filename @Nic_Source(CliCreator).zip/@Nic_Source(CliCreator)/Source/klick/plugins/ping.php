<?php
if (in_array($userID, $admins)){
if($msg == 'ping' || $msg == 'Ping' || $msg == '/ping' || $msg == 'آنلاینی' || $msg == 'انلاینی'){
$MadelineProto->messages->sendMessage(['peer' => $chatID, 'reply_to_msg_id' => $msg_id ,'message' => "<b>پ ن پ افلاینم</b>😂",'parse_mode' => 'html']);
}
}