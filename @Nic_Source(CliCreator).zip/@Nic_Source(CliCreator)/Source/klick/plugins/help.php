<?php
if (in_array($userID, $admins)){

if($msg == "/analyz"){
              $MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => "♦️آخرین پست بازدید شده :\n->[ibazdidad](https://t.me/ibazdidads/$msgid)",'parse_mode' => 'MarkDown']);
            }
            
            if($msg == "/help"){
              $MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => "🌷️ راهنمای ربات کلیکر  
🌹️ /analyz
• دریافت آخرین پست سین شده
«»«»«»«»«»«»«»«»«»«»«»«»
🌹️ /ping
• دریافت وضعیت ربات
«»«»«»«»«»«»«»«»«»«»«»«»
🌹️ /help
• دریافت دوباره همین پیام


▁▂▃▄▅▆▇▁▂▃▄▅▆▇

🔸 ساخته شده با ربات :
🆔: @Nic_Source
--------------------
⚠️ادمین عزیز، اگر بخوایین رباتتون افلاین نشه و برای همیشه آنلاین بمونه لطفا به پشتیبانی پیام دهید :
@Mehdi_Yousefii 👨‍💻",'parse_mode' => 'MarkDown']);
            }
 
    
    
    }
