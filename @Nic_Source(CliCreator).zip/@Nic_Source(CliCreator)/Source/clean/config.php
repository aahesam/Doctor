<?php
/**
 * Created by PhpStorm.
 * User: hadi
 * Date: 24/07/2018
 * Time: 05:03 PM
 */



$admin='**ADMIN**'; // ID admin {number}
$bot_id ='**ADMIN**';