<?php
/**
 * Created by PhpStorm.
 * User: hadi
 * Date: 24/07/2018
 * Time: 05:24 PM
 */
include 'config.php';

if(isset($update['update']['message']['to_id']['channel_id'])) {
    $channel = '-100' . $update['update']['message']['to_id']['channel_id'];
    $chh3 = $update['update']['message']['to_id']['channel_id'];
    $id=$update['update']['message']['id'];

    $etelaat = $MadelineProto->get_pwr_chat($channel);
    $chat5 = $etelaat['participants'];
    foreach($chat5 as $key=>$val){

        $admdinss=$chat5[$key];
        if($admdinss['role']=='creator'){
            if($admdinss['user']['id']==$from_id){
                if(strpos($message,'!del ')!==false){

                    $num=str_replace('!del ','',$message);
                    $arr=[];
                    $id=$update['update']['message']['id'];
                    for($i=$id;$i>=$id-$num; $i--){
                        $kooos=$MadelineProto->channels->getMessages(['channel' => $channel, 'id' => [$i] ]);

                        if(isset($kooos['chats'][0]['id'])){
                            $arr[]= $i;
                        }else{
                            $num++;
                        }//if

                    }//loop
                    $messages_AffectedMessages = $MadelineProto->channels->deleteMessages(['channel' => $channel, 'id' => $arr]);

                    $MadelineProto->messages->sendMessage(['peer'=>$channel,'message'=>'عملیات مورد نظر انجام شد !']);
                }elseif(strpos($message,'!ping')!==false){
                    $MadelineProto->messages->sendMessage(['peer'=>$channel,'message'=>'من آنلاین هستم !']);

                }


            }
        }

    }
    $Chat85 = $MadelineProto->get_full_info($from_id);

    if($Chat85['User']['bot']==true and $Chat85['User']['id']!=$bot_id ){
        $messages_AffectedMessages = $MadelineProto->channels->deleteMessages(['channel' => $channel, 'id' => [$id] ]);

    }

}