<?php
/*
✖️کانال نیک سورس✖️
مرجع تخصصی سورس ربات های تلگرامی:

🔸کانال ما:
➰ T.me/Nic_Source ➰

💥خرید هاست:
NicMizban.tk
 */

$phpversion = explode('.', phpversion());
if(intval($phpversion[0]) >= 7) {
    include 'config.php';

    if (!file_exists('madeline.php')) {
        copy('https://phar.madelineproto.xyz/madeline.php', 'madeline.php');
    }
    include 'madeline.php';
    $MadelineProto = new \danog\MadelineProto\API('session.madeline');
    $MadelineProto->start();
    $offset=0;
    while (true) {
        $updates = $MadelineProto->get_updates(['offset' => $offset, 'limit' => 50, 'timeout' => 0]);
        \danog\MadelineProto\Logger::log($updates);
        foreach ($updates as $update) {
            $offset = $update['update_id'] + 1;
            $up = $update['update']['_'];
            if ($up == 'updateNewMessage' or $up == 'updateNewChannelMessage') {
                if (isset($update['update']['message']['out']) && $update['update']['message']['out']) {
                    continue;
                }
                $up = $MadelineProto->get_info($update['update']);
                $chatID = $up['bot_api_id'];
                $type = $up['type'];
                $from_id = $update['update']['message']['from_id'];
                $message='';
                if(isset($update['update']['message']['message'])){
                    $message = $update['update']['message']['message'];
                }                $msg_id = $update['update']['message']['id'];
                try{
                    include 'PG.php';
                }
                catch (\danog\MadelineProto\RPCErrorException $e) {
                    $MadelineProto->messages->sendMessage(['peer' => $admin, 'message' => $e->getCode().': '.$e->getMessage().PHP_EOL.$e->getTraceAsString()]);
                }
            }

        }

    }





}else{
    echo "لطفا ورژن php هاست خود را به هفت ارتقا دهید .";
}